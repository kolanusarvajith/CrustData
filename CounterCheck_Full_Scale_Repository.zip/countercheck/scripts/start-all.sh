#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "=== Starting CounterCheck v2.0 Full-Scale Stack ==="

if [ ! -f "$ROOT_DIR/apps/api/.env" ]; then
  cp "$ROOT_DIR/apps/api/.env.example" "$ROOT_DIR/apps/api/.env"
  echo "Created apps/api/.env from .env.example (set CRUSTDATA_API_KEY inside apps/api/.env or via the web UI Runtime Controls)."
fi

if command -v ollama >/dev/null 2>&1; then
  echo "Detected local Ollama installation."
else
  echo "Note: Ollama CLI not found in PATH; CounterCheck will use its built-in deterministic fallback until Ollama is started."
fi

echo "Starting FastAPI backend on http://localhost:8000 ..."
(cd "$ROOT_DIR/apps/api" && python3 -m uvicorn app.main:app --reload --port 8000) &
API_PID=$!

echo "Starting Next.js analyst workspace on http://localhost:3000 ..."
(cd "$ROOT_DIR/apps/web" && npm install && npm run dev) &
WEB_PID=$!

trap "kill $API_PID $WEB_PID 2>/dev/null || true" EXIT
wait
