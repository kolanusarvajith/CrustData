#!/usr/bin/env bash
set -euo pipefail
MODEL="${LLM_MODEL:-qwen2.5:3b-instruct}"
if ! command -v ollama >/dev/null 2>&1; then
  echo "Ollama is not installed. Install Ollama for macOS from https://ollama.com/download, then rerun." >&2
  exit 1
fi
ollama pull "$MODEL"
echo "Model '$MODEL' downloaded. Verify with: ollama list"
