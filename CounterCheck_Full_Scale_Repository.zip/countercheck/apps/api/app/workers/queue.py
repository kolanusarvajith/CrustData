from __future__ import annotations
import json
import redis
from app.core.config import settings

QUEUE_KEY = "countercheck:investigations"


class InvestigationQueue:
    def __init__(self, client: redis.Redis | None = None):
        self.client = client or redis.Redis.from_url(settings.redis_url, decode_responses=True)

    def enqueue(self, investigation_id: str) -> None:
        self.client.lpush(QUEUE_KEY, json.dumps({"investigation_id": investigation_id}))

    def dequeue(self, timeout: int = 5) -> str | None:
        item = self.client.brpop(QUEUE_KEY, timeout=timeout)
        if item is None:
            return None
        payload = json.loads(item[1])
        return str(payload["investigation_id"])
