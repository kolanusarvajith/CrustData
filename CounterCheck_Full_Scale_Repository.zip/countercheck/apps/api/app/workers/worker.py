from __future__ import annotations
import asyncio
import logging
from app.core.database import SessionLocal
from app.services.investigation_workflow import resolve_and_enrich
from app.workers.queue import InvestigationQueue

logger = logging.getLogger(__name__)


async def execute(investigation_id: str) -> None:
    db = SessionLocal()
    try:
        await resolve_and_enrich(investigation_id, db)
    except Exception:
        logger.exception("Investigation worker failed for %s", investigation_id)
    finally:
        db.close()


def main() -> None:
    queue = InvestigationQueue()
    while True:
        investigation_id = queue.dequeue(timeout=5)
        if investigation_id:
            asyncio.run(execute(investigation_id))


if __name__ == "__main__":
    main()
