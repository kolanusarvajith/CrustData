"""Simple CLI worker entry point. Queue integration is deliberately isolated here."""
import asyncio
import os
from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.services.investigation_workflow import resolve_and_enrich


async def run(investigation_id: str) -> None:
    db: Session = SessionLocal()
    try:
        result = await resolve_and_enrich(investigation_id, db)
        print({"investigation_id": investigation_id, "status": result.get("status")})
    finally:
        db.close()


if __name__ == "__main__":
    target = os.environ.get("INVESTIGATION_ID")
    if not target:
        raise SystemExit("Set INVESTIGATION_ID")
    asyncio.run(run(target))
