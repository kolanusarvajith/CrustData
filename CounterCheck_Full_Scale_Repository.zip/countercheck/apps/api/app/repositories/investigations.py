from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.models.investigation import Investigation, Claim, InvestigationEvent
from app.schemas.investigation import InvestigationCreate


class InvestigationRepository:
    def __init__(self, db: Session):
        self.db = db

    def create(self, body: InvestigationCreate) -> Investigation:
        identifier = body.company_domain or body.company_name or ""
        item = Investigation(company_identifier=identifier, company_name=body.company_name,
            company_domain=body.company_domain, purpose=body.purpose, status="draft",
            input_snapshot=body.model_dump(mode="json"))
        for claim in body.claims:
            item.claims.append(Claim(**claim.model_dump()))
        self.db.add(item)
        self.db.commit()
        self.db.refresh(item)
        return item

    def get(self, investigation_id: str) -> Investigation | None:
        return self.db.scalar(select(Investigation).where(Investigation.id == investigation_id))

    def list(self, limit: int = 50, offset: int = 0) -> list[Investigation]:
        return list(self.db.scalars(select(Investigation).order_by(Investigation.created_at.desc()).limit(limit).offset(offset)))

    def append_event(self, investigation_id: str, *, stage: str, event_type: str, status: str, message: str, details: dict | None = None) -> InvestigationEvent:
        current = self.db.scalar(select(func.max(InvestigationEvent.sequence)).where(InvestigationEvent.investigation_id == investigation_id)) or 0
        event = InvestigationEvent(investigation_id=investigation_id, sequence=current + 1, stage=stage,
            event_type=event_type, status=status, safe_message=message, details=details or {})
        self.db.add(event)
        self.db.commit()
        self.db.refresh(event)
        return event
