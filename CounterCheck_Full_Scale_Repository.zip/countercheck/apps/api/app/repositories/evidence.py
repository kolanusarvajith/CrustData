from sqlalchemy.orm import Session
from app.models.investigation import EvidenceSource, Observation
from app.schemas.evidence import EvidenceSourceCreate, ObservationCreate


class EvidenceRepository:
    def __init__(self, db: Session):
        self.db = db

    def create_source(self, investigation_id: str, body: EvidenceSourceCreate) -> EvidenceSource:
        source = EvidenceSource(investigation_id=investigation_id, provider=body.provider,
            provider_entity_id=body.provider_entity_id, source_url=str(body.source_url) if body.source_url else None,
            source_title=body.source_title, publisher=body.publisher, published_at=body.published_at,
            content_hash=body.content_hash, raw_object_ref=body.raw_object_ref, limitations=body.limitations)
        self.db.add(source)
        self.db.commit()
        self.db.refresh(source)
        return source

    def create_observation(self, investigation_id: str, body: ObservationCreate) -> Observation:
        observation = Observation(investigation_id=investigation_id, **body.model_dump())
        self.db.add(observation)
        self.db.commit()
        self.db.refresh(observation)
        return observation
