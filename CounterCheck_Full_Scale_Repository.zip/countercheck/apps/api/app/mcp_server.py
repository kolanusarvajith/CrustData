"""Model Context Protocol (MCP) Server for CounterCheck autonomous due-diligence tools."""
from __future__ import annotations
import asyncio
import json
import sys
from typing import Any
from app.core.store import store
from app.integrations.llm.provider import OllamaProvider
from app.services.claim_extraction import extract_claims
from app.services.investigation_workflow import run_full_investigation_pipeline

MCP_TOOLS = [
    {
        "name": "countercheck_extract_claims",
        "description": "Extract structured, testable due-diligence claims from unstructured company pitch or data room text.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "company": {"type": "string", "description": "Company name or domain"},
                "text": {"type": "string", "description": "Unstructured text containing claims"},
            },
            "required": ["company", "text"],
        },
    },
    {
        "name": "countercheck_run_investigation",
        "description": "Execute an end-to-end Crustdata + deterministic verification investigation on a company and its claims.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "company_name": {"type": "string"},
                "company_domain": {"type": "string"},
                "purpose": {"type": "string"},
                "claims": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "category": {"type": "string"},
                            "original_text": {"type": "string"},
                            "claimed_value": {},
                        },
                        "required": ["category", "original_text"],
                    },
                },
            },
            "required": ["claims"],
        },
    },
    {
        "name": "countercheck_get_dossier",
        "description": "Retrieve the complete verified dossier, evidence sources, and entity graph for an investigation ID.",
        "inputSchema": {
            "type": "object",
            "properties": {"investigation_id": {"type": "string"}},
            "required": ["investigation_id"],
        },
    },
]


async def handle_mcp_request(req: dict[str, Any]) -> dict[str, Any]:
    method = req.get("method")
    req_id = req.get("id")
    params = req.get("params") or {}

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "countercheck-mcp", "version": "2.0.0"},
                "capabilities": {"tools": {}},
            },
        }
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": req_id, "result": {"tools": MCP_TOOLS}}
    if method == "tools/call":
        tool_name = params.get("name")
        args = params.get("arguments") or {}
        if tool_name == "countercheck_extract_claims":
            llm = OllamaProvider()
            res = await extract_claims(llm, str(args.get("company", "Company")), str(args.get("text", "")))
            return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": json.dumps(res, indent=2)}]}}
        if tool_name == "countercheck_run_investigation":
            created = store.create_investigation(
                company_name=args.get("company_name"),
                company_domain=args.get("company_domain"),
                purpose=args.get("purpose") or "MCP Autonomous Investigation",
                claims=args.get("claims") or [],
            )
            completed = await run_full_investigation_pipeline(created["id"], auto_select_top_candidate=True)
            return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": json.dumps(completed, indent=2, default=str)}]}}
        if tool_name == "countercheck_get_dossier":
            inv = store.get_investigation(str(args.get("investigation_id", "")))
            return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": json.dumps(inv, indent=2, default=str)}]}}
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Unknown tool: {tool_name}"}}

    return {"jsonrpc": "2.0", "id": req_id, "result": {}}


def main() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            resp = asyncio.run(handle_mcp_request(req))
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
        except Exception as exc:
            sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(exc)}}) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
