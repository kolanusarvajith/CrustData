from datetime import datetime
from pydantic import BaseModel, Field
from typing import Any


class ClaimInput(BaseModel):
    original_text: str = Field(min_length=1, max_length=2000)
    category: str = Field(min_length=1, max_length=80)
    subject: str = Field(min_length=1, max_length=256)
    metric: str = Field(min_length=1, max_length=128)
    operator: str = Field(default="equals", max_length=32)
    claimed_value: Any = None
    unit: str | None = None
    period: str | None = None


class InvestigationCreate(BaseModel):
    company_name: str | None = Field(default=None, min_length=1, max_length=256)
    company_domain: str | None = Field(default=None, min_length=1, max_length=253)
    purpose: str = Field(default="Preliminary business due diligence", max_length=500)
    claims: list[ClaimInput] = Field(min_length=1, max_length=50)

    def validate_company(self) -> "InvestigationCreate":
        if bool(self.company_name) == bool(self.company_domain):
            raise ValueError("Provide exactly one of company_name or company_domain")
        return self


class InvestigationSummary(BaseModel):
    id: str
    status: str
    company_identifier: str
    created_at: datetime
