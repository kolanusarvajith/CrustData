from datetime import datetime
from pydantic import BaseModel, Field, HttpUrl
from typing import Any


class EvidenceSourceCreate(BaseModel):
    provider: str = Field(min_length=1, max_length=40)
    provider_entity_id: str | None = None
    source_url: HttpUrl | None = None
    source_title: str | None = None
    publisher: str | None = None
    published_at: datetime | None = None
    content_hash: str | None = Field(default=None, max_length=64)
    raw_object_ref: str | None = None
    limitations: str | None = None


class ObservationCreate(BaseModel):
    evidence_source_id: str
    entity_provider_id: str | None = None
    field_path: str = Field(min_length=1, max_length=512)
    raw_value: Any = None
    normalized_value: Any = None
    unit: str | None = None
    observed_at: datetime | None = None
