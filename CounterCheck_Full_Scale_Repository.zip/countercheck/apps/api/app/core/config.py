from __future__ import annotations
import os
from pathlib import Path
from typing import Any

# Load .env files if present without requiring external packages
for env_name in (".env", ".env.local"):
    for base in (Path.cwd(), Path(__file__).resolve().parents[2]):
        env_path = base / env_name
        if env_path.is_file():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip('"').strip("'")
                if k and k not in os.environ:
                    os.environ[k] = v


def _env_bool(key: str, default: bool) -> bool:
    val = os.environ.get(key)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


DEFAULT_BACKEND_CRUSTDATA_KEY = "cd_2fe96ab6021f8a28d31c7d878c9412f0ba1c"


class Settings:
    def __init__(self) -> None:
        self.app_env: str = os.environ.get("APP_ENV", "development")
        self.app_name: str = os.environ.get("APP_NAME", "CounterCheck")
        self.database_url: str = os.environ.get(
            "DATABASE_URL",
            f"sqlite:///{(Path(__file__).resolve().parents[2] / 'countercheck_dev.db').as_posix()}",
        )
        self.sqlite_path: str = os.environ.get(
            "SQLITE_PATH",
            str(Path(__file__).resolve().parents[2] / "countercheck_dev.db"),
        )
        self.redis_url: str = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
        raw_key = os.environ.get("CRUSTDATA_API_KEY", DEFAULT_BACKEND_CRUSTDATA_KEY)
        if raw_key in {"replace_me_after_rotating_the_exposed_key", "your_crustdata_api_key_here"}:
            raw_key = DEFAULT_BACKEND_CRUSTDATA_KEY
        self.crustdata_api_key: str = raw_key
        self.crustdata_api_base_url: str = os.environ.get("CRUSTDATA_API_BASE_URL", "https://api.crustdata.com")
        self.crustdata_api_version: str = os.environ.get("CRUSTDATA_API_VERSION", "2025-11-01")
        self.crustdata_timeout_seconds: float = float(os.environ.get("CRUSTDATA_TIMEOUT_SECONDS", "8"))
        self.crustdata_max_calls_per_investigation: int = int(os.environ.get("CRUSTDATA_MAX_CALLS_PER_INVESTIGATION", "25"))
        self.crustdata_max_estimated_credits_per_investigation: float = float(
            os.environ.get("CRUSTDATA_MAX_ESTIMATED_CREDITS_PER_INVESTIGATION", "50.0")
        )
        self.crustdata_demo_fallback: bool = _env_bool("CRUSTDATA_DEMO_FALLBACK", True)
        self.global_kill_switch: bool = _env_bool("GLOBAL_KILL_SWITCH", False)
        self.llm_provider: str = os.environ.get("LLM_PROVIDER", "ollama")
        self.llm_base_url: str = os.environ.get("LLM_BASE_URL", "http://localhost:11434")
        self.llm_model: str = os.environ.get("LLM_MODEL", "qwen2.5:3b-instruct")
        self.llm_timeout_seconds: float = float(os.environ.get("LLM_TIMEOUT_SECONDS", "90"))
        self.llm_required: bool = _env_bool("LLM_REQUIRED", True)
        self.cors_origins: str = os.environ.get("CORS_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000,http://localhost:8000,http://127.0.0.1:8000,*")

    @property
    def cors_origin_list(self) -> list[str]:
        origins = [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]
        return origins or ["*"]

    def update_runtime(self, updates: dict[str, Any]) -> dict[str, Any]:
        if "crustdata_api_key" in updates and updates["crustdata_api_key"] is not None:
            val = str(updates["crustdata_api_key"]).strip()
            if val and not val.startswith("***") and "..." not in val:
                self.crustdata_api_key = val
        if "crustdata_api_base_url" in updates and updates["crustdata_api_base_url"]:
            self.crustdata_api_base_url = str(updates["crustdata_api_base_url"]).strip().rstrip("/")
        if "crustdata_max_calls_per_investigation" in updates and updates["crustdata_max_calls_per_investigation"] is not None:
            self.crustdata_max_calls_per_investigation = max(1, int(updates["crustdata_max_calls_per_investigation"]))
        if "crustdata_max_estimated_credits_per_investigation" in updates and updates["crustdata_max_estimated_credits_per_investigation"] is not None:
            self.crustdata_max_estimated_credits_per_investigation = max(1.0, float(updates["crustdata_max_estimated_credits_per_investigation"]))
        if "crustdata_demo_fallback" in updates and updates["crustdata_demo_fallback"] is not None:
            self.crustdata_demo_fallback = bool(updates["crustdata_demo_fallback"])
        if "global_kill_switch" in updates and updates["global_kill_switch"] is not None:
            self.global_kill_switch = bool(updates["global_kill_switch"])
        if "llm_base_url" in updates and updates["llm_base_url"]:
            self.llm_base_url = str(updates["llm_base_url"]).strip().rstrip("/")
        if "llm_model" in updates and updates["llm_model"]:
            self.llm_model = str(updates["llm_model"]).strip()
        if "llm_timeout_seconds" in updates and updates["llm_timeout_seconds"] is not None:
            self.llm_timeout_seconds = max(5.0, float(updates["llm_timeout_seconds"]))
        return self.safe_dict()

    def safe_dict(self) -> dict[str, Any]:
        masked_key = ""
        if self.crustdata_api_key:
            if len(self.crustdata_api_key) > 10:
                masked_key = f"{self.crustdata_api_key[:6]}...{self.crustdata_api_key[-4:]}"
            else:
                masked_key = "***configured***"
        return {
            "app_env": self.app_env,
            "crustdata_configured": bool(self.crustdata_api_key),
            "crustdata_key_preview": masked_key,
            "crustdata_api_base_url": self.crustdata_api_base_url,
            "crustdata_api_version": self.crustdata_api_version,
            "crustdata_max_calls_per_investigation": self.crustdata_max_calls_per_investigation,
            "crustdata_max_estimated_credits_per_investigation": self.crustdata_max_estimated_credits_per_investigation,
            "crustdata_demo_fallback": self.crustdata_demo_fallback,
            "global_kill_switch": self.global_kill_switch,
            "llm_provider": self.llm_provider,
            "llm_base_url": self.llm_base_url,
            "llm_model": self.llm_model,
            "llm_timeout_seconds": self.llm_timeout_seconds,
            "llm_required": self.llm_required,
        }


settings = Settings()


def get_settings() -> Settings:
    return settings
