import logging
import re

_SECRET_PATTERNS = [
    re.compile(r'(?i)(authorization\s*[:=]\s*bearer\s+)[^\s,;"\']+'),
    re.compile(r'(?i)(crustdata_api_key\s*[:=]\s*)[^\s,;"\']+'),
    re.compile(r'(?i)(api_key\s*[:=]\s*)[^\s,;"\']+'),
]


def redact_secrets(text: str) -> str:
    result = str(text)
    for pattern in _SECRET_PATTERNS:
        result = pattern.sub(r"\1[REDACTED]", result)
    return result


class SecretRedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        record.msg = redact_secrets(message)
        record.args = ()
        return True


def configure_logging() -> None:
    root = logging.getLogger()
    if not root.handlers:
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    for handler in root.handlers:
        handler.addFilter(SecretRedactionFilter())
