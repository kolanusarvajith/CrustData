from app.core.database import Base, engine
from app.models.investigation import Investigation, Claim, EvidenceSource, Observation, Verdict, InvestigationEvent  # noqa: F401


def initialize_development_database() -> None:
    Base.metadata.create_all(bind=engine)


if __name__ == "__main__":
    initialize_development_database()
