"""Zero-friction transactional SQLite persistence store implementing the full Section 9 schema."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4
from app.core.config import settings


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class CounterCheckStore:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or settings.sqlite_path
        self._lock = threading.RLock()
        try:
            self._init_schema()
        except sqlite3.OperationalError:
            self.db_path = "/tmp/countercheck_dev.db"
            self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _init_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS workspaces (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    settings_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS investigations (
                    id TEXT PRIMARY KEY,
                    workspace_id TEXT NOT NULL DEFAULT 'ws_default',
                    company_identifier TEXT NOT NULL,
                    company_name TEXT,
                    company_domain TEXT,
                    company_crustdata_id INTEGER,
                    purpose TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'draft',
                    current_stage TEXT NOT NULL DEFAULT 'draft',
                    cancel_requested INTEGER NOT NULL DEFAULT 0,
                    input_snapshot TEXT NOT NULL DEFAULT '{}',
                    candidates_json TEXT NOT NULL DEFAULT '[]',
                    company_profile_json TEXT NOT NULL DEFAULT '{}',
                    people_json TEXT NOT NULL DEFAULT '[]',
                    jobs_json TEXT NOT NULL DEFAULT '[]',
                    graph_json TEXT NOT NULL DEFAULT '{"nodes":[],"edges":[]}',
                    quality_warnings_json TEXT NOT NULL DEFAULT '[]',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS claims (
                    id TEXT PRIMARY KEY,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    category TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    metric TEXT NOT NULL,
                    operator TEXT NOT NULL DEFAULT 'equals',
                    claimed_value_json TEXT,
                    unit TEXT,
                    period TEXT,
                    original_text TEXT NOT NULL,
                    parse_version TEXT NOT NULL DEFAULT 'v2.1',
                    ambiguity_flags_json TEXT NOT NULL DEFAULT '[]'
                );
                CREATE TABLE IF NOT EXISTS verdicts (
                    id TEXT PRIMARY KEY,
                    claim_id TEXT NOT NULL UNIQUE REFERENCES claims(id) ON DELETE CASCADE,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    status TEXT NOT NULL,
                    explanation TEXT NOT NULL,
                    confidence_band TEXT NOT NULL DEFAULT 'MEDIUM',
                    rule_version TEXT NOT NULL DEFAULT '2.1.0',
                    evidence_ids_json TEXT NOT NULL DEFAULT '[]',
                    operands_json TEXT NOT NULL DEFAULT '{}',
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS human_reviews (
                    id TEXT PRIMARY KEY,
                    claim_id TEXT NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    reviewer_id TEXT NOT NULL DEFAULT 'analyst@countercheck.local',
                    disposition TEXT NOT NULL,
                    override_status TEXT,
                    override_reason TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS evidence_sources (
                    id TEXT PRIMARY KEY,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    provider TEXT NOT NULL,
                    provider_entity_id TEXT,
                    source_url TEXT,
                    source_title TEXT,
                    publisher TEXT,
                    source_quality TEXT NOT NULL DEFAULT 'provider_indexed',
                    published_at TEXT,
                    retrieved_at TEXT NOT NULL,
                    content_hash TEXT,
                    raw_object_ref TEXT,
                    limitations TEXT,
                    annotations_json TEXT NOT NULL DEFAULT '[]'
                );
                CREATE TABLE IF NOT EXISTS observations (
                    id TEXT PRIMARY KEY,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    evidence_source_id TEXT NOT NULL REFERENCES evidence_sources(id) ON DELETE CASCADE,
                    entity_provider_id TEXT,
                    field_path TEXT NOT NULL,
                    raw_value_json TEXT,
                    normalized_value_json TEXT,
                    unit TEXT,
                    observed_at TEXT
                );
                CREATE TABLE IF NOT EXISTS investigation_events (
                    id TEXT PRIMARY KEY,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    sequence INTEGER NOT NULL,
                    stage TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    safe_message TEXT NOT NULL,
                    details_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    UNIQUE(investigation_id, sequence)
                );
                CREATE TABLE IF NOT EXISTS credit_ledger (
                    id TEXT PRIMARY KEY,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    provider TEXT NOT NULL DEFAULT 'crustdata',
                    endpoint TEXT NOT NULL,
                    estimated_credits REAL NOT NULL DEFAULT 0.0,
                    actual_credits REAL,
                    status_code INTEGER DEFAULT 200,
                    latency_ms REAL DEFAULT 0.0,
                    mode TEXT DEFAULT 'live',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit_events (
                    id TEXT PRIMARY KEY,
                    investigation_id TEXT,
                    actor_id TEXT NOT NULL DEFAULT 'analyst@countercheck.local',
                    action TEXT NOT NULL,
                    object_type TEXT NOT NULL,
                    object_id TEXT,
                    reason TEXT,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS reports (
                    id TEXT PRIMARY KEY,
                    investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
                    version INTEGER NOT NULL,
                    content_json TEXT NOT NULL,
                    content_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                """
            )
            # Ensure default workspace exists
            conn.execute(
                "INSERT OR IGNORE INTO workspaces (id, name, settings_json, created_at) VALUES (?, ?, ?, ?)",
                ("ws_default", "CounterCheck Primary Trust & Compliance Workspace", "{}", utcnow_iso()),
            )
            conn.commit()

    def create_investigation(
        self,
        *,
        company_name: str | None,
        company_domain: str | None,
        purpose: str,
        claims: list[dict[str, Any]],
    ) -> dict[str, Any]:
        inv_id = f"inv_{uuid4().hex[:12]}"
        now = utcnow_iso()
        identifier = (company_domain or company_name or "").strip()
        snapshot = {
            "company_name": company_name,
            "company_domain": company_domain,
            "purpose": purpose,
            "claims": claims,
        }
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO investigations (
                    id, company_identifier, company_name, company_domain, purpose,
                    status, current_stage, input_snapshot, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, 'draft', 'draft', ?, ?, ?)
                """,
                (inv_id, identifier, company_name, company_domain, purpose, json.dumps(snapshot, default=str), now, now),
            )
            created_claims = []
            for idx, c in enumerate(claims):
                cid = f"clm_{uuid4().hex[:10]}"
                val = c.get("claimed_value", c.get("value"))
                ambig = c.get("ambiguity_flags") or []
                conn.execute(
                    """
                    INSERT INTO claims (
                        id, investigation_id, category, subject, metric, operator,
                        claimed_value_json, unit, period, original_text, parse_version, ambiguity_flags_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        cid,
                        inv_id,
                        str(c.get("category") or "general"),
                        str(c.get("subject") or identifier),
                        str(c.get("metric") or c.get("category") or "fact"),
                        str(c.get("operator") or "equals"),
                        json.dumps(val, default=str),
                        c.get("unit"),
                        c.get("period"),
                        str(c.get("original_text") or f"{c.get('metric')}: {val}"),
                        str(c.get("parse_version") or "v2.1"),
                        json.dumps(ambig),
                    ),
                )
                created_claims.append({
                    "id": cid,
                    "category": str(c.get("category") or "general"),
                    "subject": str(c.get("subject") or identifier),
                    "metric": str(c.get("metric") or c.get("category") or "fact"),
                    "operator": str(c.get("operator") or "equals"),
                    "claimed_value": val,
                    "unit": c.get("unit"),
                    "period": c.get("period"),
                    "original_text": str(c.get("original_text") or ""),
                    "ambiguity_flags": ambig,
                })
            conn.execute(
                """
                INSERT INTO audit_events (id, investigation_id, action, object_type, object_id, reason, metadata_json, created_at)
                VALUES (?, ?, 'investigation_created', 'investigation', ?, 'Initial intake submitted', ?, ?)
                """,
                (f"aud_{uuid4().hex[:10]}", inv_id, inv_id, json.dumps({"claim_count": len(created_claims)}), now),
            )
            conn.commit()
        self.append_event(
            inv_id,
            stage="draft",
            event_type="investigation_created",
            status="draft",
            message=f"Investigation created for '{identifier}' with {len(created_claims)} testable claims.",
            details={"claim_count": len(created_claims)},
        )
        return self.get_investigation(inv_id)  # type: ignore[return-value]

    def add_claim_to_investigation(self, investigation_id: str, claim_data: dict[str, Any]) -> dict[str, Any]:
        cid = f"clm_{uuid4().hex[:10]}"
        val = claim_data.get("claimed_value", claim_data.get("value"))
        ambig = claim_data.get("ambiguity_flags") or []
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO claims (
                    id, investigation_id, category, subject, metric, operator,
                    claimed_value_json, unit, period, original_text, parse_version, ambiguity_flags_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    cid,
                    investigation_id,
                    str(claim_data.get("category") or "general"),
                    str(claim_data.get("subject") or "Company"),
                    str(claim_data.get("metric") or claim_data.get("category") or "fact"),
                    str(claim_data.get("operator") or "equals"),
                    json.dumps(val, default=str),
                    claim_data.get("unit"),
                    claim_data.get("period"),
                    str(claim_data.get("original_text") or f"{claim_data.get('metric')}: {val}"),
                    "v2.1",
                    json.dumps(ambig),
                ),
            )
            conn.commit()
        return self.get_claim(cid)  # type: ignore[return-value]

    def list_investigations(self, limit: int = 50, offset: int = 0) -> list[dict[str, Any]]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM investigations ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
            results = []
            for r in rows:
                inv_id = r["id"]
                claims = self._fetch_claims_for_investigation(conn, inv_id)
                credits = conn.execute(
                    "SELECT COALESCE(SUM(estimated_credits), 0) AS est, COALESCE(SUM(actual_credits), 0) AS act FROM credit_ledger WHERE investigation_id = ?",
                    (inv_id,),
                ).fetchone()
                verdict_counts = {"SUPPORTED": 0, "CONTRADICTED": 0, "UNVERIFIED": 0, "CONFLICTING": 0}
                for c in claims:
                    v = c.get("verdict")
                    if v and v.get("status") in verdict_counts:
                        verdict_counts[v["status"]] += 1
                    else:
                        verdict_counts["UNVERIFIED"] += 1
                results.append({
                    "id": inv_id,
                    "status": r["status"],
                    "current_stage": r["current_stage"],
                    "company_identifier": r["company_identifier"],
                    "company_name": r["company_name"] or r["company_identifier"],
                    "company_domain": r["company_domain"],
                    "company_crustdata_id": r["company_crustdata_id"],
                    "purpose": r["purpose"],
                    "claim_count": len(claims),
                    "verdict_counts": verdict_counts,
                    "estimated_credits": round(float(credits["est"] if credits else 0.0), 2),
                    "actual_credits": round(float(credits["act"] if credits else 0.0), 2),
                    "created_at": r["created_at"],
                    "updated_at": r["updated_at"],
                })
            return results

    def _fetch_claims_for_investigation(self, conn: sqlite3.Connection, investigation_id: str) -> list[dict[str, Any]]:
        c_rows = conn.execute("SELECT * FROM claims WHERE investigation_id = ? ORDER BY rowid ASC", (investigation_id,)).fetchall()
        claims = []
        for c in c_rows:
            cid = c["id"]
            v_row = conn.execute("SELECT * FROM verdicts WHERE claim_id = ?", (cid,)).fetchone()
            rev_row = conn.execute(
                "SELECT * FROM human_reviews WHERE claim_id = ? ORDER BY created_at DESC LIMIT 1",
                (cid,),
            ).fetchone()
            verdict_dict = None
            if v_row:
                verdict_dict = {
                    "id": v_row["id"],
                    "status": v_row["status"],
                    "explanation": v_row["explanation"],
                    "confidence_band": v_row["confidence_band"],
                    "rule_version": v_row["rule_version"],
                    "evidence_ids": json.loads(v_row["evidence_ids_json"] or "[]"),
                    "operands": json.loads(v_row["operands_json"] or "{}"),
                    "updated_at": v_row["updated_at"],
                }
            review_dict = None
            if rev_row:
                review_dict = {
                    "id": rev_row["id"],
                    "reviewer_id": rev_row["reviewer_id"],
                    "disposition": rev_row["disposition"],
                    "override_status": rev_row["override_status"],
                    "override_reason": rev_row["override_reason"],
                    "created_at": rev_row["created_at"],
                }
            claims.append({
                "id": cid,
                "investigation_id": investigation_id,
                "category": c["category"],
                "subject": c["subject"],
                "metric": c["metric"],
                "operator": c["operator"],
                "claimed_value": json.loads(c["claimed_value_json"]) if c["claimed_value_json"] is not None else None,
                "unit": c["unit"],
                "period": c["period"],
                "original_text": c["original_text"],
                "parse_version": c["parse_version"],
                "ambiguity_flags": json.loads(c["ambiguity_flags_json"] or "[]"),
                "verdict": verdict_dict,
                "human_review": review_dict,
            })
        return claims

    def get_investigation(self, investigation_id: str) -> dict[str, Any] | None:
        with self._lock, self._connect() as conn:
            r = conn.execute("SELECT * FROM investigations WHERE id = ?", (investigation_id,)).fetchone()
            if not r:
                return None
            claims = self._fetch_claims_for_investigation(conn, investigation_id)
            sources = self.list_evidence_sources(investigation_id, _conn=conn)
            observations = self.list_observations(investigation_id, _conn=conn)
            events = self.list_events(investigation_id, after=0, _conn=conn)
            credits = self.list_credits(investigation_id, _conn=conn)
            reports = self.list_reports(investigation_id, _conn=conn)
            audits = self.list_audit_events(investigation_id, _conn=conn)
            return {
                "id": r["id"],
                "workspace_id": r["workspace_id"],
                "status": r["status"],
                "current_stage": r["current_stage"],
                "cancel_requested": bool(r["cancel_requested"]),
                "company_identifier": r["company_identifier"],
                "company_name": r["company_name"],
                "company_domain": r["company_domain"],
                "company_crustdata_id": r["company_crustdata_id"],
                "purpose": r["purpose"],
                "candidates": json.loads(r["candidates_json"] or "[]"),
                "company_profile": json.loads(r["company_profile_json"] or "{}"),
                "people": json.loads(r["people_json"] or "[]"),
                "jobs": json.loads(r["jobs_json"] or "[]"),
                "graph": json.loads(r["graph_json"] or '{"nodes":[],"edges":[]}'),
                "quality_warnings": json.loads(r["quality_warnings_json"] or "[]"),
                "claims": claims,
                "evidence_sources": sources,
                "observations": observations,
                "events": events,
                "credit_usage": credits,
                "reports": reports,
                "audit_events": audits,
                "created_at": r["created_at"],
                "updated_at": r["updated_at"],
            }

    def get_claim(self, claim_id: str) -> dict[str, Any] | None:
        with self._lock, self._connect() as conn:
            c = conn.execute("SELECT * FROM claims WHERE id = ?", (claim_id,)).fetchone()
            if not c:
                return None
            inv_claims = self._fetch_claims_for_investigation(conn, c["investigation_id"])
            return next((x for x in inv_claims if x["id"] == claim_id), None)

    def update_investigation_state(self, investigation_id: str, **fields: Any) -> None:
        if not fields:
            return
        fields["updated_at"] = utcnow_iso()
        cols = []
        vals = []
        for k, v in fields.items():
            if isinstance(v, (dict, list)):
                cols.append(f"{k} = ?")
                vals.append(json.dumps(v, default=str))
            elif isinstance(v, bool):
                cols.append(f"{k} = ?")
                vals.append(1 if v else 0)
            else:
                cols.append(f"{k} = ?")
                vals.append(v)
        vals.append(investigation_id)
        with self._lock, self._connect() as conn:
            conn.execute(f"UPDATE investigations SET {', '.join(cols)} WHERE id = ?", vals)
            conn.commit()

    def append_event(
        self,
        investigation_id: str,
        *,
        stage: str,
        event_type: str,
        status: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        now = utcnow_iso()
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT COALESCE(MAX(sequence), 0) AS max_seq FROM investigation_events WHERE investigation_id = ?",
                (investigation_id,),
            ).fetchone()
            seq = int(row["max_seq"] if row else 0) + 1
            ev_id = f"evt_{uuid4().hex[:10]}"
            conn.execute(
                """
                INSERT INTO investigation_events (id, investigation_id, sequence, stage, event_type, status, safe_message, details_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (ev_id, investigation_id, seq, stage, event_type, status, message, json.dumps(details or {}, default=str), now),
            )
            conn.execute(
                "UPDATE investigations SET current_stage = ?, updated_at = ? WHERE id = ?",
                (stage, now, investigation_id),
            )
            conn.commit()
            return {
                "id": ev_id,
                "event_id": ev_id,
                "investigation_id": investigation_id,
                "sequence": seq,
                "stage": stage,
                "event_type": event_type,
                "status": status,
                "message": message,
                "details": details or {},
                "created_at": now,
            }

    def list_events(self, investigation_id: str, *, after: int = 0, _conn: sqlite3.Connection | None = None) -> list[dict[str, Any]]:
        def _query(c: sqlite3.Connection) -> list[dict[str, Any]]:
            rows = c.execute(
                "SELECT * FROM investigation_events WHERE investigation_id = ? AND sequence > ? ORDER BY sequence ASC",
                (investigation_id, after),
            ).fetchall()
            return [
                {
                    "id": r["id"],
                    "event_id": r["id"],
                    "investigation_id": r["investigation_id"],
                    "sequence": r["sequence"],
                    "stage": r["stage"],
                    "event_type": r["event_type"],
                    "status": r["status"],
                    "message": r["safe_message"],
                    "details": json.loads(r["details_json"] or "{}"),
                    "created_at": r["created_at"],
                }
                for r in rows
            ]
        if _conn is not None:
            return _query(_conn)
        with self._lock, self._connect() as conn:
            return _query(conn)

    def create_evidence_source(self, investigation_id: str, data: dict[str, Any]) -> dict[str, Any]:
        sid = data.get("id") or f"ev_{uuid4().hex[:8]}"
        now = utcnow_iso()
        raw_str = json.dumps(data.get("raw_payload") or data, sort_keys=True, default=str)
        content_hash = data.get("content_hash") or hashlib.sha256(raw_str.encode("utf-8")).hexdigest()[:24]
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO evidence_sources (
                    id, investigation_id, provider, provider_entity_id, source_url, source_title,
                    publisher, source_quality, published_at, retrieved_at, content_hash, raw_object_ref, limitations, annotations_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    sid,
                    investigation_id,
                    str(data.get("provider") or "crustdata"),
                    str(data.get("provider_entity_id") or ""),
                    str(data["source_url"]) if data.get("source_url") else None,
                    data.get("source_title") or data.get("title") or "Evidence Source",
                    data.get("publisher") or "Crustdata Canonical Graph",
                    data.get("source_quality") or "provider_indexed",
                    str(data["published_at"]) if data.get("published_at") else None,
                    now,
                    content_hash,
                    data.get("raw_object_ref") or f"s3://countercheck-private/{investigation_id}/{sid}.json",
                    data.get("limitations") or "Provider-indexed record; verify cutoff timestamp.",
                    json.dumps(data.get("annotations") or []),
                ),
            )
            conn.commit()
        return {
            "id": sid,
            "investigation_id": investigation_id,
            "provider": str(data.get("provider") or "crustdata"),
            "provider_entity_id": data.get("provider_entity_id"),
            "source_url": str(data["source_url"]) if data.get("source_url") else None,
            "title": data.get("source_title") or data.get("title"),
            "publisher": data.get("publisher") or "Crustdata Canonical Graph",
            "source_quality": data.get("source_quality") or "provider_indexed",
            "published_at": str(data["published_at"]) if data.get("published_at") else None,
            "retrieved_at": now,
            "content_hash": content_hash,
            "limitations": data.get("limitations"),
            "annotations": data.get("annotations") or [],
        }

    def annotate_evidence_source(self, source_id: str, note: str, author: str = "analyst@countercheck.local") -> dict[str, Any] | None:
        now = utcnow_iso()
        with self._lock, self._connect() as conn:
            row = conn.execute("SELECT * FROM evidence_sources WHERE id = ?", (source_id,)).fetchone()
            if not row:
                return None
            notes = json.loads(row["annotations_json"] or "[]")
            notes.append({"id": f"note_{uuid4().hex[:6]}", "author": author, "note": note, "created_at": now})
            conn.execute("UPDATE evidence_sources SET annotations_json = ? WHERE id = ?", (json.dumps(notes), source_id))
            conn.execute(
                "INSERT INTO audit_events (id, investigation_id, actor_id, action, object_type, object_id, reason, metadata_json, created_at) VALUES (?, ?, ?, 'evidence_annotated', 'evidence_source', ?, ?, '{}', ?)",
                (f"aud_{uuid4().hex[:10]}", row["investigation_id"], author, source_id, note, now),
            )
            conn.commit()
            return {"id": source_id, "annotations": notes}

    def list_evidence_sources(self, investigation_id: str, _conn: sqlite3.Connection | None = None) -> list[dict[str, Any]]:
        def _query(c: sqlite3.Connection) -> list[dict[str, Any]]:
            rows = c.execute(
                "SELECT * FROM evidence_sources WHERE investigation_id = ? ORDER BY retrieved_at DESC",
                (investigation_id,),
            ).fetchall()
            return [
                {
                    "id": r["id"],
                    "provider": r["provider"],
                    "provider_entity_id": r["provider_entity_id"],
                    "source_url": r["source_url"],
                    "title": r["source_title"],
                    "publisher": r["publisher"],
                    "source_quality": r["source_quality"],
                    "published_at": r["published_at"],
                    "retrieved_at": r["retrieved_at"],
                    "content_hash": r["content_hash"],
                    "raw_object_ref": r["raw_object_ref"],
                    "limitations": r["limitations"],
                    "annotations": json.loads(r["annotations_json"] or "[]"),
                }
                for r in rows
            ]
        if _conn is not None:
            return _query(_conn)
        with self._lock, self._connect() as conn:
            return _query(conn)

    def create_observation(self, investigation_id: str, data: dict[str, Any]) -> dict[str, Any]:
        oid = data.get("id") or f"obs_{uuid4().hex[:8]}"
        now = str(data.get("observed_at") or utcnow_iso())
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO observations (
                    id, investigation_id, evidence_source_id, entity_provider_id, field_path,
                    raw_value_json, normalized_value_json, unit, observed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    oid,
                    investigation_id,
                    data["evidence_source_id"],
                    data.get("entity_provider_id"),
                    data["field_path"],
                    json.dumps(data.get("raw_value"), default=str),
                    json.dumps(data.get("normalized_value"), default=str),
                    data.get("unit"),
                    now,
                ),
            )
            conn.commit()
        return {
            "id": oid,
            "investigation_id": investigation_id,
            "evidence_source_id": data["evidence_source_id"],
            "entity_provider_id": data.get("entity_provider_id"),
            "field_path": data["field_path"],
            "raw_value": data.get("raw_value"),
            "normalized_value": data.get("normalized_value"),
            "unit": data.get("unit"),
            "observed_at": now,
        }

    def list_observations(self, investigation_id: str, _conn: sqlite3.Connection | None = None) -> list[dict[str, Any]]:
        def _query(c: sqlite3.Connection) -> list[dict[str, Any]]:
            rows = c.execute("SELECT * FROM observations WHERE investigation_id = ? ORDER BY rowid ASC", (investigation_id,)).fetchall()
            return [
                {
                    "id": r["id"],
                    "investigation_id": r["investigation_id"],
                    "evidence_source_id": r["evidence_source_id"],
                    "entity_provider_id": r["entity_provider_id"],
                    "field_path": r["field_path"],
                    "raw_value": json.loads(r["raw_value_json"]) if r["raw_value_json"] is not None else None,
                    "normalized_value": json.loads(r["normalized_value_json"]) if r["normalized_value_json"] is not None else None,
                    "unit": r["unit"],
                    "observed_at": r["observed_at"],
                }
                for r in rows
            ]
        if _conn is not None:
            return _query(_conn)
        with self._lock, self._connect() as conn:
            return _query(conn)

    def upsert_verdict(
        self,
        *,
        claim_id: str,
        investigation_id: str,
        status: str,
        explanation: str,
        confidence_band: str = "MEDIUM",
        rule_version: str = "2.1.0",
        evidence_ids: list[str] | None = None,
        operands: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        now = utcnow_iso()
        vid = f"vrd_{uuid4().hex[:10]}"
        eids = list(dict.fromkeys(evidence_ids or []))
        with self._lock, self._connect() as conn:
            existing = conn.execute("SELECT id FROM verdicts WHERE claim_id = ?", (claim_id,)).fetchone()
            if existing:
                vid = existing["id"]
                conn.execute(
                    """
                    UPDATE verdicts
                    SET status = ?, explanation = ?, confidence_band = ?, rule_version = ?,
                        evidence_ids_json = ?, operands_json = ?, updated_at = ?
                    WHERE claim_id = ?
                    """,
                    (status, explanation, confidence_band, rule_version, json.dumps(eids), json.dumps(operands or {}, default=str), now, claim_id),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO verdicts (id, claim_id, investigation_id, status, explanation, confidence_band, rule_version, evidence_ids_json, operands_json, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (vid, claim_id, investigation_id, status, explanation, confidence_band, rule_version, json.dumps(eids), json.dumps(operands or {}, default=str), now),
                )
            conn.commit()
        return {
            "id": vid,
            "claim_id": claim_id,
            "status": status,
            "explanation": explanation,
            "confidence_band": confidence_band,
            "rule_version": rule_version,
            "evidence_ids": eids,
            "operands": operands or {},
            "updated_at": now,
        }

    def record_human_review(
        self,
        *,
        claim_id: str,
        disposition: str,
        override_status: str | None = None,
        reason: str | None = None,
        reviewer_id: str = "analyst@countercheck.local",
    ) -> dict[str, Any]:
        now = utcnow_iso()
        rev_id = f"rev_{uuid4().hex[:10]}"
        with self._lock, self._connect() as conn:
            claim = conn.execute("SELECT * FROM claims WHERE id = ?", (claim_id,)).fetchone()
            if not claim:
                raise KeyError("Claim not found")
            inv_id = claim["investigation_id"]
            conn.execute(
                """
                INSERT INTO human_reviews (id, claim_id, investigation_id, reviewer_id, disposition, override_status, override_reason, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (rev_id, claim_id, inv_id, reviewer_id, disposition, override_status, reason, now),
            )
            conn.execute(
                """
                INSERT INTO audit_events (id, investigation_id, actor_id, action, object_type, object_id, reason, metadata_json, created_at)
                VALUES (?, ?, ?, 'claim_reviewed', 'claim', ?, ?, ?, ?)
                """,
                (
                    f"aud_{uuid4().hex[:10]}",
                    inv_id,
                    reviewer_id,
                    claim_id,
                    reason,
                    json.dumps({"disposition": disposition, "override_status": override_status}),
                    now,
                ),
            )
            conn.commit()
        return {
            "review_id": rev_id,
            "claim_id": claim_id,
            "disposition": disposition,
            "override_status": override_status,
            "override_reason": reason,
            "system_verdict_unchanged": True,
            "created_at": now,
        }

    def record_credit(
        self,
        investigation_id: str,
        endpoint: str,
        estimated: float,
        actual: float | None = None,
        *,
        status_code: int = 200,
        latency_ms: float = 0.0,
        mode: str = "live",
    ) -> dict[str, Any]:
        if estimated < 0 or (actual is not None and actual < 0):
            raise ValueError("Credit values cannot be negative")
        cid = f"crd_{uuid4().hex[:10]}"
        now = utcnow_iso()
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO credit_ledger (id, investigation_id, provider, endpoint, estimated_credits, actual_credits, status_code, latency_ms, mode, created_at)
                VALUES (?, ?, 'crustdata', ?, ?, ?, ?, ?, ?, ?)
                """,
                (cid, investigation_id, endpoint, estimated, actual, status_code, latency_ms, mode, now),
            )
            conn.commit()
        return {
            "id": cid,
            "investigation_id": investigation_id,
            "endpoint": endpoint,
            "estimated_credits": estimated,
            "actual_credits": actual,
            "status_code": status_code,
            "latency_ms": latency_ms,
            "mode": mode,
            "created_at": now,
        }

    def list_credits(self, investigation_id: str, _conn: sqlite3.Connection | None = None) -> dict[str, Any]:
        def _query(c: sqlite3.Connection) -> dict[str, Any]:
            rows = c.execute(
                "SELECT * FROM credit_ledger WHERE investigation_id = ? ORDER BY created_at ASC",
                (investigation_id,),
            ).fetchall()
            items = [
                {
                    "id": r["id"],
                    "endpoint": r["endpoint"],
                    "estimated_credits": r["estimated_credits"],
                    "actual_credits": r["actual_credits"],
                    "status_code": r["status_code"],
                    "latency_ms": r["latency_ms"],
                    "mode": r["mode"],
                    "created_at": r["created_at"],
                }
                for r in rows
            ]
            return {
                "items": items,
                "estimated_total": round(sum(x["estimated_credits"] for x in items), 2),
                "actual_total": round(sum(x["actual_credits"] or 0.0 for x in items), 2),
                "budget_cap": settings.crustdata_max_estimated_credits_per_investigation,
            }
        if _conn is not None:
            return _query(_conn)
        with self._lock, self._connect() as conn:
            return _query(conn)

    def create_report_snapshot(self, investigation_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        now = utcnow_iso()
        rid = f"rep_{uuid4().hex[:10]}"
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        chash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT COALESCE(MAX(version), 0) AS max_v FROM reports WHERE investigation_id = ?",
                (investigation_id,),
            ).fetchone()
            ver = int(row["max_v"] if row else 0) + 1
            payload_with_ver = {**payload, "version": ver, "content_hash": chash, "generated_at": payload.get("generated_at") or now}
            conn.execute(
                "INSERT INTO reports (id, investigation_id, version, content_json, content_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (rid, investigation_id, ver, json.dumps(payload_with_ver, default=str), chash, now),
            )
            conn.commit()
        return {
            "id": rid,
            "investigation_id": investigation_id,
            "version": ver,
            "content_hash": chash,
            "content": payload_with_ver,
            "generated_at": now,
        }

    def list_reports(self, investigation_id: str, _conn: sqlite3.Connection | None = None) -> list[dict[str, Any]]:
        def _query(c: sqlite3.Connection) -> list[dict[str, Any]]:
            rows = c.execute(
                "SELECT * FROM reports WHERE investigation_id = ? ORDER BY version DESC",
                (investigation_id,),
            ).fetchall()
            return [
                {
                    "id": r["id"],
                    "version": r["version"],
                    "content_hash": r["content_hash"],
                    "content": json.loads(r["content_json"]),
                    "created_at": r["created_at"],
                }
                for r in rows
            ]
        if _conn is not None:
            return _query(_conn)
        with self._lock, self._connect() as conn:
            return _query(conn)

    def list_audit_events(self, investigation_id: str | None = None, _conn: sqlite3.Connection | None = None) -> list[dict[str, Any]]:
        def _query(c: sqlite3.Connection) -> list[dict[str, Any]]:
            if investigation_id:
                rows = c.execute(
                    "SELECT * FROM audit_events WHERE investigation_id = ? ORDER BY created_at DESC",
                    (investigation_id,),
                ).fetchall()
            else:
                rows = c.execute("SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 100").fetchall()
            return [
                {
                    "id": r["id"],
                    "investigation_id": r["investigation_id"],
                    "actor_id": r["actor_id"],
                    "action": r["action"],
                    "object_type": r["object_type"],
                    "object_id": r["object_id"],
                    "reason": r["reason"],
                    "metadata": json.loads(r["metadata_json"] or "{}"),
                    "created_at": r["created_at"],
                }
                for r in rows
            ]
        if _conn is not None:
            return _query(_conn)
        with self._lock, self._connect() as conn:
            return _query(conn)

    def clear_investigation_artifacts_for_rerun(self, investigation_id: str) -> None:
        with self._lock, self._connect() as conn:
            conn.execute("DELETE FROM observations WHERE investigation_id = ?", (investigation_id,))
            conn.execute("DELETE FROM evidence_sources WHERE investigation_id = ?", (investigation_id,))
            conn.execute("DELETE FROM verdicts WHERE investigation_id = ?", (investigation_id,))
            conn.commit()


store = CounterCheckStore()
