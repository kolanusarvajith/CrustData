from __future__ import annotations
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class VerdictStatus(str, Enum):
    SUPPORTED = "SUPPORTED"
    CONTRADICTED = "CONTRADICTED"
    UNVERIFIED = "UNVERIFIED"
    CONFLICTING = "CONFLICTING"


@dataclass(frozen=True)
class VerificationResult:
    status: VerdictStatus
    explanation: str
    evidence_ids: tuple[str, ...]
    rule_version: str = "2.1.0"
    confidence_band: str = "MEDIUM"
    operands: dict[str, Any] = field(default_factory=dict)


_MULTIPLIERS = {
    "k": 1e3,
    "thousand": 1e3,
    "m": 1e6,
    "million": 1e6,
    "mm": 1e6,
    "mn": 1e6,
    "b": 1e9,
    "bn": 1e9,
    "billion": 1e9,
    "t": 1e12,
    "trillion": 1e12,
}


def parse_numeric_value(raw: Any) -> float | None:
    """Normalize numbers and shorthand strings like '$12.5M', '1,200', '~350', '6.6B' to float."""
    if raw is None or isinstance(raw, bool):
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    text = str(raw).strip()
    if not text:
        return None
    cleaned = re.sub(r"[,$€£¥~+≈]", "", text).strip()
    match = re.match(
        r"^([+-]?\d+(?:\.\d+)?)\s*(k|thousand|m|mm|mn|million|b|bn|billion|t|trillion)?(?:\s*(?:usd|eur|gbp|inr|employees|people|staff|openings|jobs|%))?$",
        cleaned,
        re.IGNORECASE,
    )
    if match:
        base = float(match.group(1))
        suffix = (match.group(2) or "").lower()
        return base * _MULTIPLIERS.get(suffix, 1.0)
    # Try extracting first number + multiplier from phrases like "over $10B in total funding"
    phrase_match = re.search(
        r"([+-]?\d+(?:,\d{3})*(?:\.\d+)?)\s*(k|thousand|m|mm|mn|million|b|bn|billion|t|trillion)?",
        text,
        re.IGNORECASE,
    )
    if phrase_match:
        num_str = phrase_match.group(1).replace(",", "")
        try:
            base = float(num_str)
            suffix = (phrase_match.group(2) or "").lower()
            return base * _MULTIPLIERS.get(suffix, 1.0)
        except ValueError:
            return None
    return None


def parse_numeric_range(raw: Any) -> tuple[float, float] | None:
    """Parse ranges like '51-200', '1,001 - 5,000', '100 to 250', '500+' into (low, high)."""
    if raw is None:
        return None
    text = str(raw).strip().replace(",", "")
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)
    if m:
        low, high = float(m.group(1)), float(m.group(2))
        return (min(low, high), max(low, high))
    m_plus = re.match(r"^(\d+(?:\.\d+)?)\s*\+$", text)
    if m_plus:
        low = float(m_plus.group(1))
        return (low, low * 2.5)
    return None


def verify_numeric_claim(
    claimed_value: float,
    observations: list[dict[str, Any]],
    *,
    tolerance: float = 0.0,
    relative_tolerance: float = 0.0,
    operator: str = "equals",
) -> VerificationResult:
    """Compare like-for-like numeric observations; never interpret missing data as contradiction."""
    usable = []
    for o in observations:
        if not o.get("comparable", True):
            continue
        val = parse_numeric_value(o.get("value"))
        if val is not None:
            usable.append({"value": val, "evidence_id": o.get("evidence_id"), "source_quality": o.get("source_quality", "provider_indexed")})
    if not usable:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "No comparable numeric observation was available in retrieved sources.",
            (),
            confidence_band="LOW",
            operands={"claimed_value": claimed_value, "observed_values": []},
        )
    values = [u["value"] for u in usable]
    ids = tuple(dict.fromkeys(str(u["evidence_id"]) for u in usable if u.get("evidence_id")))
    effective_tol = max(tolerance, abs(claimed_value) * relative_tolerance)

    def _matches(obs_val: float) -> bool:
        op = (operator or "equals").lower()
        if op in {"gte", ">=", "at_least", "greater_than_or_equal", "over", "more_than"}:
            return obs_val + effective_tol >= claimed_value
        if op in {"lte", "<=", "at_most", "less_than_or_equal", "under"}:
            return obs_val - effective_tol <= claimed_value
        if op in {"approx", "approximately", "around"}:
            return abs(obs_val - claimed_value) <= max(effective_tol, abs(claimed_value) * 0.15)
        return abs(obs_val - claimed_value) <= effective_tol

    match_flags = {_matches(v) for v in values}
    if len(match_flags) > 1 or (len(set(values)) > 1 and max(values) - min(values) > max(effective_tol * 2, 1e-6)):
        if True in match_flags and False in match_flags:
            return VerificationResult(
                VerdictStatus.CONFLICTING,
                f"Comparable observations disagree across sources ({', '.join(f'{v:g}' for v in sorted(set(values)))}) against claimed value {claimed_value:g}.",
                ids,
                confidence_band="LOW",
                operands={"claimed_value": claimed_value, "observed_values": values, "operator": operator},
            )
    observed = values[0]
    if _matches(observed):
        return VerificationResult(
            VerdictStatus.SUPPORTED,
            f"Observed value {observed:g} satisfies claimed {operator} {claimed_value:g} (tolerance ±{effective_tol:g}).",
            ids,
            confidence_band="HIGH" if len(ids) > 1 else "MEDIUM",
            operands={"claimed_value": claimed_value, "observed_value": observed, "tolerance": effective_tol},
        )
    return VerificationResult(
        VerdictStatus.CONTRADICTED,
        f"Observed value {observed:g} materially conflicts with the claim ({operator} {claimed_value:g}).",
        ids,
        confidence_band="HIGH" if len(ids) > 1 else "MEDIUM",
        operands={"claimed_value": claimed_value, "observed_value": observed, "tolerance": effective_tol},
    )
