from __future__ import annotations
import re
from typing import Any
from app.verification.rules import (
    VerificationResult,
    VerdictStatus,
    parse_numeric_range,
    parse_numeric_value,
    verify_numeric_claim,
)

_LOCATION_ALIASES = {
    "sf": "san francisco",
    "san francisco, ca": "san francisco",
    "san francisco, california": "san francisco",
    "san francisco, california, united states": "san francisco",
    "san francisco, ca, usa": "san francisco",
    "nyc": "new york",
    "new york city": "new york",
    "new york, ny": "new york",
    "new york, ny, usa": "new york",
    "bengaluru": "bangalore",
    "bengaluru, karnataka": "bangalore",
    "bangalore, india": "bangalore",
    "mumbai, maharashtra": "mumbai",
    "london, uk": "london",
    "london, united kingdom": "london",
    "dublin, ireland": "dublin",
}


def normalize_location(loc: str | None) -> str:
    if not loc:
        return ""
    cleaned = re.sub(r"\s+", " ", loc.strip().casefold())
    if cleaned in _LOCATION_ALIASES:
        return _LOCATION_ALIASES[cleaned]
    first_part = cleaned.split(",")[0].strip()
    return _LOCATION_ALIASES.get(first_part, first_part)


def compare_year_claim(
    claimed_year: int,
    observed_year: int | None,
    evidence_id: str | None,
    *,
    is_incorporation_vs_founding_mismatch: bool = False,
    secondary_observations: list[dict[str, Any]] | None = None,
) -> VerificationResult:
    if is_incorporation_vs_founding_mismatch:
        ids = (evidence_id,) if evidence_id else ()
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "Observed date reflects legal incorporation rather than public founding year; semantic definitions are not equivalent without explicit confirmation.",
            ids,
            confidence_band="LOW",
            operands={"claimed_year": claimed_year, "observed_year": observed_year},
        )
    all_years: list[tuple[int, str | None]] = []
    if observed_year is not None:
        all_years.append((int(observed_year), evidence_id))
    for sec in secondary_observations or []:
        y = parse_numeric_value(sec.get("value"))
        if y is not None and 1800 <= int(y) <= 2100:
            all_years.append((int(y), sec.get("evidence_id")))

    if not all_years:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "No founding-year observation was available.",
            (),
            confidence_band="LOW",
            operands={"claimed_year": claimed_year, "observed_year": None},
        )
    ids = tuple(dict.fromkeys(eid for _, eid in all_years if eid))
    unique_years = {y for y, _ in all_years}
    if len(unique_years) > 1:
        if claimed_year in unique_years:
            return VerificationResult(
                VerdictStatus.CONFLICTING,
                f"Sources report conflicting founding years ({', '.join(str(y) for y in sorted(unique_years))}) compared with claimed {claimed_year}.",
                ids,
                confidence_band="LOW",
                operands={"claimed_year": claimed_year, "observed_years": sorted(unique_years)},
            )
    primary_year = all_years[0][0]
    if claimed_year == primary_year:
        return VerificationResult(
            VerdictStatus.SUPPORTED,
            f"Observed founding year is {primary_year}, matching the claim.",
            ids,
            confidence_band="HIGH" if len(ids) > 1 else "MEDIUM",
            operands={"claimed_year": claimed_year, "observed_year": primary_year},
        )
    return VerificationResult(
        VerdictStatus.CONTRADICTED,
        f"Observed founding year is {primary_year}, not {claimed_year}.",
        ids,
        confidence_band="HIGH" if len(ids) > 1 else "MEDIUM",
        operands={"claimed_year": claimed_year, "observed_year": primary_year},
    )


def compare_headcount_claim(
    claimed_count: int | str,
    observed_headcount: int | None,
    evidence_id: str | None,
    *,
    observed_is_estimate: bool = True,
    observed_range: str | None = None,
    operator: str = "equals",
    tolerance_ratio: float = 0.12,
) -> VerificationResult:
    parsed_claim = parse_numeric_value(claimed_count)
    claim_range = parse_numeric_range(claimed_count)
    ids = (evidence_id,) if evidence_id else ()

    if observed_headcount is None and not observed_range:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "No headcount observation was available.",
            (),
            confidence_band="LOW",
        )

    suffix = " (provider estimate)" if observed_is_estimate else ""
    obs_interval = parse_numeric_range(observed_range) if observed_range else None

    if parsed_claim is not None and observed_headcount is not None:
        claimed_int = int(parsed_claim)
        if claimed_int == observed_headcount:
            return VerificationResult(
                VerdictStatus.SUPPORTED,
                f"Observed headcount is {observed_headcount}{suffix}.",
                ids,
                confidence_band="MEDIUM",
                operands={"claimed": claimed_int, "observed": observed_headcount},
            )
        op = (operator or "equals").lower()
        tol = max(5, int(claimed_int * tolerance_ratio)) if op in {"approx", "approximately", "around"} else 0
        if op in {"gte", ">=", "at_least", "over"} and observed_headcount + int(claimed_int * 0.1) >= claimed_int:
            return VerificationResult(
                VerdictStatus.SUPPORTED,
                f"Observed headcount is {observed_headcount:,}{suffix}, supporting the claim of {operator} {claimed_int:,}.",
                ids,
                confidence_band="MEDIUM",
                operands={"claimed": claimed_int, "observed": observed_headcount},
            )
        if tol > 0 and abs(observed_headcount - claimed_int) <= tol:
            return VerificationResult(
                VerdictStatus.SUPPORTED,
                f"Observed headcount is {observed_headcount:,}{suffix}, within ±{int(tolerance_ratio*100)}% tolerance of claimed {claimed_int:,}.",
                ids,
                confidence_band="MEDIUM",
                operands={"claimed": claimed_int, "observed": observed_headcount},
            )
        if obs_interval and obs_interval[0] <= claimed_int <= obs_interval[1]:
            return VerificationResult(
                VerdictStatus.SUPPORTED,
                f"Claimed headcount {claimed_int:,} falls within observed range {observed_range} (point estimate {observed_headcount:,}){suffix}.",
                ids,
                confidence_band="MEDIUM",
                operands={"claimed": claimed_int, "observed": observed_headcount, "range": observed_range},
            )
        contra_suffix = " (provider estimate; not an audited count)" if observed_is_estimate else ""
        return VerificationResult(
            VerdictStatus.CONTRADICTED,
            f"Observed headcount is {observed_headcount}{contra_suffix}, versus claim {claimed_int}.",
            ids,
            confidence_band="MEDIUM",
            operands={"claimed": claimed_int, "observed": observed_headcount},
        )

    if claim_range and observed_headcount is not None:
        if claim_range[0] <= observed_headcount <= claim_range[1]:
            return VerificationResult(
                VerdictStatus.SUPPORTED,
                f"Observed headcount {observed_headcount:,}{suffix} falls inside claimed interval {claimed_count}.",
                ids,
                confidence_band="MEDIUM",
            )
        return VerificationResult(
            VerdictStatus.CONTRADICTED,
            f"Observed headcount {observed_headcount:,}{suffix} is outside claimed interval {claimed_count}.",
            ids,
            confidence_band="MEDIUM",
        )

    return VerificationResult(
        VerdictStatus.UNVERIFIED,
        "Headcount claim format could not be compared deterministically with observed records.",
        ids,
        confidence_band="LOW",
    )


def compare_location_claim(
    claimed_location: str,
    observed_location: str | None,
    evidence_id: str | None,
    *,
    secondary_offices: list[str] | None = None,
) -> VerificationResult:
    if not observed_location:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "No headquarters observation was available.",
            (),
            confidence_band="LOW",
        )
    ids = (evidence_id,) if evidence_id else ()
    norm_claim = normalize_location(claimed_location)
    norm_obs = normalize_location(observed_location)
    if (
        claimed_location.casefold().strip() == observed_location.casefold().strip()
        or (norm_claim and norm_claim == norm_obs)
        or (norm_claim and norm_claim in observed_location.casefold())
        or (norm_obs and norm_obs in claimed_location.casefold())
    ):
        return VerificationResult(
            VerdictStatus.SUPPORTED,
            f"Observed headquarters is {observed_location}.",
            ids,
            confidence_band="HIGH",
            operands={"claimed_location": claimed_location, "observed_location": observed_location},
        )
    if secondary_offices:
        matched_office = next(
            (off for off in secondary_offices if normalize_location(off) == norm_claim or norm_claim in off.casefold()),
            None,
        )
        if matched_office:
            return VerificationResult(
                VerdictStatus.CONFLICTING,
                f"Observed primary headquarters is {observed_location}, while {matched_office} is listed as a regional office rather than global HQ.",
                ids,
                confidence_band="MEDIUM",
                operands={"claimed_location": claimed_location, "observed_hq": observed_location, "matched_office": matched_office},
            )
    return VerificationResult(
        VerdictStatus.CONTRADICTED,
        f"Observed headquarters is {observed_location}; compare location definitions before relying on this difference.",
        ids,
        confidence_band="MEDIUM",
        operands={"claimed_location": claimed_location, "observed_location": observed_location},
    )


def compare_funding_claim(
    claimed_amount_or_round: Any,
    observed_total_usd: float | None,
    evidence_ids: list[str],
    *,
    claim_metric: str = "total_funding",
    observed_last_round_type: str | None = None,
    observed_last_round_usd: float | None = None,
    operator: str = "equals",
) -> VerificationResult:
    ids = tuple(dict.fromkeys(e for e in evidence_ids if e))
    metric_lower = (claim_metric or "total_funding").casefold()
    claimed_num = parse_numeric_value(claimed_amount_or_round)
    claimed_str = str(claimed_amount_or_round or "").strip()

    # Guardrail Section 7.2: Never compare a single funding round with cumulative funding without explicit transformation
    is_single_round_claim = any(k in metric_lower or k in claimed_str.casefold() for k in ("series ", "seed", "last_round", "latest_round", "round_amount"))
    if is_single_round_claim and observed_last_round_usd is None and observed_last_round_type is None:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "Claim refers to a specific funding round, whereas available structured observations only report cumulative total funding. Refusing to compare single round against cumulative total.",
            ids,
            confidence_band="LOW",
            operands={"claimed": claimed_amount_or_round, "observed_total_usd": observed_total_usd},
        )

    if is_single_round_claim and observed_last_round_type and claimed_num is None:
        if observed_last_round_type.casefold() in claimed_str.casefold() or claimed_str.casefold() in observed_last_round_type.casefold():
            return VerificationResult(
                VerdictStatus.SUPPORTED,
                f"Observed latest funding stage ({observed_last_round_type}) matches the claimed round.",
                ids,
                confidence_band="HIGH",
            )
        return VerificationResult(
            VerdictStatus.CONTRADICTED,
            f"Observed latest funding stage is {observed_last_round_type}, which conflicts with claimed {claimed_str}.",
            ids,
            confidence_band="MEDIUM",
        )

    target_observed = observed_last_round_usd if (is_single_round_claim and observed_last_round_usd is not None) else observed_total_usd
    if target_observed is None or claimed_num is None:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "No comparable funding observation was available in provider or corroborated public records.",
            ids,
            confidence_band="LOW",
        )

    return verify_numeric_claim(
        claimed_num,
        [{"value": target_observed, "evidence_id": eid, "comparable": True} for eid in (ids or ("",))],
        relative_tolerance=0.10,
        operator=operator,
    )


def compare_leadership_claim(
    claim_text: str,
    claim_subject: str,
    claimed_value: Any,
    people_observations: list[dict[str, Any]],
) -> VerificationResult:
    """Verify executive/founder roles and prior employer history against Crustdata person records."""
    if not people_observations:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "No leadership or executive profile records were retrieved to evaluate this claim.",
            (),
            confidence_band="LOW",
        )
    ids = tuple(dict.fromkeys(str(p.get("evidence_id")) for p in people_observations if p.get("evidence_id")))
    combined_search = f"{claim_subject} {claimed_value} {claim_text}".casefold()

    matched_people = []
    for person in people_observations:
        name = str(person.get("name") or "").casefold()
        title = str(person.get("title") or "").casefold()
        if name and (name in combined_search or any(part in combined_search for part in name.split() if len(part) > 2)):
            matched_people.append(person)
        elif any(role in combined_search and role in title for role in ("ceo", "chief executive", "founder", "co-founder", "cto", "president", "cfo")):
            matched_people.append(person)

    if not matched_people:
        # Check if claim asserts a named person is CEO/Founder when another person holds that role
        if any(role in combined_search for role in ("ceo", "founder", "co-founder", "chief executive")):
            observed_leaders = [f"{p.get('name')} ({p.get('title')})" for p in people_observations if p.get("name")]
            if observed_leaders:
                return VerificationResult(
                    VerdictStatus.CONTRADICTED,
                    f"Claimed leadership assertion was not found among verified company executives: {', '.join(observed_leaders[:4])}.",
                    ids,
                    confidence_band="MEDIUM",
                    operands={"claimed": claim_text, "observed_leaders": observed_leaders},
                )
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "Named executive or role could not be unambiguously matched in retrieved Crustdata people profiles.",
            ids,
            confidence_band="LOW",
        )

    # Check if the claim is about prior employers or specific title
    claimed_str = str(claimed_value or "").casefold()
    for p in matched_people:
        p_name = p.get("name", "Executive")
        p_title = p.get("title", "")
        past_employers = [str(emp).casefold() for emp in (p.get("past_employers") or [])]
        all_profile_text = f"{p_name} {p_title} {' '.join(past_employers)} {p.get('summary', '')}".casefold()
        if not claimed_str or claimed_str in all_profile_text or any(tok in all_profile_text for tok in claimed_str.split() if len(tok) > 3):
            return VerificationResult(
                VerdictStatus.SUPPORTED,
                f"Verified executive profile for {p_name} ({p_title}; prior: {', '.join(p.get('past_employers') or ['N/A'])}) corroborates the claim.",
                ids,
                confidence_band="HIGH",
                operands={"matched_person": p_name, "title": p_title, "past_employers": p.get("past_employers", [])},
            )

    p0 = matched_people[0]
    return VerificationResult(
        VerdictStatus.CONTRADICTED,
        f"Verified employment history for {p0.get('name')} ({p0.get('title')}; prior employers: {', '.join(p0.get('past_employers') or ['None listed'])}) conflicts with claimed '{claimed_value}'.",
        ids,
        confidence_band="MEDIUM",
        operands={"matched_person": p0.get("name"), "observed_employers": p0.get("past_employers", []), "claimed": claimed_value},
    )


def compare_web_corroborated_claim(
    claim_text: str,
    claimed_value: Any,
    web_observations: list[dict[str, Any]],
) -> VerificationResult:
    """Verify partnership, compliance, or operating signal claims against web & job observations."""
    if not web_observations:
        return VerificationResult(
            VerdictStatus.UNVERIFIED,
            "No corroborating public web or operating signal evidence was found for this claim.",
            (),
            confidence_band="LOW",
        )
    ids = tuple(dict.fromkeys(str(w.get("evidence_id")) for w in web_observations if w.get("evidence_id")))
    support_obs = [w for w in web_observations if w.get("stance") == "supporting"]
    contra_obs = [w for w in web_observations if w.get("stance") == "contradicting"]

    if support_obs and contra_obs:
        return VerificationResult(
            VerdictStatus.CONFLICTING,
            f"Public sources disagree: {support_obs[0].get('summary', 'One source supports')} while {contra_obs[0].get('summary', 'another source contradicts')}.",
            ids,
            confidence_band="LOW",
        )
    if contra_obs:
        return VerificationResult(
            VerdictStatus.CONTRADICTED,
            f"Corroborating source contradicts claim: {contra_obs[0].get('summary')}",
            ids,
            confidence_band="MEDIUM",
        )
    if support_obs:
        independent = any(w.get("source_type") in {"independent_reporting", "regulatory_registry", "third_party_database"} for w in support_obs)
        caveat = "" if independent else " (Note: based on company-authored or self-reported announcement; independent corroboration recommended)"
        return VerificationResult(
            VerdictStatus.SUPPORTED,
            f"Public evidence supports claim: {support_obs[0].get('summary')}{caveat}",
            ids,
            confidence_band="HIGH" if independent else "MEDIUM",
        )
    return VerificationResult(
        VerdictStatus.UNVERIFIED,
        "Retrieved public web sources mention related entities but do not conclusively verify or refute this specific claim.",
        ids,
        confidence_band="LOW",
    )
