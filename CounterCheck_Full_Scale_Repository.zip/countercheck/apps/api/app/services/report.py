from __future__ import annotations
import hashlib
import json
from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, select
from sqlalchemy.orm import Mapped, mapped_column, Session
from app.core.database import Base


class ReportSnapshot(Base):
    __tablename__ = "reports"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    investigation_id: Mapped[str] = mapped_column(ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    content_json: Mapped[dict] = mapped_column(__import__("sqlalchemy").JSON, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


def create_report_snapshot(db: Session, investigation_id: str, payload: dict) -> ReportSnapshot:
    latest = db.scalar(select(ReportSnapshot).where(ReportSnapshot.investigation_id == investigation_id).order_by(ReportSnapshot.version.desc()))
    content = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    item = ReportSnapshot(investigation_id=investigation_id, version=(latest.version + 1 if latest else 1),
        content_json=payload, content_hash=hashlib.sha256(content.encode()).hexdigest())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item
