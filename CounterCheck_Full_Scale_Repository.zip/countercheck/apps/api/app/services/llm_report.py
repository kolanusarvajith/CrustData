from __future__ import annotations
from typing import Any
from app.integrations.llm.prompts import REPORT_SCHEMA
from app.integrations.llm.provider import LLMProvider


def validate_evidence_references(draft: dict[str, Any], allowed_evidence_ids: set[str]) -> dict[str, Any]:
    """Reject model-produced references that the backend did not provide (Section 7.4)."""
    cleaned = []
    for item in draft.get("key_findings", []):
        ids = item.get("evidence_ids", [])
        if not isinstance(ids, list) or any(not isinstance(i, str) or i not in allowed_evidence_ids for i in ids):
            continue
        if not item.get("text"):
            continue
        cleaned.append({"text": str(item["text"]), "evidence_ids": ids})
    return {
        "executive_summary": str(draft.get("executive_summary", "")),
        "key_findings": cleaned,
        "follow_up_questions": [str(q) for q in draft.get("follow_up_questions", []) if isinstance(q, str)],
    }


async def draft_report_narrative(
    llm: LLMProvider,
    verified_findings: list[dict[str, Any]],
    allowed_evidence_ids: set[str],
    *,
    allow_heuristic_fallback: bool = True,
) -> dict[str, Any]:
    draft = await llm.generate_structured(
        task="Draft cautious preliminary due-diligence narrative only from the verified results. Do not change verdicts or invent facts. Cite only supplied evidence IDs.",
        payload={"verified_findings": verified_findings},
        schema=REPORT_SCHEMA,
        allow_heuristic_fallback=allow_heuristic_fallback,
    )
    validated = validate_evidence_references(draft, allowed_evidence_ids)
    if draft.get("_llm_mode"):
        validated["_llm_mode"] = draft["_llm_mode"]
    return validated
