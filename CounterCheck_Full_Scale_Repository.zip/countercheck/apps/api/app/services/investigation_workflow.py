"""Full 9-stage CounterCheck investigation state machine and deterministic verification orchestrator."""
from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from typing import Any
from app.core.config import settings
from app.core.store import CounterCheckStore, store as default_store
from app.integrations.crustdata.client import CrustdataClient
from app.integrations.crustdata.schemas import normalize_identify_candidates, normalize_enriched_company, normalize_people_profiles
from app.integrations.llm.provider import OllamaProvider
from app.integrations.web.safety import classify_source_quality
from app.services.llm_report import draft_report_narrative
from app.verification.company_rules import (
    compare_funding_claim,
    compare_headcount_claim,
    compare_leadership_claim,
    compare_location_claim,
    compare_web_corroborated_claim,
    compare_year_claim,
)
from app.verification.rules import (
    VerificationResult,
    VerdictStatus,
    parse_numeric_value,
    verify_numeric_claim,
)

COMPANY_FIELDS = ["basic_info", "headcount", "funding", "locations", "hiring", "news"]


def evaluate_single_claim_against_observations(
    claim: dict[str, Any],
    observations: list[dict[str, Any]],
    people_profiles: list[dict[str, Any]],
    web_records: list[dict[str, Any]],
    company_evidence_id: str | None,
    people_evidence_id: str | None,
) -> VerificationResult:
    category = (claim.get("category") or "").casefold().strip()
    metric = (claim.get("metric") or "").casefold().strip()
    operator = claim.get("operator") or "equals"
    claimed_val = claim.get("claimed_value")
    orig_text = claim.get("original_text") or ""

    def _find_obs(field_suffix: str) -> dict[str, Any] | None:
        for o in observations:
            fp = (o.get("field_path") or "").casefold()
            if fp == field_suffix or fp.endswith(f".{field_suffix}"):
                return o
        return None

    # 1. Founding Year / Incorporation Date
    if category in {"founding_year", "year_founded", "incorporation_date"} or "year_founded" in metric or "founded" in metric:
        num = parse_numeric_value(claimed_val)
        if num is None:
            return VerificationResult(VerdictStatus.UNVERIFIED, "Claimed founding year is not a valid integer year.", ())
        obs_yr = _find_obs("year_founded")
        obs_inc = _find_obs("incorporation_year")
        is_inc_claim = "incorporat" in orig_text.casefold() or "incorporat" in metric
        if is_inc_claim and obs_inc and obs_yr and obs_inc.get("normalized_value") != obs_yr.get("normalized_value"):
            # Explicit incorporation date comparison
            return compare_year_claim(
                int(num),
                int(obs_inc["normalized_value"]),
                obs_inc.get("evidence_source_id") or company_evidence_id,
            )
        return compare_year_claim(
            int(num),
            int(obs_yr["normalized_value"]) if (obs_yr and obs_yr.get("normalized_value") is not None) else None,
            (obs_yr.get("evidence_source_id") if obs_yr else None) or company_evidence_id,
        )

    # 2. Headcount / Employee Count
    if category in {"headcount", "employee_count", "employees"} or "headcount" in metric or "employee" in metric:
        obs_hc = _find_obs("headcount.total") or _find_obs("total")
        obs_range = _find_obs("headcount.range") or _find_obs("range")
        return compare_headcount_claim(
            claimed_val,
            int(obs_hc["normalized_value"]) if (obs_hc and obs_hc.get("normalized_value") is not None) else None,
            (obs_hc.get("evidence_source_id") if obs_hc else None) or company_evidence_id,
            observed_is_estimate=True,
            observed_range=str(obs_range["normalized_value"]) if (obs_range and obs_range.get("normalized_value")) else None,
            operator=operator,
        )

    # 3. Headquarters / Location
    if category in {"location", "headquarters", "hq"} or "headquarters" in metric or "location" in metric:
        obs_hq = _find_obs("headquarters")
        obs_off = _find_obs("offices")
        offices_list = obs_off.get("normalized_value") if (obs_off and isinstance(obs_off.get("normalized_value"), list)) else []
        return compare_location_claim(
            str(claimed_val or orig_text),
            str(obs_hq["normalized_value"]) if (obs_hq and obs_hq.get("normalized_value")) else None,
            (obs_hq.get("evidence_source_id") if obs_hq else None) or company_evidence_id,
            secondary_offices=offices_list,
        )

    # 4. Funding / Investment
    if category in {"funding", "total_funding", "funding_round"} or "funding" in metric or "investment" in metric:
        obs_tot = _find_obs("total_investment_usd")
        obs_rt = _find_obs("last_funding_round_type")
        obs_ra = _find_obs("last_funding_round_amount_usd")
        eids = [
            x.get("evidence_source_id")
            for x in (obs_tot, obs_rt, obs_ra)
            if x and x.get("evidence_source_id")
        ]
        for w in web_records:
            if w.get("evidence_id") and any(k in (w.get("snippet") or "").casefold() for k in ("funding", "raised", "series", "billion", "million")):
                eids.append(w["evidence_id"])
        return compare_funding_claim(
            claimed_val if claimed_val is not None else orig_text,
            float(obs_tot["normalized_value"]) if (obs_tot and obs_tot.get("normalized_value") is not None) else None,
            [e for e in eids if e],
            claim_metric=f"{metric} {orig_text}",
            observed_last_round_type=str(obs_rt["normalized_value"]) if (obs_rt and obs_rt.get("normalized_value")) else None,
            observed_last_round_usd=float(obs_ra["normalized_value"]) if (obs_ra and obs_ra.get("normalized_value") is not None) else None,
            operator=operator,
        )

    # 5. Leadership / Executive History / Founders
    if category in {"leadership", "executive_history", "founder", "people"} or any(k in metric for k in ("executive", "founder", "ceo", "leadership")):
        enriched_people = [{**p, "evidence_id": p.get("evidence_id") or people_evidence_id} for p in people_profiles]
        return compare_leadership_claim(
            orig_text,
            str(claim.get("subject") or ""),
            claimed_val,
            enriched_people,
        )

    # 6. Hiring / Job Openings
    if category in {"hiring", "jobs", "job_openings", "operating_signal"} or "job" in metric or "hiring" in metric:
        obs_jobs = _find_obs("open_jobs_count")
        claimed_num = parse_numeric_value(claimed_val)
        if claimed_num is not None and obs_jobs and obs_jobs.get("normalized_value") is not None:
            return verify_numeric_claim(
                claimed_num,
                [{"value": obs_jobs["normalized_value"], "evidence_id": obs_jobs.get("evidence_source_id") or company_evidence_id, "comparable": True}],
                relative_tolerance=0.15,
                operator=operator,
            )

    # 7. Public Corroboration / Partnerships / Compliance / Fallback Numeric
    claimed_num = parse_numeric_value(claimed_val)
    if claimed_num is not None:
        matching_obs = [
            {"value": o["normalized_value"], "evidence_id": o["evidence_source_id"], "comparable": True}
            for o in observations
            if o.get("field_path", "").casefold().split(".")[-1] in {metric, category}
            and isinstance(o.get("normalized_value"), (int, float))
        ]
        if matching_obs:
            return verify_numeric_claim(claimed_num, matching_obs, operator=operator)

    return compare_web_corroborated_claim(orig_text, claimed_val, web_records)


def build_entity_relationship_graph(
    *,
    company_id: str,
    company_name: str,
    company_domain: str | None,
    company_blob: dict[str, Any],
    people: list[dict[str, Any]],
    web_sources: list[dict[str, Any]],
    company_evidence_id: str,
    people_evidence_id: str | None,
) -> dict[str, list[dict[str, Any]]]:
    """Construct evidence-backed nodes and edges (Section 8.6). Every edge references stored evidence IDs."""
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []

    comp_node_id = f"node_company_{company_id}"
    nodes.append({
        "id": comp_node_id,
        "type": "company",
        "label": company_name,
        "subtitle": company_domain or f"Crustdata #{company_id}",
        "evidence_ids": [company_evidence_id],
    })

    # Headquarters node
    hq = (company_blob.get("locations") or {}).get("headquarters")
    if hq:
        hq_node_id = "node_loc_hq"
        nodes.append({
            "id": hq_node_id,
            "type": "location",
            "label": str(hq).split(",")[0].strip(),
            "subtitle": str(hq),
            "evidence_ids": [company_evidence_id],
        })
        edges.append({
            "id": f"edge_hq_{company_id}",
            "source": comp_node_id,
            "target": hq_node_id,
            "relation": "headquartered_in",
            "temporal_label": "Current HQ",
            "evidence_ids": [company_evidence_id],
        })

    # Investors nodes
    investors = (company_blob.get("funding") or {}).get("investors") or []
    for idx, inv_name in enumerate(investors[:5]):
        inv_node_id = f"node_investor_{idx}"
        nodes.append({
            "id": inv_node_id,
            "type": "investor",
            "label": str(inv_name),
            "subtitle": "Institutional Investor",
            "evidence_ids": [company_evidence_id],
        })
        edges.append({
            "id": f"edge_inv_{idx}",
            "source": inv_node_id,
            "target": comp_node_id,
            "relation": "invested_in",
            "temporal_label": str((company_blob.get("funding") or {}).get("last_funding_round_type") or "Verified Round"),
            "evidence_ids": [company_evidence_id],
        })

    # Leadership & Past Employer nodes
    p_ev_id = people_evidence_id or company_evidence_id
    for idx, person in enumerate(people[:6]):
        p_node_id = f"node_person_{idx}"
        p_name = person.get("name") or f"Executive {idx+1}"
        p_title = person.get("title") or "Leadership"
        rel_type = "founded_by" if "founder" in p_title.casefold() else "employed_by"
        nodes.append({
            "id": p_node_id,
            "type": "person",
            "label": p_name,
            "subtitle": p_title,
            "profile_url": person.get("profile_url"),
            "evidence_ids": [p_ev_id],
        })
        edges.append({
            "id": f"edge_person_{idx}",
            "source": comp_node_id if rel_type == "founded_by" else p_node_id,
            "target": p_node_id if rel_type == "founded_by" else comp_node_id,
            "relation": rel_type,
            "temporal_label": f"Since {person.get('start_date') or 'verified'}",
            "evidence_ids": [p_ev_id],
        })
        for emp_idx, past_emp in enumerate((person.get("past_employers") or [])[:2]):
            emp_node_id = f"node_emp_{idx}_{emp_idx}"
            nodes.append({
                "id": emp_node_id,
                "type": "employer",
                "label": str(past_emp),
                "subtitle": f"Prior Employer ({p_name})",
                "evidence_ids": [p_ev_id],
            })
            edges.append({
                "id": f"edge_past_emp_{idx}_{emp_idx}",
                "source": p_node_id,
                "target": emp_node_id,
                "relation": "employed_by",
                "temporal_label": "Prior Role",
                "evidence_ids": [p_ev_id],
            })

    # Corroborating Web Sources nodes
    for idx, ws in enumerate(web_sources[:4]):
        ws_node_id = f"node_source_{idx}"
        w_ev_id = ws.get("evidence_id") or company_evidence_id
        nodes.append({
            "id": ws_node_id,
            "type": "source",
            "label": str(ws.get("publisher") or "Public Source"),
            "subtitle": str(ws.get("title") or "")[:48],
            "url": ws.get("url"),
            "evidence_ids": [w_ev_id],
        })
        edges.append({
            "id": f"edge_source_{idx}",
            "source": ws_node_id,
            "target": comp_node_id,
            "relation": "corroborated_by",
            "temporal_label": str(ws.get("source_type") or "public_web"),
            "evidence_ids": [w_ev_id],
        })

    return {"nodes": nodes, "edges": edges}


async def run_full_investigation_pipeline(
    investigation_id: str,
    *,
    selected_candidate_id: int | None = None,
    auto_select_top_candidate: bool = False,
    allow_fallback: bool | None = None,
    target_store: CounterCheckStore | None = None,
) -> dict[str, Any]:
    """Execute the 9-stage investigation pipeline with persisted checkpoints, SSE events, and credit tracking."""
    s = target_store or default_store
    inv = s.get_investigation(investigation_id)
    if inv is None:
        raise ValueError("Investigation not found")

    use_fallback = allow_fallback if allow_fallback is not None else settings.crustdata_demo_fallback
    s.clear_investigation_artifacts_for_rerun(investigation_id)
    s.update_investigation_state(investigation_id, status="running", cancel_requested=False)

    async with CrustdataClient(allow_fallback=use_fallback) as client:
        # STAGE 1: RESOLVING IDENTITY
        s.append_event(
            investigation_id,
            stage="resolving_identity",
            event_type="stage_started",
            status="running",
            message=f"Resolving canonical company identity for '{inv['company_identifier']}' via Crustdata /company/identify",
        )
        identity_resp = await client.identify_company(
            name=inv["company_name"] if not inv["company_domain"] else None,
            domain=inv["company_domain"],
        )
        s.record_credit(investigation_id, "/company/identify", estimated=0.0, actual=0.0, mode=client.call_history[-1].get("mode", "live") if client.call_history else "live")

        matches = normalize_identify_candidates(identity_resp)

        if not matches:
            s.append_event(
                investigation_id,
                stage="resolving_identity",
                event_type="identity_candidates",
                status="failed",
                message="No matching company candidates returned by Crustdata /company/identify.",
                details={"candidate_count": 0},
            )
            s.update_investigation_state(investigation_id, status="failed", candidates_json=[])
            return {"status": "failed", "candidates": []}

        # Check if disambiguation gate is triggered (AC-02)
        chosen_match = None
        if selected_candidate_id is not None:
            chosen_match = next((m for m in matches if int(m.get("id") or 0) == int(selected_candidate_id)), matches[0])
        elif len(matches) == 1 or auto_select_top_candidate:
            chosen_match = matches[0]
        else:
            s.update_investigation_state(
                investigation_id,
                status="needs_user_input",
                current_stage="awaiting_identity_confirmation",
                candidates_json=matches,
            )
            s.append_event(
                investigation_id,
                stage="awaiting_identity_confirmation",
                event_type="identity_candidates",
                status="needs_user_input",
                message=f"Ambiguous company identity: found {len(matches)} plausible candidates. Analyst confirmation required.",
                details={"candidate_count": len(matches), "candidates": matches},
            )
            return {"status": "needs_user_input", "candidates": matches}

        canonical_id = int(chosen_match["id"])
        canonical_name = chosen_match.get("name") or inv["company_name"] or inv["company_identifier"]
        canonical_domain = chosen_match.get("domain") or inv["company_domain"]
        s.update_investigation_state(
            investigation_id,
            company_crustdata_id=canonical_id,
            company_name=canonical_name,
            company_domain=canonical_domain,
            candidates_json=matches,
        )
        s.append_event(
            investigation_id,
            stage="resolving_identity",
            event_type="identity_resolved",
            status="running",
            message=f"Resolved canonical entity: {canonical_name} (Crustdata ID #{canonical_id}, domain: {canonical_domain})",
            details={"crustdata_company_id": canonical_id, "confidence": chosen_match.get("confidence")},
        )

        # STAGE 2: PLANNING
        s.append_event(
            investigation_id,
            stage="planning",
            event_type="stage_started",
            status="running",
            message=f"Planning deterministic retrieval across {len(inv['claims'])} claims within {settings.crustdata_max_estimated_credits_per_investigation} credit cap.",
        )

        # Check cooperative cancellation
        latest_inv = s.get_investigation(investigation_id)
        if latest_inv and latest_inv.get("cancel_requested"):
            s.update_investigation_state(investigation_id, status="cancelled")
            s.append_event(investigation_id, stage="cancelled", event_type="investigation_cancelled", status="cancelled", message="Investigation cancelled by user.")
            return {"status": "cancelled"}

        # STAGE 3: RETRIEVING COMPANY PROFILE
        s.update_investigation_state(investigation_id, status="retrieving_company")
        s.append_event(
            investigation_id,
            stage="retrieving_company",
            event_type="stage_started",
            status="running",
            message=f"Enriching company #{canonical_id} via Crustdata /company/enrich (fields: {', '.join(COMPANY_FIELDS)})",
        )
        enrichment = await client.enrich_company(
            company_id=canonical_id,
            fields=COMPANY_FIELDS,
            name_hint=canonical_name,
            domain_hint=canonical_domain,
        )
        s.record_credit(investigation_id, "/company/enrich", estimated=2.0, actual=2.0, mode=client.call_history[-1].get("mode", "live"))

        company_blob = normalize_enriched_company(enrichment, canonical_id, canonical_name, canonical_domain)

        comp_source = s.create_evidence_source(
            investigation_id,
            {
                "id": f"ev_comp_{canonical_id}",
                "provider": "crustdata",
                "provider_entity_id": str(canonical_id),
                "source_url": f"https://api.crustdata.com/company/enrich?id={canonical_id}",
                "source_title": f"Crustdata Canonical Company Enrichment — {canonical_name} (#{canonical_id})",
                "publisher": "Crustdata Canonical Graph",
                "source_quality": "provider_indexed",
                "limitations": "Provider-indexed company record; headcount and private funding metrics may be estimated or periodically refreshed.",
                "raw_payload": company_blob,
            },
        )

        basic_info = company_blob.get("basic_info") or {}
        hc_info = company_blob.get("headcount") or {}
        fund_info = company_blob.get("funding") or {}
        loc_info = company_blob.get("locations") or {}
        hiring_info = company_blob.get("hiring") or {}

        company_facts = [
            ("basic_info.year_founded", basic_info.get("year_founded"), "year"),
            ("basic_info.incorporation_year", basic_info.get("incorporation_year"), "year"),
            ("basic_info.primary_domain", basic_info.get("primary_domain"), None),
            ("headcount.total", hc_info.get("total"), "employees"),
            ("headcount.range", hc_info.get("range"), "employees"),
            ("headcount.yoy_growth_pct", hc_info.get("yoy_growth_pct"), "percent"),
            ("funding.total_investment_usd", fund_info.get("total_investment_usd"), "USD"),
            ("funding.last_funding_round_type", fund_info.get("last_funding_round_type"), None),
            ("funding.last_funding_round_amount_usd", fund_info.get("last_funding_round_amount_usd"), "USD"),
            ("locations.headquarters", loc_info.get("headquarters"), None),
            ("locations.offices", loc_info.get("offices"), None),
            ("hiring.open_jobs_count", hiring_info.get("open_jobs_count"), "jobs"),
        ]
        for field_path, val, unit in company_facts:
            if val is not None:
                s.create_observation(
                    investigation_id,
                    {
                        "evidence_source_id": comp_source["id"],
                        "entity_provider_id": str(canonical_id),
                        "field_path": field_path,
                        "raw_value": val,
                        "normalized_value": val,
                        "unit": unit,
                    },
                )

        s.append_event(
            investigation_id,
            stage="retrieving_company",
            event_type="stage_completed",
            status="running",
            message=f"Company enrichment normalized ({sum(1 for _, v, _ in company_facts if v is not None)} structured observations stored).",
        )

        # STAGE 4: RETRIEVING PEOPLE & LEADERSHIP
        s.update_investigation_state(investigation_id, status="retrieving_people")
        s.append_event(
            investigation_id,
            stage="retrieving_people",
            event_type="stage_started",
            status="running",
            message="Discovering founders and executive leadership via Crustdata /person/search and /person/enrich",
        )
        people_resp = await client.search_people(company_id=canonical_id, limit=8, name_hint=canonical_name)
        deduped_people = normalize_people_profiles(people_resp)
        s.record_credit(
            investigation_id,
            "/person/search",
            estimated=round(0.03 * max(len(deduped_people), 1), 2),
            actual=round(0.03 * max(len(deduped_people), 1), 2),
            mode=client.call_history[-1].get("mode", "live"),
        )

        people_source = s.create_evidence_source(
            investigation_id,
            {
                "id": f"ev_people_{canonical_id}",
                "provider": "crustdata",
                "provider_entity_id": str(canonical_id),
                "source_url": f"https://api.crustdata.com/person/search?company_id={canonical_id}",
                "source_title": f"Crustdata Executive & Leadership Profiles — {canonical_name} ({len(deduped_people)} verified profiles)",
                "publisher": "Crustdata People Graph",
                "source_quality": "provider_indexed",
                "limitations": "Professional network employment timelines may reflect self-reported role dates.",
                "raw_payload": deduped_people,
            },
        )
        for idx, person in enumerate(deduped_people):
            person["evidence_id"] = people_source["id"]
            s.create_observation(
                investigation_id,
                {
                    "evidence_source_id": people_source["id"],
                    "entity_provider_id": str(person.get("person_id") or f"person_{idx}"),
                    "field_path": f"leadership.profile.{idx}",
                    "raw_value": person,
                    "normalized_value": {
                        "name": person.get("name"),
                        "title": person.get("title"),
                        "past_employers": person.get("past_employers") or [],
                        "start_date": person.get("start_date"),
                    },
                },
            )

        # STAGE 5: RESEARCHING JOBS & PUBLIC WEB CORROBORATION
        s.update_investigation_state(investigation_id, status="researching_web")
        s.append_event(
            investigation_id,
            stage="researching_web",
            event_type="stage_started",
            status="running",
            message="Gathering operating signals (/job/search) and public web corroboration (/web/search/live)",
        )
        jobs_resp = await client.search_jobs(company_id=canonical_id, limit=10, name_hint=canonical_name)
        jobs_list = jobs_resp.get("jobs", []) if isinstance(jobs_resp, dict) else []
        s.record_credit(
            investigation_id,
            "/job/search",
            estimated=round(0.03 * max(len(jobs_list), 1), 2),
            actual=round(0.03 * max(len(jobs_list), 1), 2),
            mode=client.call_history[-1].get("mode", "live"),
        )

        web_resp = await client.web_search(
            f"{canonical_name} funding headcount leadership headquarters",
            company_id=canonical_id,
            name_hint=canonical_name,
        )
        web_results = web_resp.get("results", []) if isinstance(web_resp, dict) else []
        s.record_credit(
            investigation_id,
            "/web/search/live",
            estimated=1.0,
            actual=1.0 if web_results else 0.0,
            mode=client.call_history[-1].get("mode", "live"),
        )

        normalized_web_records: list[dict[str, Any]] = []
        for idx, w in enumerate(web_results[:5]):
            if not isinstance(w, dict):
                continue
            w_url = w.get("url")
            sq_type, sq_lim = classify_source_quality(w_url, canonical_domain)
            w_source = s.create_evidence_source(
                investigation_id,
                {
                    "id": f"ev_web_{canonical_id}_{idx+1}",
                    "provider": "crustdata_web",
                    "provider_entity_id": str(canonical_id),
                    "source_url": w_url,
                    "source_title": w.get("title") or f"Public Web Corroboration #{idx+1}",
                    "publisher": w.get("publisher") or "Public Web Source",
                    "source_quality": w.get("source_type") or sq_type,
                    "published_at": w.get("published_at"),
                    "limitations": sq_lim,
                    "raw_payload": w,
                },
            )
            rec = {
                "evidence_id": w_source["id"],
                "url": w_url,
                "title": w.get("title"),
                "publisher": w.get("publisher"),
                "snippet": w.get("snippet"),
                "summary": w.get("snippet"),
                "stance": w.get("stance") or "supporting",
                "source_type": w.get("source_type") or sq_type,
            }
            normalized_web_records.append(rec)
            s.create_observation(
                investigation_id,
                {
                    "evidence_source_id": w_source["id"],
                    "entity_provider_id": str(canonical_id),
                    "field_path": f"web.corroboration.{idx}",
                    "raw_value": w.get("snippet"),
                    "normalized_value": rec,
                },
            )

        # STAGE 6: NORMALIZING & ENTITY GRAPH CONSTRUCTION
        s.update_investigation_state(investigation_id, status="normalizing")
        graph = build_entity_relationship_graph(
            company_id=str(canonical_id),
            company_name=canonical_name,
            company_domain=canonical_domain,
            company_blob=company_blob,
            people=deduped_people,
            web_sources=normalized_web_records,
            company_evidence_id=comp_source["id"],
            people_evidence_id=people_source["id"],
        )
        s.update_investigation_state(
            investigation_id,
            company_profile_json=company_blob,
            people_json=deduped_people,
            jobs_json=jobs_list,
            graph_json=graph,
        )
        s.append_event(
            investigation_id,
            stage="normalizing",
            event_type="stage_completed",
            status="running",
            message=f"Constructed evidence-backed entity relationship graph ({len(graph['nodes'])} nodes, {len(graph['edges'])} edges).",
        )

        # STAGE 7: DETERMINISTIC CLAIM VERIFICATION
        s.update_investigation_state(investigation_id, status="verifying")
        all_obs = s.list_observations(investigation_id)
        current_inv = s.get_investigation(investigation_id)
        claims_list = (current_inv or {}).get("claims", [])
        verified_findings_for_llm: list[dict[str, Any]] = []
        allowed_evidence_ids = {src["id"] for src in s.list_evidence_sources(investigation_id)}

        for clm in claims_list:
            vres = evaluate_single_claim_against_observations(
                clm,
                all_obs,
                deduped_people,
                normalized_web_records,
                comp_source["id"],
                people_source["id"],
            )
            valid_eids = [eid for eid in vres.evidence_ids if eid in allowed_evidence_ids]
            if not valid_eids and comp_source["id"] in allowed_evidence_ids and vres.status != VerdictStatus.UNVERIFIED:
                valid_eids = [comp_source["id"]]
            s.upsert_verdict(
                claim_id=clm["id"],
                investigation_id=investigation_id,
                status=vres.status.value,
                explanation=vres.explanation,
                confidence_band=vres.confidence_band,
                rule_version=vres.rule_version,
                evidence_ids=valid_eids,
                operands=vres.operands,
            )
            verified_findings_for_llm.append({
                "claim_id": clm["id"],
                "category": clm["category"],
                "original_text": clm["original_text"],
                "status": vres.status.value,
                "explanation": vres.explanation,
                "confidence_band": vres.confidence_band,
                "evidence_ids": valid_eids,
            })

        s.append_event(
            investigation_id,
            stage="verifying",
            event_type="stage_completed",
            status="running",
            message=f"Deterministic verification completed across {len(claims_list)} claims (rule engine v2.1.0).",
        )

        # STAGE 8: QUALITY CHECK
        s.update_investigation_state(investigation_id, status="quality_check")
        warnings: list[str] = []
        if any(f["status"] == "CONTRADICTED" for f in verified_findings_for_llm):
            warnings.append("Material contradictions detected between submitted claims and verified provider/registry observations.")
        if any(f["status"] == "UNVERIFIED" for f in verified_findings_for_llm):
            warnings.append("One or more claims remain UNVERIFIED due to absent or non-comparable external evidence; missing data is not treated as contradiction.")
        if not any(w.get("source_type") in {"independent_reporting", "regulatory_registry"} for w in normalized_web_records):
            warnings.append("Limited independent press or registry corroboration; primary reliance on provider-indexed records.")
        s.update_investigation_state(investigation_id, quality_warnings_json=warnings)

        # STAGE 9: DRAFTING REPORT & SNAPSHOT
        s.update_investigation_state(investigation_id, status="drafting_report")
        llm = OllamaProvider()
        narrative = await draft_report_narrative(
            llm,
            verified_findings_for_llm,
            allowed_evidence_ids,
            allow_heuristic_fallback=True,
        )
        refreshed_inv = s.get_investigation(investigation_id) or inv
        report_payload = {
            "investigation_id": investigation_id,
            "company_name": canonical_name,
            "company_domain": canonical_domain,
            "company_crustdata_id": canonical_id,
            "purpose": refreshed_inv.get("purpose"),
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "model_version": settings.llm_model,
            "llm_mode": narrative.get("_llm_mode", "ollama_live"),
            "rule_version": "2.1.0",
            "executive_summary": narrative["executive_summary"],
            "key_findings": narrative["key_findings"],
            "follow_up_questions": narrative["follow_up_questions"],
            "quality_warnings": warnings,
            "claims": [
                {
                    "id": c["id"],
                    "category": c["category"],
                    "subject": c["subject"],
                    "metric": c["metric"],
                    "claimed_value": c["claimed_value"],
                    "original_text": c["original_text"],
                    "verdict": (c.get("verdict") or {}).get("status", "UNVERIFIED"),
                    "confidence_band": (c.get("verdict") or {}).get("confidence_band", "LOW"),
                    "explanation": (c.get("verdict") or {}).get("explanation", "Not verified"),
                    "evidence_ids": (c.get("verdict") or {}).get("evidence_ids", []),
                    "human_review": c.get("human_review"),
                }
                for c in (refreshed_inv.get("claims") or [])
            ],
            "evidence_sources": s.list_evidence_sources(investigation_id),
            "people": deduped_people,
            "credit_usage": s.list_credits(investigation_id),
            "limitations": [
                "Preliminary due-diligence research support only; not a legal opinion, audited financial review, credit decision, or fraud certification.",
                "Crustdata records and public webpages can be incomplete, stale, estimated, duplicated, or self-reported.",
                "Deterministic verification rules are authoritative; the LLM is restricted to bounded narrative synthesis and cannot alter verdicts.",
            ],
        }
        snapshot = s.create_report_snapshot(investigation_id, report_payload)

        s.update_investigation_state(investigation_id, status="completed", current_stage="completed")
        s.append_event(
            investigation_id,
            stage="completed",
            event_type="investigation_completed",
            status="completed",
            message=f"Investigation dossier completed (Report Snapshot v{snapshot['version']}, SHA-256: {snapshot['content_hash'][:12]}).",
            details={"report_version": snapshot["version"], "content_hash": snapshot["content_hash"]},
        )
        return s.get_investigation(investigation_id)  # type: ignore[return-value]


# Compatibility wrapper for existing tests / routes calling resolve_and_enrich
async def resolve_and_enrich(investigation_id: str, db: Any = None) -> dict[str, Any]:
    return await run_full_investigation_pipeline(investigation_id, auto_select_top_candidate=False)


def seed_evaluation_investigations_if_empty(target_store: CounterCheckStore | None = None) -> None:
    """Seed 3 pre-verified evaluation investigations (Section 15.2) if the database has no investigations yet."""
    s = target_store or default_store
    if s.list_investigations(limit=1):
        return

    scenarios = [
        {
            "company_name": "Stripe",
            "company_domain": "stripe.com",
            "purpose": "Enterprise Vendor & FinTech Counterparty Due Diligence",
            "claims": [
                {
                    "category": "founding_year",
                    "subject": "Stripe",
                    "metric": "year_founded",
                    "operator": "equals",
                    "claimed_value": 2010,
                    "unit": "year",
                    "period": "2010",
                    "original_text": "Stripe was founded in 2010 by Patrick and John Collison.",
                },
                {
                    "category": "headcount",
                    "subject": "Stripe",
                    "metric": "headcount.total",
                    "operator": "approx",
                    "claimed_value": 8000,
                    "unit": "employees",
                    "period": "current",
                    "original_text": "Stripe operates globally with approximately 8,000 full-time employees.",
                },
                {
                    "category": "funding",
                    "subject": "Stripe",
                    "metric": "total_investment_usd",
                    "operator": "approx",
                    "claimed_value": "$9.4B",
                    "unit": "USD",
                    "period": "cumulative",
                    "original_text": "Stripe has raised approximately $9.4 billion in cumulative institutional funding.",
                },
                {
                    "category": "leadership",
                    "subject": "Steffan Tomlinson",
                    "metric": "executive_history",
                    "operator": "contains",
                    "claimed_value": "Confluent",
                    "unit": None,
                    "period": "prior",
                    "original_text": "CFO Steffan Tomlinson previously served as CFO at Confluent and Google Cloud.",
                },
            ],
        },
        {
            "company_name": "Meridian Quantum Logistics Ltd.",
            "company_domain": "meridian-q-logistics.io",
            "purpose": "High-Risk Supplier Onboarding & Shell Company Screening",
            "claims": [
                {
                    "category": "founding_year",
                    "subject": "Meridian Quantum Logistics Ltd.",
                    "metric": "year_founded",
                    "operator": "equals",
                    "claimed_value": 2016,
                    "unit": "year",
                    "period": "2016",
                    "original_text": "Vendor pitch states Meridian Quantum Logistics has operated since 2016.",
                },
                {
                    "category": "headcount",
                    "subject": "Meridian Quantum Logistics Ltd.",
                    "metric": "headcount.total",
                    "operator": "gte",
                    "claimed_value": 450,
                    "unit": "employees",
                    "period": "current",
                    "original_text": "Vendor claims over 450 full-time logistics staff across Europe.",
                },
                {
                    "category": "location",
                    "subject": "Meridian Quantum Logistics Ltd.",
                    "metric": "headquarters",
                    "operator": "equals",
                    "claimed_value": "Zurich, Switzerland",
                    "unit": None,
                    "period": "current",
                    "original_text": "Company states its global headquarters is located in Zurich, Switzerland.",
                },
                {
                    "category": "funding",
                    "subject": "Meridian Quantum Logistics Ltd.",
                    "metric": "total_investment_usd",
                    "operator": "equals",
                    "claimed_value": "$85M",
                    "unit": "USD",
                    "period": "cumulative",
                    "original_text": "Vendor claims $85M in institutional Series B funding.",
                },
                {
                    "category": "leadership",
                    "subject": "Arthur Vance",
                    "metric": "executive_history",
                    "operator": "contains",
                    "claimed_value": "Maersk",
                    "unit": None,
                    "period": "prior",
                    "original_text": "Managing Director Arthur Vance claims 10 years as VP of Operations at Maersk.",
                },
            ],
        },
        {
            "company_name": "Anthropic",
            "company_domain": "anthropic.com",
            "purpose": "VC Growth Investment & AI Governance Review",
            "claims": [
                {
                    "category": "founding_year",
                    "subject": "Anthropic",
                    "metric": "year_founded",
                    "operator": "equals",
                    "claimed_value": 2021,
                    "unit": "year",
                    "period": "2021",
                    "original_text": "Anthropic PBC was founded in 2021.",
                },
                {
                    "category": "leadership",
                    "subject": "Dario Amodei",
                    "metric": "executive_history",
                    "operator": "contains",
                    "claimed_value": "OpenAI",
                    "unit": None,
                    "period": "prior",
                    "original_text": "Co-founders Dario Amodei and Daniela Amodei previously held leadership roles at OpenAI.",
                },
                {
                    "category": "funding",
                    "subject": "Anthropic",
                    "metric": "total_investment_usd",
                    "operator": "gte",
                    "claimed_value": "$10B",
                    "unit": "USD",
                    "period": "cumulative",
                    "original_text": "Anthropic has raised over $10 billion in total strategic and venture capital.",
                },
                {
                    "category": "location",
                    "subject": "Anthropic",
                    "metric": "headquarters",
                    "operator": "equals",
                    "claimed_value": "London, UK",
                    "unit": None,
                    "period": "current",
                    "original_text": "Claim states Anthropic's primary global headquarters is in London, UK.",
                },
            ],
        },
    ]

    for scen in scenarios:
        created = s.create_investigation(
            company_name=scen["company_name"],
            company_domain=scen["company_domain"],
            purpose=scen["purpose"],
            claims=scen["claims"],
        )
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.ensure_future(run_full_investigation_pipeline(created["id"], auto_select_top_candidate=True, allow_fallback=True, target_store=s))
            else:
                loop.run_until_complete(run_full_investigation_pipeline(created["id"], auto_select_top_candidate=True, allow_fallback=True, target_store=s))
        except RuntimeError:
            asyncio.run(run_full_investigation_pipeline(created["id"], auto_select_top_candidate=True, allow_fallback=True, target_store=s))
