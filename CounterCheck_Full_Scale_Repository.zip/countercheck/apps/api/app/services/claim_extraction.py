from __future__ import annotations
from typing import Any
from app.integrations.llm.prompts import CLAIM_EXTRACTION_SCHEMA
from app.integrations.llm.provider import LLMProvider


async def extract_claims(
    llm: LLMProvider,
    company: str,
    free_text: str,
    *,
    allow_heuristic_fallback: bool = True,
) -> dict[str, Any]:
    if not free_text.strip():
        raise ValueError("Claim text cannot be empty")
    return await llm.generate_structured(
        task="Extract factual, testable claims about the named company. Preserve wording; mark ambiguity instead of guessing.",
        payload={"company": company, "claim_text": free_text},
        schema=CLAIM_EXTRACTION_SCHEMA,
        allow_heuristic_fallback=allow_heuristic_fallback,
    )
