from dataclasses import dataclass


@dataclass(frozen=True)
class CreditEstimate:
    endpoint: str
    expected_records: int
    base_credits_per_record: float
    premium_credits_per_record: float = 0.0

    @property
    def total(self) -> float:
        return self.expected_records * (self.base_credits_per_record + self.premium_credits_per_record)


# Prices are account-observed as of 2026-10-31; revalidate via get_plan_access before production.
ACCOUNT_PRICE_BASELINE = {
    "/company/identify": 0.0,
    "/company/enrich": 2.0,
    "/company/search": 0.03,
    "/person/search": 0.03,
    "/person/enrich": 1.0,
    "/job/search": 0.03,
    "/web/search/live": 1.0,
    "/web/enrich/live": 1.0,
}


def estimate_default_company_investigation(*, people_count: int = 5, web_queries: int = 2, pages: int = 3) -> float:
    if min(people_count, web_queries, pages) < 0:
        raise ValueError("Counts cannot be negative")
    # Does not include premium profile/experience/funding fields or retries.
    return 2.0 + people_count * (0.03 + 0.1 + 1.0) + web_queries * 1.0 + pages * 1.0
