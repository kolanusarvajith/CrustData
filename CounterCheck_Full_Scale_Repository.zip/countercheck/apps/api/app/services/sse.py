from __future__ import annotations
import asyncio
import json
from collections.abc import AsyncIterator
from app.core.store import CounterCheckStore, store as default_store


async def event_stream(
    investigation_id: str,
    *,
    after: int = 0,
    poll_seconds: float = 0.5,
    max_polls: int = 120,
    target_store: CounterCheckStore | None = None,
) -> AsyncIterator[str]:
    """SSE stream with sequence replay and terminal-state completion."""
    s = target_store or default_store
    last = after
    polls = 0
    while polls < max_polls:
        polls += 1
        rows = s.list_events(investigation_id, after=last)
        for event in rows:
            last = int(event["sequence"])
            yield f"id: {last}\nevent: progress\ndata: {json.dumps(event, default=str)}\n\n"
        inv = s.get_investigation(investigation_id)
        if inv and inv["status"] in {"completed", "failed", "cancelled", "needs_user_input"}:
            break
        yield ": keep-alive\n\n"
        await asyncio.sleep(poll_seconds)
