from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import DateTime, Float, ForeignKey, String, select
from sqlalchemy.orm import Mapped, mapped_column, Session
from app.core.database import Base


class CreditLedgerEntry(Base):
    __tablename__ = "credit_ledger"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    investigation_id: Mapped[str] = mapped_column(ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False)
    provider: Mapped[str] = mapped_column(String(40), nullable=False, default="crustdata")
    endpoint: Mapped[str] = mapped_column(String(128), nullable=False)
    estimated_credits: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    actual_credits: Mapped[float | None] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


def record_credit(db: Session, investigation_id: str, endpoint: str, estimated: float, actual: float | None = None) -> CreditLedgerEntry:
    if estimated < 0 or (actual is not None and actual < 0):
        raise ValueError("Credit values cannot be negative")
    entry = CreditLedgerEntry(investigation_id=investigation_id, endpoint=endpoint,
        estimated_credits=estimated, actual_credits=actual)
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def list_credit_entries(db: Session, investigation_id: str) -> list[CreditLedgerEntry]:
    return list(db.scalars(select(CreditLedgerEntry).where(CreditLedgerEntry.investigation_id == investigation_id).order_by(CreditLedgerEntry.created_at)))
