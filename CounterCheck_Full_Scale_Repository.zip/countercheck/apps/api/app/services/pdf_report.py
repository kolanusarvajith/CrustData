"""Traceable multi-section PDF Dossier exporter built on ReportLab."""
from __future__ import annotations
from io import BytesIO
from typing import Any
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def render_report_pdf(report: dict[str, Any]) -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=15 * mm,
        leftMargin=15 * mm,
        topMargin=15 * mm,
        bottomMargin=15 * mm,
        title=f"CounterCheck Dossier - {report.get('company_name') or 'Investigation'}",
    )
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="CCBanner",
            parent=styles["Title"],
            fontSize=18,
            leading=22,
            alignment=0,
            textColor=colors.HexColor("#0F172A"),
            spaceAfter=2 * mm,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CCSub",
            parent=styles["BodyText"],
            fontSize=10,
            leading=14,
            textColor=colors.HexColor("#334155"),
            spaceAfter=4 * mm,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CCSection",
            parent=styles["Heading2"],
            fontSize=12,
            leading=16,
            textColor=colors.HexColor("#0F172A"),
            spaceBefore=4 * mm,
            spaceAfter=2 * mm,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CCSmall",
            parent=styles["BodyText"],
            fontSize=8,
            leading=11,
            textColor=colors.HexColor("#334155"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="CCMeta",
            parent=styles["BodyText"],
            fontSize=7.5,
            leading=10,
            textColor=colors.HexColor("#64748B"),
        )
    )

    story = [
        Paragraph("COUNTERCHECK · TRUST &amp; COMPLIANCE DOSSIER", styles["CCBanner"]),
        Paragraph("Evidence-First Business Due Diligence &amp; Deterministic Claim Verification Report", styles["CCSub"]),
    ]

    meta_rows = [
        [
            Paragraph(f"<b>Target Entity:</b> {escape(str(report.get('company_name') or 'Unresolved'))}", styles["CCSmall"]),
            Paragraph(f"<b>Canonical Domain:</b> {escape(str(report.get('company_domain') or 'N/A'))}", styles["CCSmall"]),
            Paragraph(f"<b>Crustdata ID:</b> {escape(str(report.get('company_crustdata_id') or 'N/A'))}", styles["CCSmall"]),
        ],
        [
            Paragraph(f"<b>Investigation ID:</b> {escape(str(report.get('investigation_id') or ''))}", styles["CCSmall"]),
            Paragraph(f"<b>Generated At:</b> {escape(str(report.get('generated_at') or '')[:19])}", styles["CCSmall"]),
            Paragraph(f"<b>Rule / Model:</b> v{escape(str(report.get('rule_version') or '2.1.0'))} · {escape(str(report.get('model_version') or 'ollama'))}", styles["CCSmall"]),
        ],
    ]
    meta_table = Table(meta_rows, colWidths=[62 * mm, 58 * mm, 60 * mm])
    meta_table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F8FAFC")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ("INNERGRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#E2E8F0")),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ])
    )
    story.append(meta_table)
    story.append(Spacer(1, 3 * mm))

    story.append(Paragraph("1. Executive Summary", styles["CCSection"]))
    story.append(Paragraph(escape(str(report.get("executive_summary") or "No summary available.")), styles["BodyText"]))

    claims_data = [[
        Paragraph("<b>Claim &amp; Category</b>", styles["CCSmall"]),
        Paragraph("<b>System Verdict</b>", styles["CCSmall"]),
        Paragraph("<b>Deterministic Explanation &amp; Provenance</b>", styles["CCSmall"]),
        Paragraph("<b>Human Review</b>", styles["CCSmall"]),
    ]]
    for c in report.get("claims", []):
        verdict_str = str(c.get("verdict") or "UNVERIFIED")
        conf_str = str(c.get("confidence_band") or "MEDIUM")
        eids = ", ".join(str(x) for x in (c.get("evidence_ids") or []))
        hr = c.get("human_review")
        hr_text = "Pending Review"
        if isinstance(hr, dict) and hr.get("disposition"):
            hr_text = f"{hr['disposition'].upper()}"
            if hr.get("override_status"):
                hr_text += f" -> {hr['override_status']}"
            if hr.get("override_reason"):
                hr_text += f" ({hr['override_reason'][:45]})"
        claims_data.append([
            Paragraph(f"<b>[{escape(str(c.get('category', 'fact')).upper())}]</b><br/>{escape(str(c.get('original_text', '')))}", styles["CCSmall"]),
            Paragraph(f"<b>{escape(verdict_str)}</b><br/>Conf: {escape(conf_str)}", styles["CCSmall"]),
            Paragraph(f"{escape(str(c.get('explanation', '')))}<br/><i>Sources: {escape(eids or 'None')}</i>", styles["CCSmall"]),
            Paragraph(escape(hr_text), styles["CCSmall"]),
        ])

    if len(claims_data) > 1:
        story.append(Paragraph("2. Claim-by-Claim Verification Matrix", styles["CCSection"]))
        c_table = Table(claims_data, colWidths=[52 * mm, 28 * mm, 70 * mm, 30 * mm], repeatRows=1)
        c_table.setStyle(
            TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ])
        )
        story.append(c_table)

    sources = report.get("evidence_sources") or []
    if sources:
        story.append(Paragraph("3. Evidence Vault &amp; Provenance Appendix", styles["CCSection"]))
        s_rows = [[
            Paragraph("<b>Evidence ID</b>", styles["CCSmall"]),
            Paragraph("<b>Source Title &amp; URL</b>", styles["CCSmall"]),
            Paragraph("<b>Quality &amp; Limitations</b>", styles["CCSmall"]),
        ]]
        for src in sources[:10]:
            s_rows.append([
                Paragraph(escape(str(src.get("id") or "")), styles["CCSmall"]),
                Paragraph(f"<b>{escape(str(src.get('title') or ''))}</b><br/>{escape(str(src.get('source_url') or 'Internal Provider Record'))}", styles["CCSmall"]),
                Paragraph(f"<b>{escape(str(src.get('source_quality') or 'indexed'))}</b>: {escape(str(src.get('limitations') or ''))}", styles["CCSmall"]),
            ])
        s_table = Table(s_rows, colWidths=[30 * mm, 80 * mm, 70 * mm], repeatRows=1)
        s_table.setStyle(
            TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E293B")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ])
        )
        story.append(s_table)

    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("4. Methodology &amp; Scope Limitations", styles["CCSection"]))
    story.append(
        Paragraph(
            "This dossier is preliminary due-diligence research support, not a legal opinion, audited financial review, credit decision, sanctions determination, or fraud certification. Missing or conflicting data requires human review. Provider records and public sources may be incomplete, stale, estimated, or self-reported.",
            styles["CCMeta"],
        )
    )
    if report.get("content_hash"):
        story.append(Spacer(1, 2 * mm))
        story.append(Paragraph(f"Snapshot SHA-256 Integrity Hash: {escape(str(report.get('content_hash')))}", styles["CCMeta"]))

    doc.build(story)
    return buffer.getvalue()
