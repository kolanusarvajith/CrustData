from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from typing import Any
from fastapi import BackgroundTasks, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field

from app.core.config import settings
from app.core.logging import configure_logging
from app.core.store import store
from app.integrations.crustdata.client import CrustdataClient
from app.integrations.crustdata.fixtures import EVALUATION_COMPANIES
from app.integrations.llm.provider import OllamaProvider
from app.services.claim_extraction import extract_claims
from app.services.credit_policy import ACCOUNT_PRICE_BASELINE, estimate_default_company_investigation
from app.services.investigation_workflow import (
    evaluate_single_claim_against_observations,
    run_full_investigation_pipeline,
    seed_evaluation_investigations_if_empty,
)
from app.services.pdf_report import render_report_pdf
from app.services.sse import event_stream

configure_logging()

app = FastAPI(
    title="CounterCheck API — Autonomous Business Due Diligence & Claim Verification",
    version="2.0.0",
    description="Evidence-first business due diligence powered by Crustdata Canonical Graph, Ollama Local LLM, and Deterministic Claim Verification.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

llm = OllamaProvider()

def _model_to_dict(m: BaseModel, *, exclude_unset: bool = False) -> dict[str, Any]:
    if hasattr(m, "model_dump"):
        return m.model_dump(exclude_unset=exclude_unset)  # type: ignore[attr-defined]
    return m.dict(exclude_unset=exclude_unset)



@app.on_event("startup")
async def on_startup() -> None:
    seed_evaluation_investigations_if_empty(store)


class ExtractRequest(BaseModel):
    company: str = Field(min_length=1, max_length=256)
    text: str = Field(min_length=1, max_length=12000)
    allow_fallback: bool = True


class IdentifyRequest(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=256)
    domain: str | None = Field(default=None, min_length=1, max_length=253)
    exact_match: bool | None = None
    allow_fallback: bool | None = None


class EnrichRequest(BaseModel):
    company_id: int = Field(gt=0)
    fields: list[str] = Field(default_factory=lambda: ["basic_info", "headcount", "funding", "locations", "hiring"])
    allow_fallback: bool | None = None


class ClaimInputModel(BaseModel):
    original_text: str = Field(min_length=1, max_length=2000)
    category: str = Field(default="general", max_length=80)
    subject: str = Field(default="Company", max_length=256)
    metric: str = Field(default="fact", max_length=128)
    operator: str = Field(default="equals", max_length=32)
    claimed_value: Any = None
    value: Any = None
    unit: str | None = None
    period: str | None = None
    ambiguity_flags: list[str] = Field(default_factory=list)


class InvestigationCreateModel(BaseModel):
    company_name: str | None = Field(default=None, max_length=256)
    company_domain: str | None = Field(default=None, max_length=253)
    purpose: str = Field(default="Preliminary business due diligence", max_length=500)
    claims: list[ClaimInputModel] = Field(default_factory=list)
    auto_start: bool = False
    auto_select_top_candidate: bool = False


class StartInvestigationRequest(BaseModel):
    auto_select_top_candidate: bool = False
    selected_candidate_id: int | None = None
    run_synchronously: bool = True


class SelectCandidateRequest(BaseModel):
    candidate_id: int = Field(gt=0)


class ReviewRequest(BaseModel):
    disposition: str = Field(default="accepted")
    override_status: str | None = Field(default=None)
    reason: str | None = Field(default=None, max_length=2000)
    reviewer_id: str = Field(default="analyst@countercheck.local", max_length=128)


class EvidenceSourceCreateModel(BaseModel):
    provider: str = Field(min_length=1, max_length=40)
    provider_entity_id: str | None = None
    source_url: str | None = None
    source_title: str | None = None
    publisher: str | None = None
    source_quality: str | None = "provider_indexed"
    published_at: str | None = None
    content_hash: str | None = None
    raw_object_ref: str | None = None
    limitations: str | None = None


class ObservationCreateModel(BaseModel):
    evidence_source_id: str
    entity_provider_id: str | None = None
    field_path: str = Field(min_length=1, max_length=512)
    raw_value: Any = None
    normalized_value: Any = None
    unit: str | None = None
    observed_at: str | None = None


class AnnotationRequest(BaseModel):
    note: str = Field(min_length=1, max_length=2000)
    author: str = Field(default="analyst@countercheck.local", max_length=128)


class RuntimeConfigUpdateRequest(BaseModel):
    crustdata_api_key: str | None = None
    crustdata_api_base_url: str | None = None
    crustdata_max_calls_per_investigation: int | None = None
    crustdata_max_estimated_credits_per_investigation: float | None = None
    crustdata_demo_fallback: bool | None = None
    global_kill_switch: bool | None = None
    llm_base_url: str | None = None
    llm_model: str | None = None
    llm_timeout_seconds: float | None = None


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "service": "countercheck-api",
        "version": "2.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/v1/settings/runtime")
async def get_runtime_settings() -> dict[str, Any]:
    return settings.safe_dict()


@app.patch("/api/v1/settings/runtime")
async def update_runtime_settings(body: RuntimeConfigUpdateRequest) -> dict[str, Any]:
    updated = settings.update_runtime(_model_to_dict(body, exclude_unset=True))
    llm.base_url = settings.llm_base_url.rstrip("/")
    llm.model = settings.llm_model
    return updated


@app.get("/api/v1/integrations/llm/status")
async def llm_status() -> dict[str, Any]:
    health_info = await llm.health()
    return {**health_info, "recent_runs": llm.run_history[-10:]}


@app.get("/api/v1/integrations/crustdata/status")
async def crustdata_status() -> dict[str, Any]:
    return {
        "configured": bool(settings.crustdata_api_key),
        "key_preview": settings.safe_dict()["crustdata_key_preview"],
        "api_version": settings.crustdata_api_version,
        "base_url": settings.crustdata_api_base_url,
        "demo_fallback_enabled": settings.crustdata_demo_fallback,
        "global_kill_switch": settings.global_kill_switch,
        "max_calls_per_investigation": settings.crustdata_max_calls_per_investigation,
        "max_estimated_credits_per_investigation": settings.crustdata_max_estimated_credits_per_investigation,
        "endpoint_pricing_baseline": ACCOUNT_PRICE_BASELINE,
        "estimated_default_investigation_credits": round(estimate_default_company_investigation(), 2),
    }


@app.post("/api/v1/llm/extract-claims")
async def llm_extract_claims(body: ExtractRequest) -> dict[str, Any]:
    try:
        return await extract_claims(llm, body.company, body.text, allow_heuristic_fallback=body.allow_fallback)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/api/v1/integrations/crustdata/identify")
async def identify_company(body: IdentifyRequest) -> Any:
    name = (body.name or "").strip() or None
    domain = (body.domain or "").strip() or None
    if bool(name) == bool(domain):
        raise HTTPException(status_code=422, detail="Provide exactly one of name or domain")
    use_fallback = body.allow_fallback if body.allow_fallback is not None else settings.crustdata_demo_fallback
    try:
        async with CrustdataClient(allow_fallback=use_fallback) as client:
            return await client.identify_company(name=name, domain=domain, exact_match=body.exact_match)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/api/v1/integrations/crustdata/enrich-company")
async def enrich_company(body: EnrichRequest) -> Any:
    use_fallback = body.allow_fallback if body.allow_fallback is not None else settings.crustdata_demo_fallback
    try:
        async with CrustdataClient(allow_fallback=use_fallback) as client:
            return await client.enrich_company(company_id=body.company_id, fields=body.fields)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/api/v1/investigations", status_code=201)
async def create_investigation(body: InvestigationCreateModel) -> dict[str, Any]:
    c_name = (body.company_name or "").strip() or None
    c_dom = (body.company_domain or "").strip() or None
    if not body.claims:
        raise HTTPException(status_code=422, detail='At least one claim is required')
    if bool(c_name) == bool(c_dom):
        raise HTTPException(status_code=422, detail="Provide exactly one of company_name or company_domain")
    claims_payload = []
    for c in body.claims:
        cd = _model_to_dict(c)
        if cd.get("claimed_value") is None and cd.get("value") is not None:
            cd["claimed_value"] = cd["value"]
        claims_payload.append(cd)
    item = store.create_investigation(
        company_name=c_name,
        company_domain=c_dom,
        purpose=body.purpose,
        claims=claims_payload,
    )
    if body.auto_start:
        item = await run_full_investigation_pipeline(
            item["id"],
            auto_select_top_candidate=body.auto_select_top_candidate,
        )
    return item


@app.get("/api/v1/investigations")
async def list_investigations(limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0)) -> dict[str, Any]:
    seed_evaluation_investigations_if_empty(store)
    items = store.list_investigations(limit=limit, offset=offset)
    return {"items": items, "limit": limit, "offset": offset}


@app.get("/api/v1/investigations/{investigation_id}")
async def get_investigation(investigation_id: str) -> dict[str, Any]:
    item = store.get_investigation(investigation_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return item


@app.post("/api/v1/investigations/{investigation_id}/start", status_code=202)
async def start_investigation(
    investigation_id: str,
    background_tasks: BackgroundTasks,
    body: StartInvestigationRequest | None = None,
) -> dict[str, Any]:
    item = store.get_investigation(investigation_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    req = body or StartInvestigationRequest()
    if req.run_synchronously:
        updated = await run_full_investigation_pipeline(
            investigation_id,
            selected_candidate_id=req.selected_candidate_id,
            auto_select_top_candidate=req.auto_select_top_candidate,
        )
        return updated
    store.update_investigation_state(investigation_id, status="queued", current_stage="queued")
    store.append_event(
        investigation_id,
        stage="queued",
        event_type="investigation_queued",
        status="queued",
        message="Investigation queued for background execution.",
    )
    background_tasks.add_task(
        run_full_investigation_pipeline,
        investigation_id,
        selected_candidate_id=req.selected_candidate_id,
        auto_select_top_candidate=req.auto_select_top_candidate,
    )
    return {"id": investigation_id, "status": "queued"}


@app.post("/api/v1/investigations/{investigation_id}/resolve-and-enrich")
async def run_company_retrieval(investigation_id: str, auto_select: bool = False) -> dict[str, Any]:
    item = store.get_investigation(investigation_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    try:
        return await run_full_investigation_pipeline(
            investigation_id,
            auto_select_top_candidate=auto_select,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Investigation retrieval failed: {exc}") from exc


@app.post("/api/v1/investigations/{investigation_id}/select-candidate")
async def select_company_candidate(investigation_id: str, body: SelectCandidateRequest) -> dict[str, Any]:
    item = store.get_investigation(investigation_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return await run_full_investigation_pipeline(
        investigation_id,
        selected_candidate_id=body.candidate_id,
        auto_select_top_candidate=True,
    )


@app.post("/api/v1/investigations/{investigation_id}/cancel")
async def cancel_investigation(investigation_id: str) -> dict[str, Any]:
    item = store.get_investigation(investigation_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    store.update_investigation_state(investigation_id, status="cancelled", cancel_requested=True)
    store.append_event(
        investigation_id,
        stage="cancelled",
        event_type="investigation_cancelled",
        status="cancelled",
        message="Cooperative cancellation requested by analyst.",
    )
    return {"id": investigation_id, "status": "cancelled"}


@app.post("/api/v1/investigations/{investigation_id}/resume")
async def resume_investigation(investigation_id: str) -> dict[str, Any]:
    item = store.get_investigation(investigation_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return await run_full_investigation_pipeline(
        investigation_id,
        selected_candidate_id=item.get("company_crustdata_id"),
        auto_select_top_candidate=True,
    )


@app.get("/api/v1/investigations/{investigation_id}/events")
async def get_investigation_events(investigation_id: str, after: int = 0) -> dict[str, Any]:
    if store.get_investigation(investigation_id) is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return {"events": store.list_events(investigation_id, after=after)}


@app.get("/api/v1/investigations/{investigation_id}/stream")
async def stream_investigation_events(investigation_id: str, last_event_id: int = 0) -> StreamingResponse:
    if store.get_investigation(investigation_id) is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return StreamingResponse(
        event_stream(investigation_id, after=last_event_id, target_store=store),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/v1/investigations/{investigation_id}/claims")
async def get_investigation_claims(investigation_id: str) -> dict[str, Any]:
    inv = store.get_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return {"claims": inv["claims"]}


@app.post("/api/v1/investigations/{investigation_id}/claims", status_code=201)
async def add_investigation_claim(investigation_id: str, body: ClaimInputModel) -> dict[str, Any]:
    inv = store.get_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    cd = _model_to_dict(body)
    if cd.get("claimed_value") is None and cd.get("value") is not None:
        cd["claimed_value"] = cd["value"]
    claim = store.add_claim_to_investigation(investigation_id, cd)
    # Immediately verify against existing observations if available
    obs = store.list_observations(investigation_id)
    if obs:
        comp_ev = next((s["id"] for s in inv["evidence_sources"] if s["provider"] == "crustdata"), None)
        vres = evaluate_single_claim_against_observations(claim, obs, inv.get("people") or [], [], comp_ev, None)
        store.upsert_verdict(
            claim_id=claim["id"],
            investigation_id=investigation_id,
            status=vres.status.value,
            explanation=vres.explanation,
            confidence_band=vres.confidence_band,
            rule_version=vres.rule_version,
            evidence_ids=list(vres.evidence_ids),
            operands=vres.operands,
        )
    return store.get_claim(claim["id"])  # type: ignore[return-value]


@app.post("/api/v1/claims/{claim_id}/verify")
async def verify_claim_endpoint(claim_id: str) -> dict[str, Any]:
    claim = store.get_claim(claim_id)
    if claim is None:
        raise HTTPException(status_code=404, detail="Claim not found")
    inv_id = claim["investigation_id"]
    inv = store.get_investigation(inv_id) or {}
    obs = store.list_observations(inv_id)
    sources = store.list_evidence_sources(inv_id)
    comp_ev = next((s["id"] for s in sources if s["provider"] == "crustdata"), None)
    vres = evaluate_single_claim_against_observations(
        claim,
        obs,
        inv.get("people") or [],
        [],
        comp_ev,
        None,
    )
    verdict = store.upsert_verdict(
        claim_id=claim_id,
        investigation_id=inv_id,
        status=vres.status.value,
        explanation=vres.explanation,
        confidence_band=vres.confidence_band,
        rule_version=vres.rule_version,
        evidence_ids=list(vres.evidence_ids),
        operands=vres.operands,
    )
    return {
        "claim_id": claim_id,
        "status": verdict["status"],
        "explanation": verdict["explanation"],
        "confidence_band": verdict["confidence_band"],
        "evidence_ids": verdict["evidence_ids"],
    }


@app.post("/api/v1/claims/{claim_id}/review", status_code=201)
@app.patch("/api/v1/claims/{claim_id}/review")
async def review_claim(claim_id: str, body: ReviewRequest) -> dict[str, Any]:
    claim = store.get_claim(claim_id)
    if claim is None:
        raise HTTPException(status_code=404, detail="Claim not found")
    if body.disposition not in {"accepted", "needs_follow_up", "overridden"}:
        raise HTTPException(status_code=422, detail="Invalid disposition")
    if body.override_status and body.override_status not in {"SUPPORTED", "CONTRADICTED", "UNVERIFIED", "CONFLICTING"}:
        raise HTTPException(status_code=422, detail="Invalid override_status")
    if body.disposition == "overridden" and (not body.override_status or not body.reason or not body.reason.strip()):
        raise HTTPException(status_code=422, detail="An override requires a target verdict and mandatory reason")
    return store.record_human_review(
        claim_id=claim_id,
        disposition=body.disposition,
        override_status=body.override_status,
        reason=body.reason,
        reviewer_id=body.reviewer_id,
    )


@app.post("/api/v1/investigations/{investigation_id}/evidence", status_code=201)
async def add_evidence_source(investigation_id: str, body: EvidenceSourceCreateModel) -> dict[str, Any]:
    if store.get_investigation(investigation_id) is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return store.create_evidence_source(investigation_id, _model_to_dict(body))


@app.post("/api/v1/evidence/{source_id}/annotate", status_code=201)
async def annotate_evidence(source_id: str, body: AnnotationRequest) -> dict[str, Any]:
    res = store.annotate_evidence_source(source_id, body.note, body.author)
    if res is None:
        raise HTTPException(status_code=404, detail="Evidence source not found")
    return res


@app.post("/api/v1/investigations/{investigation_id}/observations", status_code=201)
async def add_observation(investigation_id: str, body: ObservationCreateModel) -> dict[str, Any]:
    inv = store.get_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    if not any(s["id"] == body.evidence_source_id for s in inv["evidence_sources"]):
        raise HTTPException(status_code=422, detail="Evidence source does not belong to this investigation")
    return store.create_observation(investigation_id, _model_to_dict(body))


@app.get("/api/v1/investigations/{investigation_id}/evidence")
async def list_evidence(investigation_id: str) -> dict[str, Any]:
    if store.get_investigation(investigation_id) is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return {
        "items": store.list_evidence_sources(investigation_id),
        "observations": store.list_observations(investigation_id),
    }


@app.get("/api/v1/investigations/{investigation_id}/graph")
async def get_investigation_graph(investigation_id: str) -> dict[str, Any]:
    inv = store.get_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return inv.get("graph") or {"nodes": [], "edges": []}


@app.get("/api/v1/investigations/{investigation_id}/usage")
async def investigation_usage(investigation_id: str) -> dict[str, Any]:
    if store.get_investigation(investigation_id) is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return store.list_credits(investigation_id)


@app.get("/api/v1/usage")
async def global_usage() -> dict[str, Any]:
    invs = store.list_investigations(limit=100)
    est_sum = sum(x["estimated_credits"] for x in invs)
    act_sum = sum(x["actual_credits"] for x in invs)
    return {
        "total_investigations": len(invs),
        "estimated_total_credits": round(est_sum, 2),
        "actual_total_credits": round(act_sum, 2),
        "per_investigation_cap": settings.crustdata_max_estimated_credits_per_investigation,
        "global_kill_switch": settings.global_kill_switch,
    }


@app.get("/api/v1/audit")
async def list_audit_trail(investigation_id: str | None = None) -> dict[str, Any]:
    return {"items": store.list_audit_events(investigation_id)}


@app.get("/api/v1/investigations/{investigation_id}/report")
async def get_report(investigation_id: str) -> dict[str, Any]:
    inv = store.get_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    reports = store.list_reports(investigation_id)
    return {"latest": reports[0] if reports else None, "versions": reports}


@app.post("/api/v1/investigations/{investigation_id}/report/snapshot", status_code=201)
@app.post("/api/v1/investigations/{investigation_id}/report/export", status_code=201)
async def snapshot_report(investigation_id: str) -> dict[str, Any]:
    inv = store.get_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    claims_summary = []
    for c in inv.get("claims", []):
        v = c.get("verdict") or {}
        claims_summary.append({
            "id": c["id"],
            "category": c["category"],
            "original_text": c["original_text"],
            "verdict": v.get("status", "UNVERIFIED"),
            "confidence_band": v.get("confidence_band", "LOW"),
            "explanation": v.get("explanation", "No verification result has been recorded."),
            "evidence_ids": v.get("evidence_ids", []),
            "human_review": c.get("human_review"),
        })
    payload = {
        "investigation_id": inv["id"],
        "company_name": inv.get("company_name") or inv.get("company_identifier"),
        "company_domain": inv.get("company_domain"),
        "company_crustdata_id": inv.get("company_crustdata_id"),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "rule_version": "2.1.0",
        "model_version": settings.llm_model,
        "executive_summary": f"Evidence-first verification dossier for {inv.get('company_name') or inv.get('company_identifier')} across {len(claims_summary)} claims.",
        "claims": claims_summary,
        "evidence_sources": inv.get("evidence_sources", []),
        "limitations": [
            "Preliminary research support only; human review required before onboarding or investment decisions.",
            "Provider records and public sources may be estimated, stale, or self-reported.",
        ],
    }
    snap = store.create_report_snapshot(inv["id"], payload)
    return {
        "id": snap["id"],
        "version": snap["version"],
        "content_hash": snap["content_hash"],
        "generated_at": snap["generated_at"],
    }


@app.get("/api/v1/investigations/{investigation_id}/report.pdf")
async def download_report_pdf(investigation_id: str) -> Response:
    inv = store.get_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    reports = store.list_reports(investigation_id)
    if not reports:
        await snapshot_report(investigation_id)
        reports = store.list_reports(investigation_id)
    pdf_bytes = render_report_pdf(reports[0]["content"])
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="countercheck-dossier-{investigation_id}.pdf"'},
    )


from pathlib import Path as _Path
from fastapi.responses import HTMLResponse


class PlaygroundRequest(BaseModel):
    endpoint: str = Field(default="/company/identify")
    company_name: str | None = None
    company_domain: str | None = None
    company_id: int | None = None
    query: str | None = None
    profile_urls: list[str] = Field(default_factory=list)
    urls: list[str] = Field(default_factory=list)
    allow_fallback: bool | None = None


@app.get("/", response_class=HTMLResponse)
async def serve_workbench_ui() -> HTMLResponse:
    for candidate in (
        _Path(__file__).resolve().parents[2] / "web" / "public" / "countercheck_workspace.html",
        _Path(__file__).resolve().parents[3] / "apps" / "web" / "public" / "countercheck_workspace.html",
    ):
        if candidate.is_file():
            return HTMLResponse(content=candidate.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>CounterCheck API v2.0 Running</h1><p>Visit <a href='/docs'>/docs</a> for OpenAPI spec.</p>")


@app.post("/api/v1/integrations/crustdata/playground")
async def crustdata_playground(body: PlaygroundRequest) -> dict[str, Any]:
    use_fallback = body.allow_fallback if body.allow_fallback is not None else settings.crustdata_demo_fallback
    ep = body.endpoint.strip()
    try:
        async with CrustdataClient(allow_fallback=use_fallback) as client:
            if ep == "/company/identify":
                data = await client.identify_company(name=body.company_name, domain=body.company_domain)
            elif ep == "/company/enrich":
                cid = int(body.company_id or 104821)
                data = await client.enrich_company(company_id=cid, name_hint=body.company_name, domain_hint=body.company_domain)
            elif ep == "/person/search":
                cid = int(body.company_id or 104821)
                data = await client.search_people(company_id=cid, limit=8, name_hint=body.company_name)
            elif ep == "/person/enrich":
                urls = body.profile_urls or ["https://www.linkedin.com/in/patrickcollison"]
                data = await client.enrich_person(profile_urls=urls, company_id=body.company_id or 104821)
            elif ep == "/job/search":
                cid = int(body.company_id or 104821)
                data = await client.search_jobs(company_id=cid, limit=10, name_hint=body.company_name)
            elif ep == "/web/search/live":
                q = body.query or f"{body.company_name or 'Stripe'} funding headcount"
                data = await client.web_search(q, company_id=body.company_id, name_hint=body.company_name)
            elif ep == "/web/enrich/live":
                u = body.urls or ["https://stripe.com/newsroom"]
                data = await client.fetch_web_pages(u)
            else:
                raise ValueError(f"Unsupported playground endpoint: {ep}")
            telemetry = client.call_history[-1] if client.call_history else {"endpoint": ep, "mode": "live"}
            return {"endpoint": ep, "telemetry": telemetry, "result": data}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
