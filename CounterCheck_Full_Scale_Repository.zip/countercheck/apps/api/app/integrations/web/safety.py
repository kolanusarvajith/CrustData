import ipaddress
import socket
from urllib.parse import urlparse


class UnsafeURL(ValueError):
    pass


def validate_public_http_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise UnsafeURL("Only absolute HTTP(S) URLs are accepted")
    host = parsed.hostname.rstrip(".").lower()
    if host in {"localhost", "localhost.localdomain", "0.0.0.0"} or host.endswith((".local", ".internal", ".localhost")):
        raise UnsafeURL("Localhost and internal URLs are not allowed")
    try:
        addresses = {ipaddress.ip_address(host)}
    except ValueError:
        try:
            addresses = {ipaddress.ip_address(info[4][0]) for info in socket.getaddrinfo(host, None)}
        except socket.gaierror as exc:
            # In sandboxed environments without DNS, check if hostname looks like a private IP range
            if host.startswith(("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.2", "172.30.", "172.31.", "127.", "169.254.")):
                raise UnsafeURL("Private IP ranges are not allowed") from exc
            raise UnsafeURL("URL host could not be resolved") from exc
    if not addresses or any(not addr.is_global for addr in addresses):
        raise UnsafeURL("Private, loopback, link-local and reserved destinations are not allowed")
    return url


def classify_source_quality(url: str | None, company_domain: str | None = None) -> tuple[str, str]:
    """Classify web source into provenance category and limitation note (Section 8.2)."""
    if not url:
        return ("provider_indexed", "Provider-indexed structured record; fields may be estimated or periodically refreshed.")
    host = (urlparse(url).hostname or "").lower().removeprefix("www.")
    comp_dom = (company_domain or "").lower().removeprefix("www.")
    if comp_dom and (host == comp_dom or host.endswith(f".{comp_dom}")):
        return ("company_authored", "Company-authored statement on official domain; treat self-reported metrics with appropriate caution.")
    if any(reg in host for reg in ("sec.gov", "companieshouse.gov.uk", "mca.gov.in", "opencorporates.com", "finra.org")):
        return ("regulatory_registry", "Official regulatory or corporate registry filing; high evidentiary weight for legal entity facts.")
    if any(news in host for news in ("reuters.com", "bloomberg.com", "wsj.com", "ft.com", "techcrunch.com", "forbes.com", "cnbc.com", "theinformation.com")):
        return ("independent_reporting", "Independent financial/technology press reporting; credible secondary corroboration.")
    if any(vc in host for vc in ("ycombinator.com", "sequoiacap.com", "a16z.com", "accel.com", "indexventures.com", "thrivecap.com", "prnewswire.com", "businesswire.com")):
        return ("investor_announcement", "Investor portfolio record or press wire announcement.")
    return ("third_party_database", "Public web or third-party directory page; verify freshness and primary provenance.")
