PROMPT_VERSION = "v2.1-2026-10-31"

CLAIM_EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "claims": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "original_text": {"type": "string"},
                    "category": {
                        "type": "string",
                        "enum": [
                            "founding_year",
                            "headcount",
                            "funding",
                            "location",
                            "leadership",
                            "hiring",
                            "customer_partnership",
                            "compliance",
                        ],
                    },
                    "subject": {"type": "string"},
                    "metric": {"type": "string"},
                    "operator": {"type": "string", "enum": ["equals", "approx", "gte", "lte", "contains"]},
                    "value": {},
                    "unit": {"type": ["string", "null"]},
                    "period": {"type": ["string", "null"]},
                    "ambiguity_flags": {"type": "array", "items": {"type": "string"}},
                },
                "required": [
                    "original_text",
                    "category",
                    "subject",
                    "metric",
                    "operator",
                    "value",
                    "unit",
                    "period",
                    "ambiguity_flags",
                ],
            },
        }
    },
    "required": ["claims"],
}

REPORT_SCHEMA = {
    "type": "object",
    "properties": {
        "executive_summary": {"type": "string"},
        "key_findings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "evidence_ids": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["text", "evidence_ids"],
            },
        },
        "follow_up_questions": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["executive_summary", "key_findings", "follow_up_questions"],
}
