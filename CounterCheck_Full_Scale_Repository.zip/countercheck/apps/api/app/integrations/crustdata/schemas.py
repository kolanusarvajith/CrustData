from __future__ import annotations
from typing import Any
from pydantic import BaseModel, Field


class CompanyIdentityInput(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=256)
    domain: str | None = Field(default=None, min_length=1, max_length=253)

    def validate_identifier(self) -> "CompanyIdentityInput":
        if bool(self.name) == bool(self.domain):
            raise ValueError("Provide exactly one of name or domain")
        return self


class CompanyCandidate(BaseModel):
    crustdata_company_id: int | None = None
    confidence_score: float | None = None
    name: str | None = None
    primary_domain: str | None = None
    website: str | None = None
    year_founded: int | None = None
    employee_count_range: str | None = None
    headquarters: str | None = None
    industries: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class CrustdataError(Exception):
    def __init__(self, message: str, *, status_code: int | None = None, retryable: bool = False):
        super().__init__(message)
        self.status_code = status_code
        self.retryable = retryable

# --- DEEP NORMALIZER ---
"""Deep schema normalizer for live Crustdata v2025-11-01 API responses."""
import re
from typing import Any


def _first_non_empty(*vals: Any) -> Any:
    for v in vals:
        if v is not None and v != "" and v != [] and v != {}:
            return v
    return None


def _parse_int_year(val: Any) -> int | None:
    if val is None:
        return None
    if isinstance(val, int) and 1800 <= val <= 2100:
        return val
    m = re.search(r"(18\d{2}|19\d{2}|20\d{2})", str(val))
    return int(m.group(1)) if m else None


def _parse_int_number(val: Any) -> int | None:
    if val is None or isinstance(val, bool):
        return None
    if isinstance(val, (int, float)):
        return int(val)
    cleaned = re.sub(r"[,\s]", "", str(val))
    m = re.match(r"^(\d+)(?:\.\d+)?$", cleaned)
    return int(m.group(1)) if m else None


def _parse_float_usd(val: Any) -> float | None:
    if val is None or isinstance(val, bool):
        return None
    if isinstance(val, (int, float)):
        return float(val)
    cleaned = re.sub(r"[,$\s]", "", str(val)).lower()
    m = re.match(r"^(\d+(?:\.\d+)?)(k|m|b|bn|million|billion)?$", cleaned)
    if not m:
        return None
    base = float(m.group(1))
    suf = m.group(2) or ""
    if suf.startswith("b"):
        return base * 1e9
    if suf.startswith("m"):
        return base * 1e6
    if suf.startswith("k"):
        return base * 1e3
    return base


def _format_location_obj(loc: Any) -> str | None:
    if not loc:
        return None
    if isinstance(loc, str):
        return loc.strip() or None
    if isinstance(loc, dict):
        parts = [
            loc.get("city") or loc.get("locality"),
            loc.get("state") or loc.get("region"),
            loc.get("country") or loc.get("country_name"),
        ]
        joined = ", ".join(str(p).strip() for p in parts if p)
        return joined or str(loc.get("full_address") or loc.get("address") or loc.get("name") or "") or None
    return str(loc)


def normalize_identify_candidates(raw_resp: Any) -> list[dict[str, Any]]:
    """Extract candidate list from any Crustdata /company/identify response shape."""
    items = raw_resp
    if isinstance(raw_resp, dict):
        items = _first_non_empty(raw_resp.get("data"), raw_resp.get("matches"), raw_resp.get("companies"), raw_resp.get("results"), [raw_resp])
    if not isinstance(items, list):
        items = [items]

    candidates: list[dict[str, Any]] = []
    for entry in items:
        if not isinstance(entry, dict):
            continue
        match_list = entry.get("matches") if isinstance(entry.get("matches"), list) else [entry]
        for m in match_list:
            if not isinstance(m, dict):
                continue
            comp = m.get("company_data") if isinstance(m.get("company_data"), dict) else m
            basic = comp.get("basic_info") if isinstance(comp.get("basic_info"), dict) else comp
            hc = comp.get("headcount") if isinstance(comp.get("headcount"), dict) else {}
            loc = comp.get("locations") if isinstance(comp.get("locations"), dict) else {}

            cid = _first_non_empty(
                comp.get("crustdata_company_id"),
                comp.get("company_id"),
                basic.get("company_id"),
                m.get("crustdata_company_id"),
                m.get("company_id"),
                comp.get("id"),
            )
            if cid is None:
                continue
            name = _first_non_empty(basic.get("name"), comp.get("company_name"), comp.get("name"), m.get("company_name"))
            domain = _first_non_empty(
                basic.get("primary_domain"),
                basic.get("domain"),
                comp.get("primary_domain"),
                comp.get("company_website_domain"),
                comp.get("domain"),
            )
            website = _first_non_empty(basic.get("website"), comp.get("website"), comp.get("company_website"), f"https://{domain}" if domain else None)
            yr = _parse_int_year(_first_non_empty(basic.get("year_founded"), comp.get("year_founded"), basic.get("founded_year")))
            hc_range = _first_non_empty(hc.get("range"), hc.get("employee_count_range"), basic.get("employee_count_range"), comp.get("employee_count_range"))
            hq = _format_location_obj(_first_non_empty(loc.get("headquarters"), basic.get("hq_location"), comp.get("hq_location"), comp.get("headquarters")))
            industries = _first_non_empty(basic.get("industries"), comp.get("industries"), [basic.get("industry")] if basic.get("industry") else [])
            conf = _first_non_empty(m.get("confidence_score"), m.get("score"), 0.95)
            candidates.append({
                "id": int(cid),
                "name": str(name or f"Company #{cid}"),
                "domain": str(domain) if domain else None,
                "website": str(website) if website else None,
                "year_founded": yr,
                "employee_count_range": str(hc_range) if hc_range else None,
                "headquarters": hq,
                "industries": industries if isinstance(industries, list) else [str(industries)],
                "confidence": float(conf) if isinstance(conf, (int, float)) else 0.9,
            })
    return candidates


def normalize_enriched_company(raw_resp: Any, fallback_id: int, fallback_name: str | None, fallback_domain: str | None) -> dict[str, Any]:
    """Normalize any live Crustdata /company/enrich response into CounterCheck's canonical company_blob."""
    payload = raw_resp
    if isinstance(raw_resp, dict):
        payload = _first_non_empty(raw_resp.get("data"), raw_resp.get("companies"), raw_resp.get("matches"), raw_resp)
    comp: dict[str, Any] = {}
    if isinstance(payload, list) and payload:
        first = payload[0]
        if isinstance(first, dict):
            if isinstance(first.get("matches"), list) and first["matches"]:
                m0 = first["matches"][0]
                comp = m0.get("company_data") if isinstance(m0.get("company_data"), dict) else m0
            elif isinstance(first.get("company_data"), dict):
                comp = first["company_data"]
            else:
                comp = first
    elif isinstance(payload, dict):
        comp = payload.get("company_data") if isinstance(payload.get("company_data"), dict) else payload

    basic = comp.get("basic_info") if isinstance(comp.get("basic_info"), dict) else {}
    hc = comp.get("headcount") if isinstance(comp.get("headcount"), dict) else {}
    fund = comp.get("funding") if isinstance(comp.get("funding"), dict) else {}
    loc = comp.get("locations") if isinstance(comp.get("locations"), dict) else {}
    hiring = comp.get("hiring") if isinstance(comp.get("hiring"), dict) else {}

    name = _first_non_empty(basic.get("name"), comp.get("company_name"), comp.get("name"), fallback_name, f"Company #{fallback_id}")
    legal_name = _first_non_empty(basic.get("legal_name"), comp.get("legal_name"), name)
    domain = _first_non_empty(basic.get("primary_domain"), basic.get("domain"), comp.get("company_website_domain"), comp.get("primary_domain"), fallback_domain)
    website = _first_non_empty(basic.get("website"), comp.get("company_website"), comp.get("website"), f"https://{domain}" if domain else None)
    year_founded = _parse_int_year(_first_non_empty(basic.get("year_founded"), comp.get("year_founded"), basic.get("founded_year")))
    inc_year = _parse_int_year(_first_non_empty(basic.get("incorporation_year"), comp.get("incorporation_year"), year_founded))
    industries = _first_non_empty(basic.get("industries"), comp.get("industries"), [basic.get("industry")] if basic.get("industry") else ["Technology"])
    desc = _first_non_empty(basic.get("description"), comp.get("linkedin_company_description"), comp.get("description"), "")

    hc_total = _parse_int_number(_first_non_empty(
        hc.get("total"),
        hc.get("linkedin_headcount"),
        hc.get("headcount"),
         hc.get("current_headcount"),
        comp.get("linkedin_headcount"),
        comp.get("employee_count"),
    ))
    hc_range = _first_non_empty(hc.get("range"), hc.get("employee_count_range"), basic.get("employee_count_range"), comp.get("employee_count_range"))
    hc_growth = _first_non_empty(hc.get("yoy_growth_pct"), hc.get("headcount_growth_yoy"), hc.get("six_months_growth_pct"))

    tot_funding = _parse_float_usd(_first_non_empty(
        fund.get("total_investment_usd"),
        fund.get("total_funding_usd"),
        fund.get("crunchbase_total_investment_usd"),
        comp.get("total_investment_usd"),
        comp.get("crunchbase_total_investment_usd"),
    ))
    last_round_type = _first_non_empty(
        fund.get("last_funding_round_type"),
        fund.get("latest_funding_round_type"),
        fund.get("last_funding_type"),
        comp.get("last_funding_round_type"),
    )
    last_round_usd = _parse_float_usd(_first_non_empty(
        fund.get("last_funding_round_amount_usd"),
        fund.get("latest_funding_round_amount_usd"),
        fund.get("last_funding_round_investment_usd"),
    ))
    raw_investors = _first_non_empty(fund.get("investors"), fund.get("all_investors"), comp.get("investors"), [])
    investors_clean: list[str] = []
    if isinstance(raw_investors, list):
        for inv in raw_investors:
            if isinstance(inv, str) and inv.strip():
                investors_clean.append(inv.strip())
            elif isinstance(inv, dict) and inv.get("name"):
                investors_clean.append(str(inv["name"]).strip())
    elif isinstance(raw_investors, str):
        investors_clean = [x.strip() for x in raw_investors.split(",") if x.strip()]

    hq_str = _format_location_obj(_first_non_empty(
        loc.get("headquarters"),
        loc.get("hq"),
        basic.get("hq_location"),
        comp.get("hq_location"),
        comp.get("headquarters"),
    ))
    raw_offices = _first_non_empty(loc.get("offices"), loc.get("office_locations"), comp.get("office_locations"), [])
    offices_clean: list[str] = []
    if isinstance(raw_offices, list):
        for off in raw_offices:
            f_off = _format_location_obj(off)
            if f_off and f_off not in offices_clean:
                offices_clean.append(f_off)
    if hq_str and hq_str not in offices_clean:
        offices_clean.insert(0, hq_str)

    open_jobs = _parse_int_number(_first_non_empty(
        hiring.get("open_jobs_count"),
        hiring.get("job_openings_count"),
        hiring.get("total_open_jobs"),
        comp.get("job_openings_count"),
    ))
    depts = _first_non_empty(hiring.get("departments_hiring"), hiring.get("departments"), [])

    return {
        "crustdata_company_id": fallback_id,
        "basic_info": {
            "name": name,
            "legal_name": legal_name,
            "primary_domain": domain,
            "website": website,
            "year_founded": year_founded,
            "incorporation_year": inc_year,
            "industries": industries if isinstance(industries, list) else [str(industries)],
            "description": str(desc),
        },
        "headcount": {
            "total": hc_total,
            "range": hc_range,
            "yoy_growth_pct": float(hc_growth) if isinstance(hc_growth, (int, float)) else None,
        },
        "funding": {
            "total_investment_usd": tot_funding,
            "last_funding_round_type": str(last_round_type) if last_round_type else None,
            "last_funding_round_amount_usd": last_round_usd,
            "investors": investors_clean,
        },
        "locations": {
            "headquarters": hq_str,
            "offices": offices_clean,
        },
        "hiring": {
            "open_jobs_count": open_jobs,
            "departments_hiring": depts if isinstance(depts, list) else [],
        },
    }


def normalize_people_profiles(raw_resp: Any) -> list[dict[str, Any]]:
    """Normalize Crustdata /person/search and /person/enrich responses into canonical leadership records."""
    items = raw_resp
    if isinstance(raw_resp, dict):
        items = _first_non_empty(raw_resp.get("profiles"), raw_resp.get("data"), raw_resp.get("people"), raw_resp.get("results"), [])
    if not isinstance(items, list):
        items = [items]

    normalized: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for idx, p in enumerate(items):
        if not isinstance(p, dict):
            continue
        bp = p.get("basic_profile") if isinstance(p.get("basic_profile"), dict) else {}
        exp = p.get("experience") if isinstance(p.get("experience"), dict) else {}
        emp_details = exp.get("employment_details") if isinstance(exp.get("employment_details"), dict) else {}
        current_roles = emp_details.get("current") if isinstance(emp_details.get("current"), list) else (p.get("current_employers") if isinstance(p.get("current_employers"), list) else [])
        past_roles = emp_details.get("past") if isinstance(emp_details.get("past"), list) else (p.get("past_employers") if isinstance(p.get("past_employers"), list) else [])
        social = p.get("social_handles") if isinstance(p.get("social_handles"), dict) else {}

        name = _first_non_empty(
            p.get("name"),
            bp.get("full_name"),
            bp.get("name"),
            f"{bp.get('first_name', '')} {bp.get('last_name', '')}".strip() or None,
        )
        if not name:
            continue

        cur_role_0 = current_roles[0] if (current_roles and isinstance(current_roles[0], dict)) else {}
        title = _first_non_empty(
            p.get("title"),
            bp.get("current_title"),
            cur_role_0.get("title"),
            bp.get("headline"),
            p.get("headline"),
            "Executive",
        )
        profile_url = _first_non_empty(
            p.get("profile_url"),
            bp.get("linkedin_url"),
            social.get("linkedin_url"),
            social.get("professional_network_url"),
            p.get("linkedin_url"),
        )
        dedup_key = str(profile_url or name).casefold()
        if dedup_key in seen_keys:
            continue
        seen_keys.add(dedup_key)

        start_date = _first_non_empty(
            p.get("start_date"),
            cur_role_0.get("start_date"),
            cur_role_0.get("date_from"),
        )

        past_emp_names: list[str] = []
        for r in past_roles:
            if isinstance(r, str) and r.strip():
                if r.strip() not in past_emp_names:
                    past_emp_names.append(r.strip())
            elif isinstance(r, dict):
                c_name = _first_non_empty(r.get("company_name"), r.get("employer_name"), r.get("name"), (r.get("company") or {}).get("name") if isinstance(r.get("company"), dict) else None)
                if c_name and str(c_name).strip() not in past_emp_names:
                    past_emp_names.append(str(c_name).strip())

        edu_list: list[str] = []
        raw_edu = _first_non_empty(p.get("education"), (p.get("education") or {}).get("schools") if isinstance(p.get("education"), dict) else None, [])
        if isinstance(raw_edu, list):
            for ed in raw_edu:
                if isinstance(ed, str):
                    edu_list.append(ed)
                elif isinstance(ed, dict) and _first_non_empty(ed.get("school_name"), ed.get("institute_name"), ed.get("name")):
                    edu_list.append(str(_first_non_empty(ed.get("school_name"), ed.get("institute_name"), ed.get("name"))))

        normalized.append({
            "person_id": str(_first_non_empty(p.get("person_id"), p.get("id"), bp.get("person_id"), f"cd_person_{idx}")),
            "name": str(name),
            "title": str(title),
            "profile_url": str(profile_url) if profile_url else None,
            "start_date": str(start_date)[:7] if start_date else None,
            "past_employers": past_emp_names,
            "education": edu_list,
            "summary": str(_first_non_empty(p.get("summary"), bp.get("summary"), bp.get("headline"), f"{name} — {title}")),
        })
    return normalized
