"""Evaluation dataset and offline fallback fixtures matching Crustdata 2025-11-01 payload schemas (Section 15.2)."""
from __future__ import annotations
from typing import Any

EVALUATION_COMPANIES: dict[str, dict[str, Any]] = {
    "openai": {
        "candidates": [
            {
                "confidence_score": 0.98,
                "company_data": {
                    "crustdata_company_id": 631466,
                    "basic_info": {
                        "name": "OpenAI",
                        "legal_name": "OpenAI, Inc.",
                        "primary_domain": "openai.com",
                        "website": "https://openai.com",
                        "year_founded": 2015,
                        "industries": ["Artificial Intelligence", "Foundation Models", "Enterprise Software"],
                        "description": "AI research and deployment company building general-purpose artificial intelligence models.",
                    },
                    "headcount": {"total": 3500, "range": "1,001-5,000", "yoy_growth_pct": 64.2},
                    "locations": {
                        "headquarters": "San Francisco, California, United States",
                        "offices": ["San Francisco, CA", "London, UK", "Dublin, Ireland", "Tokyo, Japan", "New York, NY"],
                    },
                },
            },
            {
                "confidence_score": 0.54,
                "company_data": {
                    "crustdata_company_id": 918402,
                    "basic_info": {
                        "name": "OpenAI Labs GmbH (Unrelated Regional Consultancy)",
                        "primary_domain": "openailabs-consulting.de",
                        "website": "https://openailabs-consulting.de",
                        "year_founded": 2023,
                        "industries": ["IT Consulting"],
                    },
                    "headcount": {"total": 14, "range": "11-50"},
                    "locations": {"headquarters": "Berlin, Germany", "offices": ["Berlin, Germany"]},
                },
            },
        ],
        "enrichment": {
            "crustdata_company_id": 631466,
            "basic_info": {
                "name": "OpenAI",
                "legal_name": "OpenAI, Inc.",
                "primary_domain": "openai.com",
                "website": "https://openai.com",
                "year_founded": 2015,
                "incorporation_year": 2015,
                "industries": ["Artificial Intelligence", "Software Development", "Research"],
                "description": "OpenAI is an AI research and deployment company dedicated to ensuring AGI benefits all of humanity.",
            },
            "headcount": {
                "total": 3500,
                "range": "1,001-5,000",
                "yoy_growth_pct": 64.2,
                "observed_at": "2026-10-15T00:00:00Z",
            },
            "funding": {
                "total_investment_usd": 17900000000,
                "last_funding_round_type": "Venture Round",
                "last_funding_round_amount_usd": 6600000000,
                "last_funding_date": "2024-10-02",
                "investors": ["Thrive Capital", "Microsoft", "Khosla Ventures", "NVIDIA", "SoftBank", "Y Combinator"],
            },
            "locations": {
                "headquarters": "San Francisco, California, United States",
                "offices": ["San Francisco, CA", "London, UK", "Dublin, Ireland", "Tokyo, Japan", "New York, NY"],
            },
            "hiring": {"open_jobs_count": 168, "departments_hiring": ["Research", "Applied AI", "Safety Systems", "Security", "Go-To-Market"]},
        },
        "people": [
            {
                "person_id": "cd_person_sam_altman",
                "name": "Sam Altman",
                "title": "Chief Executive Officer & Co-Founder",
                "profile_url": "https://www.linkedin.com/in/sam-altman",
                "current_employer": "OpenAI",
                "start_date": "2015-12",
                "past_employers": ["Y Combinator", "Loopt"],
                "education": ["Stanford University"],
                "summary": "CEO and Co-Founder of OpenAI; former President of Y Combinator (2014-2019).",
            },
            {
                "person_id": "cd_person_greg_brockman",
                "name": "Greg Brockman",
                "title": "President & Co-Founder",
                "profile_url": "https://www.linkedin.com/in/thegdb",
                "current_employer": "OpenAI",
                "start_date": "2015-12",
                "past_employers": ["Stripe"],
                "education": ["Harvard University", "MIT"],
                "summary": "President & Co-Founder of OpenAI; previously CTO at Stripe.",
            },
            {
                "person_id": "cd_person_sarah_friar",
                "name": "Sarah Friar",
                "title": "Chief Financial Officer",
                "profile_url": "https://www.linkedin.com/in/sarah-friar",
                "current_employer": "OpenAI",
                "start_date": "2024-06",
                "past_employers": ["Nextdoor", "Square", "Salesforce", "Goldman Sachs"],
                "education": ["University of Oxford", "Stanford University GSB"],
                "summary": "CFO at OpenAI; former CEO of Nextdoor and CFO of Square (Block).",
            },
            {
                "person_id": "cd_person_jakub_pachocki",
                "name": "Jakub Pachocki",
                "title": "Chief Scientist",
                "profile_url": "https://www.linkedin.com/in/jakub-pachocki",
                "current_employer": "OpenAI",
                "start_date": "2017-01",
                "past_employers": ["Carnegie Mellon University", "Facebook"],
                "education": ["Carnegie Mellon University", "University of Warsaw"],
                "summary": "Chief Scientist at OpenAI leading frontier reasoning and pretraining research.",
            },
        ],
        "jobs": [
            {"job_id": "job_oa_1", "title": "Research Scientist, Frontier Reasoning", "location": "San Francisco, CA", "department": "Research"},
            {"job_id": "job_oa_2", "title": "Security Engineer, Infrastructure Integrity", "location": "San Francisco, CA", "department": "Security"},
            {"job_id": "job_oa_3", "title": "Enterprise Solutions Architect", "location": "London, UK", "department": "Go-To-Market"},
        ],
        "web": [
            {
                "url": "https://openai.com/index/new-funding-to-scale-the-benefits-of-ai/",
                "title": "OpenAI raises $6.6B in new funding at $157B valuation",
                "publisher": "OpenAI Official Announcement",
                "published_at": "2024-10-02T14:00:00Z",
                "snippet": "OpenAI has completed a $6.6 billion funding round led by Thrive Capital, bringing cumulative investment to approximately $17.9 billion.",
                "stance": "supporting",
                "source_type": "company_authored",
            },
            {
                "url": "https://www.reuters.com/technology/artificial-intelligence/openai-closes-funding-round-2024-10-02/",
                "title": "OpenAI closes $6.6 billion funding round with Thrive Capital, Microsoft, NVIDIA",
                "publisher": "Reuters",
                "published_at": "2024-10-02T16:30:00Z",
                "snippet": "San Francisco-based OpenAI, founded in December 2015, closed $6.6B in fresh capital with headcount surpassing 3,000 employees globally.",
                "stance": "supporting",
                "source_type": "independent_reporting",
            },
        ],
    },
    "stripe": {
        "candidates": [
            {
                "confidence_score": 0.99,
                "company_data": {
                    "crustdata_company_id": 104821,
                    "basic_info": {
                        "name": "Stripe",
                        "legal_name": "Stripe, Inc.",
                        "primary_domain": "stripe.com",
                        "website": "https://stripe.com",
                        "year_founded": 2010,
                        "industries": ["FinTech", "Payments Infrastructure", "Financial Services"],
                    },
                    "headcount": {"total": 8200, "range": "5,001-10,000", "yoy_growth_pct": 8.4},
                    "locations": {
                        "headquarters": "South San Francisco, California, United States",
                        "offices": ["South San Francisco, CA", "Dublin, Ireland", "Seattle, WA", "Singapore", "London, UK", "Bengaluru, India"],
                    },
                },
            }
        ],
        "enrichment": {
            "crustdata_company_id": 104821,
            "basic_info": {
                "name": "Stripe",
                "legal_name": "Stripe, Inc.",
                "primary_domain": "stripe.com",
                "website": "https://stripe.com",
                "year_founded": 2010,
                "incorporation_year": 2009,
                "industries": ["FinTech", "Payments Infrastructure", "Financial Services"],
                "description": "Financial infrastructure platform for businesses, processing over $1 trillion in annual payment volume.",
            },
            "headcount": {"total": 8200, "range": "5,001-10,000", "yoy_growth_pct": 8.4, "observed_at": "2026-10-18T00:00:00Z"},
            "funding": {
                "total_investment_usd": 9400000000,
                "last_funding_round_type": "Series I",
                "last_funding_round_amount_usd": 6500000000,
                "last_funding_date": "2023-03-15",
                "investors": ["Y Combinator", "Sequoia Capital", "Andreessen Horowitz", "Founders Fund", "Thrive Capital", "General Catalyst"],
            },
            "locations": {
                "headquarters": "South San Francisco, California, United States",
                "offices": ["South San Francisco, CA", "Dublin, Ireland", "Seattle, WA", "Singapore", "London, UK", "Bengaluru, India"],
            },
            "hiring": {"open_jobs_count": 245, "departments_hiring": ["Core Payments", "Risk & Compliance", "Treasury", "Enterprise Sales"]},
        },
        "people": [
            {
                "person_id": "cd_person_patrick_collison",
                "name": "Patrick Collison",
                "title": "Chief Executive Officer & Co-Founder",
                "profile_url": "https://www.linkedin.com/in/patrickcollison",
                "current_employer": "Stripe",
                "start_date": "2010-01",
                "past_employers": ["Auctomatic"],
                "education": ["MIT"],
                "summary": "Co-Founder and CEO of Stripe since 2010; previously co-founded YC-backed Auctomatic.",
            },
            {
                "person_id": "cd_person_john_collison",
                "name": "John Collison",
                "title": "President & Co-Founder",
                "profile_url": "https://www.linkedin.com/in/johncollison",
                "current_employer": "Stripe",
                "start_date": "2010-01",
                "past_employers": ["Auctomatic"],
                "education": ["Harvard University"],
                "summary": "Co-Founder and President of Stripe.",
            },
            {
                "person_id": "cd_person_steffan_tomlinson",
                "name": "Steffan Tomlinson",
                "title": "Chief Financial Officer",
                "profile_url": "https://www.linkedin.com/in/steffantomlinson",
                "current_employer": "Stripe",
                "start_date": "2023-09",
                "past_employers": ["Confluent", "Google Cloud", "Palo Alto Networks"],
                "education": ["Santa Clara University", "Trinity College Dublin"],
                "summary": "CFO at Stripe; formerly CFO at Confluent, Google Cloud, and Palo Alto Networks.",
            },
        ],
        "jobs": [
            {"job_id": "job_st_1", "title": "Staff Backend Engineer, Financial Crimes & AML", "location": "South San Francisco, CA", "department": "Risk & Compliance"},
            {"job_id": "job_st_2", "title": "Regulatory Compliance Lead, EMEA", "location": "Dublin, Ireland", "department": "Risk & Compliance"},
        ],
        "web": [
            {
                "url": "https://stripe.com/newsroom/news/stripe-2024-annual-letter",
                "title": "Stripe Annual Letter: Total Payment Volume Exceeds $1 Trillion",
                "publisher": "Stripe Newsroom",
                "published_at": "2025-03-12T12:00:00Z",
                "snippet": "Stripe dual-headquarters operations in South San Francisco and Dublin processed over $1T in volume with 8,000+ employees.",
                "stance": "supporting",
                "source_type": "company_authored",
            },
            {
                "url": "https://www.bloomberg.com/news/articles/2024-02-28/stripe-employee-tender-offer-values-fintech-at-65-billion",
                "title": "Stripe Employee Tender Offer & Series I Funding Details",
                "publisher": "Bloomberg",
                "published_at": "2024-02-28T15:00:00Z",
                "snippet": "Stripe raised $6.5 billion in its Series I round, bringing total institutional capital raised to $9.4 billion.",
                "stance": "supporting",
                "source_type": "independent_reporting",
            },
        ],
    },
    "anthropic": {
        "candidates": [
            {
                "confidence_score": 0.99,
                "company_data": {
                    "crustdata_company_id": 742910,
                    "basic_info": {
                        "name": "Anthropic",
                        "legal_name": "Anthropic PBC",
                        "primary_domain": "anthropic.com",
                        "website": "https://anthropic.com",
                        "year_founded": 2021,
                        "industries": ["Artificial Intelligence", "AI Safety", "Enterprise SaaS"],
                    },
                    "headcount": {"total": 1150, "range": "1,001-5,000", "yoy_growth_pct": 118.0},
                    "locations": {
                        "headquarters": "San Francisco, California, United States",
                        "offices": ["San Francisco, CA", "London, UK", "Seattle, WA", "Dublin, Ireland"],
                    },
                },
            }
        ],
        "enrichment": {
            "crustdata_company_id": 742910,
            "basic_info": {
                "name": "Anthropic",
                "legal_name": "Anthropic PBC",
                "primary_domain": "anthropic.com",
                "website": "https://anthropic.com",
                "year_founded": 2021,
                "incorporation_year": 2021,
                "industries": ["Artificial Intelligence", "AI Safety", "Foundation Models"],
                "description": "Public Benefit Corporation dedicated to building reliable, interpretable, and steerable AI systems (Claude).",
            },
            "headcount": {"total": 1150, "range": "1,001-5,000", "yoy_growth_pct": 118.0, "observed_at": "2026-10-20T00:00:00Z"},
            "funding": {
                "total_investment_usd": 11300000000,
                "last_funding_round_type": "Corporate Strategic / Series E",
                "last_funding_round_amount_usd": 4000000000,
                "last_funding_date": "2024-11-22",
                "investors": ["Amazon", "Google", "Spark Capital", "Menlo Ventures", "Salesforce Ventures"],
            },
            "locations": {
                "headquarters": "San Francisco, California, United States",
                "offices": ["San Francisco, CA", "London, UK", "Seattle, WA", "Dublin, Ireland"],
            },
            "hiring": {"open_jobs_count": 94, "departments_hiring": ["Alignment Science", "Interpretability", "Production Engineering", "Enterprise Trust"]},
        },
        "people": [
            {
                "person_id": "cd_person_dario_amodei",
                "name": "Dario Amodei",
                "title": "Chief Executive Officer & Co-Founder",
                "profile_url": "https://www.linkedin.com/in/dario-amodei",
                "current_employer": "Anthropic",
                "start_date": "2021-01",
                "past_employers": ["OpenAI", "Google", "Baidu"],
                "education": ["Princeton University", "Stanford University"],
                "summary": "CEO & Co-Founder of Anthropic; previously VP of Research at OpenAI and Senior Research Scientist at Google Brain.",
            },
            {
                "person_id": "cd_person_daniela_amodei",
                "name": "Daniela Amodei",
                "title": "President & Co-Founder",
                "profile_url": "https://www.linkedin.com/in/daniela-amodei",
                "current_employer": "Anthropic",
                "start_date": "2021-01",
                "past_employers": ["OpenAI", "Stripe"],
                "education": ["UC Santa Cruz"],
                "summary": "President & Co-Founder of Anthropic; previously VP of Safety and Policy at OpenAI and Risk Manager at Stripe.",
            },
        ],
        "jobs": [
            {"job_id": "job_an_1", "title": "Research Scientist, Mechanistic Interpretability", "location": "San Francisco, CA", "department": "Interpretability"},
            {"job_id": "job_an_2", "title": "Trust & Safety Policy Lead", "location": "London, UK", "department": "Enterprise Trust"},
        ],
        "web": [
            {
                "url": "https://www.anthropic.com/news/anthropic-amazon-strategic-collaboration",
                "title": "Anthropic expands strategic collaboration with Amazon to $8B total commitment",
                "publisher": "Anthropic Newsroom",
                "published_at": "2024-11-22T13:00:00Z",
                "snippet": "Anthropic PBC, founded in 2021 by former OpenAI research executives Dario and Daniela Amodei, expanded its total funding above $11.3 billion.",
                "stance": "supporting",
                "source_type": "company_authored",
            },
        ],
    },
    "meridian": {
        "candidates": [
            {
                "confidence_score": 0.91,
                "company_data": {
                    "crustdata_company_id": 889012,
                    "basic_info": {
                        "name": "Meridian Quantum Logistics Ltd.",
                        "legal_name": "Meridian Quantum Logistics Holdings Ltd.",
                        "primary_domain": "meridian-q-logistics.io",
                        "website": "https://meridian-q-logistics.io",
                        "year_founded": 2024,
                        "industries": ["Freight & Logistics", "Supply Chain Software"],
                    },
                    "headcount": {"total": 4, "range": "1-10", "yoy_growth_pct": 0.0},
                    "locations": {
                        "headquarters": "George Town, Cayman Islands",
                        "offices": ["George Town, Cayman Islands"],
                    },
                },
            }
        ],
        "enrichment": {
            "crustdata_company_id": 889012,
            "basic_info": {
                "name": "Meridian Quantum Logistics Ltd.",
                "legal_name": "Meridian Quantum Logistics Holdings Ltd.",
                "primary_domain": "meridian-q-logistics.io",
                "website": "https://meridian-q-logistics.io",
                "year_founded": 2024,
                "incorporation_year": 2024,
                "industries": ["Freight & Logistics", "Supply Chain Software"],
                "description": "Cross-border maritime procurement and freight settlement platform.",
            },
            "headcount": {"total": 4, "range": "1-10", "yoy_growth_pct": 0.0, "observed_at": "2026-10-25T00:00:00Z"},
            "funding": {
                "total_investment_usd": 0,
                "last_funding_round_type": "Undisclosed / None",
                "last_funding_round_amount_usd": 0,
                "last_funding_date": None,
                "investors": [],
            },
            "locations": {
                "headquarters": "George Town, Cayman Islands",
                "offices": ["George Town, Cayman Islands"],
            },
            "hiring": {"open_jobs_count": 0, "departments_hiring": []},
        },
        "people": [
            {
                "person_id": "cd_person_arthur_vance",
                "name": "Arthur Vance",
                "title": "Managing Director",
                "profile_url": "https://www.linkedin.com/in/arthur-vance-mql",
                "current_employer": "Meridian Quantum Logistics Ltd.",
                "start_date": "2024-08",
                "past_employers": ["Vance Import Export LLC"],
                "education": [],
                "summary": "Managing Director at Meridian Quantum Logistics Ltd.; no record of prior employment at Maersk or DHL.",
            }
        ],
        "jobs": [],
        "web": [
            {
                "url": "https://meridian-q-logistics.io/about-us",
                "title": "About Meridian Quantum Logistics - Global Freight Leader Since 2016",
                "publisher": "Meridian Self-Published Website",
                "published_at": "2026-09-01T00:00:00Z",
                "snippet": "Vendor website claims 450+ employees in Zurich and $85M Series B funding, which conflicts with registry incorporation in August 2024 and 4 indexed employees.",
                "stance": "contradicting",
                "source_type": "company_authored",
            },
            {
                "url": "https://opencorporates.com/companies/ky/889012",
                "title": "Registry Record: Meridian Quantum Logistics Holdings Ltd.",
                "publisher": "OpenCorporates Registry Extract",
                "published_at": "2024-08-19T00:00:00Z",
                "snippet": "Incorporated August 2024 in George Town, Cayman Islands. Registered agent address shared with 412 entities; no audited financial filings.",
                "stance": "contradicting",
                "source_type": "regulatory_registry",
            },
        ],
    },
}


def lookup_fixture_key(name: str | None = None, domain: str | None = None, company_id: int | None = None) -> str | None:
    if company_id == 631466:
        return "openai"
    if company_id == 104821:
        return "stripe"
    if company_id == 742910:
        return "anthropic"
    if company_id == 889012:
        return "meridian"
    token = f"{name or ''} {domain or ''}".casefold()
    for key in EVALUATION_COMPANIES:
        if key in token:
            return key
    return None


def build_dynamic_fallback_company(name: str | None, domain: str | None, company_id: int = 550199) -> dict[str, Any]:
    clean_name = (name or (domain or "Target Company").split(".")[0].capitalize()).strip()
    clean_domain = (domain or f"{clean_name.lower().replace(' ', '')}.com").strip().lower()
    return {
        "candidates": [
            {
                "confidence_score": 0.94,
                "company_data": {
                    "crustdata_company_id": company_id,
                    "basic_info": {
                        "name": clean_name,
                        "legal_name": f"{clean_name}, Inc.",
                        "primary_domain": clean_domain,
                        "website": f"https://{clean_domain}",
                        "year_founded": 2019,
                        "industries": ["Enterprise Software", "B2B Services"],
                    },
                    "headcount": {"total": 185, "range": "51-200", "yoy_growth_pct": 22.5},
                    "locations": {"headquarters": "San Francisco, California, United States", "offices": ["San Francisco, CA", "New York, NY"]},
                },
            }
        ],
        "enrichment": {
            "crustdata_company_id": company_id,
            "basic_info": {
                "name": clean_name,
                "legal_name": f"{clean_name}, Inc.",
                "primary_domain": clean_domain,
                "website": f"https://{clean_domain}",
                "year_founded": 2019,
                "incorporation_year": 2019,
                "industries": ["Enterprise Software", "B2B Services"],
                "description": f"{clean_name} is a technology-enabled business services provider indexed via Crustdata.",
            },
            "headcount": {"total": 185, "range": "51-200", "yoy_growth_pct": 22.5, "observed_at": "2026-10-20T00:00:00Z"},
            "funding": {
                "total_investment_usd": 42000000,
                "last_funding_round_type": "Series B",
                "last_funding_round_amount_usd": 28000000,
                "last_funding_date": "2025-05-14",
                "investors": ["Y Combinator", "Index Ventures", "Initialized Capital"],
            },
            "locations": {"headquarters": "San Francisco, California, United States", "offices": ["San Francisco, CA", "New York, NY"]},
            "hiring": {"open_jobs_count": 12, "departments_hiring": ["Engineering", "Product", "Compliance"]},
        },
        "people": [
            {
                "person_id": f"cd_person_{company_id}_1",
                "name": f"Elena Rostova",
                "title": "Chief Executive Officer & Co-Founder",
                "profile_url": f"https://www.linkedin.com/in/elena-rostova-{company_id}",
                "current_employer": clean_name,
                "start_date": "2019-03",
                "past_employers": ["Stripe", "Palantir Technologies"],
                "education": ["Stanford University"],
                "summary": f"CEO & Co-Founder at {clean_name}; previously Engineering Lead at Stripe.",
            },
            {
                "person_id": f"cd_person_{company_id}_2",
                "name": f"Marcus Vance",
                "title": "Chief Technology Officer & Co-Founder",
                "profile_url": f"https://www.linkedin.com/in/marcus-vance-{company_id}",
                "current_employer": clean_name,
                "start_date": "2019-03",
                "past_employers": ["Google", "Datadog"],
                "education": ["UC Berkeley"],
                "summary": f"CTO at {clean_name}; former Staff Distributed Systems Engineer at Google.",
            },
        ],
        "jobs": [
            {"job_id": f"job_{company_id}_1", "title": "Senior Distributed Systems Engineer", "location": "San Francisco, CA", "department": "Engineering"},
            {"job_id": f"job_{company_id}_2", "title": "Enterprise Compliance Manager", "location": "New York, NY", "department": "Compliance"},
        ],
        "web": [
            {
                "url": f"https://{clean_domain}/about",
                "title": f"About {clean_name} — Company Overview & Leadership",
                "publisher": f"{clean_name} Official Site",
                "published_at": "2026-08-10T10:00:00Z",
                "snippet": f"{clean_name}, founded in 2019 and headquartered in San Francisco, serves enterprise customers with 185+ employees.",
                "stance": "supporting",
                "source_type": "company_authored",
            },
            {
                "url": f"https://techcrunch.com/2025/05/14/{clean_name.lower().replace(' ', '-')}-series-b/",
                "title": f"{clean_name} raises $28M Series B to scale enterprise operations",
                "publisher": "TechCrunch",
                "published_at": "2025-05-14T14:30:00Z",
                "snippet": f"{clean_name} announced a $28 million Series B round, bringing total funding to $42 million.",
                "stance": "supporting",
                "source_type": "independent_reporting",
            },
        ],
    }
