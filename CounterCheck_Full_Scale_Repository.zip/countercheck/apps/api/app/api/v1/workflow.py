from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.services.investigation_workflow import resolve_and_enrich

router = APIRouter(prefix="/api/v1/investigations", tags=["investigation-workflow"])

@router.post("/{investigation_id}/resolve-and-enrich")
async def run_company_retrieval(investigation_id: str, db: Session = Depends(get_db)):
    try:
        return await resolve_and_enrich(investigation_id, db)
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Investigation retrieval failed") from exc
