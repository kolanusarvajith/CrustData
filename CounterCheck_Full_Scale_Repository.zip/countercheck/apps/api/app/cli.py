"""CounterCheck CLI for running end-to-end due-diligence investigations from the terminal."""
from __future__ import annotations
import argparse
import asyncio
import json
from pathlib import Path
from app.core.store import store
from app.integrations.llm.provider import OllamaProvider
from app.services.claim_extraction import extract_claims
from app.services.investigation_workflow import run_full_investigation_pipeline
from app.services.pdf_report import render_report_pdf


async def run_cli(args: argparse.Namespace) -> None:
    llm = OllamaProvider()
    claims_list = []
    if args.pitch_text:
        extracted = await extract_claims(llm, args.company or args.domain or "Target", args.pitch_text, allow_heuristic_fallback=True)
        claims_list.extend(extracted.get("claims", []))
    for c_str in args.claim or []:
        extracted = await extract_claims(llm, args.company or args.domain or "Target", c_str, allow_heuristic_fallback=True)
        claims_list.extend(extracted.get("claims", []))

    if not claims_list:
        claims_list = [
            {
                "category": "founding_year",
                "subject": args.company or args.domain or "Target",
                "metric": "year_founded",
                "operator": "equals",
                "claimed_value": 2015,
                "original_text": "Company was founded in 2015.",
            }
        ]

    created = store.create_investigation(
        company_name=args.company if not args.domain else None,
        company_domain=args.domain,
        purpose=args.purpose,
        claims=claims_list,
    )
    result = await run_full_investigation_pipeline(
        created["id"],
        auto_select_top_candidate=not args.require_disambiguation,
    )
    if args.pdf_out and result.get("reports"):
        pdf_bytes = render_report_pdf(result["reports"][0]["content"])
        Path(args.pdf_out).write_bytes(pdf_bytes)
    print(json.dumps({
        "investigation_id": result["id"],
        "status": result["status"],
        "company_name": result.get("company_name"),
        "company_crustdata_id": result.get("company_crustdata_id"),
        "verdicts": [
            {
                "claim": c["original_text"],
                "category": c["category"],
                "verdict": (c.get("verdict") or {}).get("status"),
                "explanation": (c.get("verdict") or {}).get("explanation"),
            }
            for c in result.get("claims", [])
        ],
        "credits": result.get("credit_usage"),
        "pdf_saved": args.pdf_out,
    }, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="CounterCheck Autonomous Due Diligence CLI")
    parser.add_argument("--company", type=str, help="Company name to investigate")
    parser.add_argument("--domain", type=str, help="Company domain to investigate")
    parser.add_argument("--purpose", type=str, default="CLI Due Diligence Investigation")
    parser.add_argument("--pitch-text", type=str, help="Unstructured vendor pitch or data room text to extract claims from")
    parser.add_argument("--claim", action="append", help="Individual claim sentence (can be passed multiple times)")
    parser.add_argument("--require-disambiguation", action="store_true", help="Pause if multiple candidates match")
    parser.add_argument("--pdf-out", type=str, help="Optional file path to save the PDF dossier")
    parsed = parser.parse_args()
    if not parsed.company and not parsed.domain:
        parser.error("Provide --company or --domain")
    asyncio.run(run_cli(parsed))


if __name__ == "__main__":
    main()
