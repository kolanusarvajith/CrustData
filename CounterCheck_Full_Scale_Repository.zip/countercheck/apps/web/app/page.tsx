"use client";

import React, { useState, useEffect, useMemo } from "react";

type VerdictStatus = "SUPPORTED" | "CONTRADICTED" | "UNVERIFIED" | "CONFLICTING";

interface HumanReview {
  id: string;
  reviewer_id: string;
  disposition: "accepted" | "needs_follow_up" | "overridden";
  override_status?: VerdictStatus | null;
  override_reason?: string | null;
  created_at: string;
}

interface ClaimItem {
  id: string;
  category: string;
  subject: string;
  metric: string;
  operator: string;
  claimed_value: any;
  unit?: string | null;
  period?: string | null;
  original_text: string;
  ambiguity_flags?: string[];
  verdict?: {
    status: VerdictStatus;
    explanation: string;
    confidence_band: string;
    rule_version: string;
    evidence_ids: string[];
  } | null;
  human_review?: HumanReview | null;
}

interface EvidenceItem {
  id: string;
  provider: string;
  provider_entity_id?: string;
  source_url?: string | null;
  title: string;
  publisher: string;
  source_quality: string;
  retrieved_at: string;
  content_hash: string;
  limitations?: string;
  annotations?: { id: string; author: string; note: string; created_at: string }[];
}

interface GraphNode {
  id: string;
  type: "company" | "person" | "employer" | "investor" | "location" | "source";
  label: string;
  subtitle?: string;
  evidence_ids: string[];
}

interface GraphEdge {
  id: string;
  source: string;
  target: string;
  relation: string;
  temporal_label?: string;
  evidence_ids: string[];
}

interface InvestigationDossier {
  id: string;
  status: string;
  current_stage: string;
  company_identifier: string;
  company_name?: string;
  company_domain?: string;
  company_crustdata_id?: number;
  purpose: string;
  candidates: any[];
  company_profile: any;
  people: any[];
  jobs: any[];
  graph: { nodes: GraphNode[]; edges: GraphEdge[] };
  quality_warnings: string[];
  claims: ClaimItem[];
  evidence_sources: EvidenceItem[];
  observations: any[];
  events: any[];
  credit_usage: {
    items: any[];
    estimated_total: number;
    actual_total: number;
    budget_cap: number;
  };
  reports: any[];
  audit_events: any[];
  created_at: string;
  updated_at: string;
}

const DEFAULT_API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

const INITIAL_FALLBACK_DOSSIERS: InvestigationDossier[] = [
  {
    id: "inv_stripe_01",
    status: "completed",
    current_stage: "completed",
    company_identifier: "stripe.com",
    company_name: "Stripe",
    company_domain: "stripe.com",
    company_crustdata_id: 104821,
    purpose: "Enterprise Vendor & FinTech Counterparty Due Diligence",
    candidates: [
      { id: 104821, name: "Stripe", domain: "stripe.com", year_founded: 2010, employee_count_range: "5,001-10,000", headquarters: "South San Francisco, CA", confidence: 0.99 }
    ],
    company_profile: {
      basic_info: { name: "Stripe", legal_name: "Stripe, Inc.", primary_domain: "stripe.com", year_founded: 2010, industries: ["FinTech", "Payments Infrastructure"] },
      headcount: { total: 8200, range: "5,001-10,000", yoy_growth_pct: 8.4 },
      funding: { total_investment_usd: 9400000000, last_funding_round_type: "Series I", last_funding_round_amount_usd: 6500000000, investors: ["Y Combinator", "Sequoia Capital", "Andreessen Horowitz", "Thrive Capital"] },
      locations: { headquarters: "South San Francisco, California, United States", offices: ["South San Francisco, CA", "Dublin, Ireland", "London, UK", "Singapore", "Bengaluru, India"] },
      hiring: { open_jobs_count: 245, departments_hiring: ["Core Payments", "Risk & Compliance", "Treasury"] }
    },
    people: [
      { person_id: "p1", name: "Patrick Collison", title: "Chief Executive Officer & Co-Founder", current_employer: "Stripe", start_date: "2010-01", past_employers: ["Auctomatic"], profile_url: "https://www.linkedin.com/in/patrickcollison" },
      { person_id: "p2", name: "John Collison", title: "President & Co-Founder", current_employer: "Stripe", start_date: "2010-01", past_employers: ["Auctomatic"], profile_url: "https://www.linkedin.com/in/johncollison" },
      { person_id: "p3", name: "Steffan Tomlinson", title: "Chief Financial Officer", current_employer: "Stripe", start_date: "2023-09", past_employers: ["Confluent", "Google Cloud", "Palo Alto Networks"], profile_url: "https://www.linkedin.com/in/steffantomlinson" }
    ],
    jobs: [
      { job_id: "j1", title: "Staff Backend Engineer, Financial Crimes & AML", location: "South San Francisco, CA", department: "Risk & Compliance" },
      { job_id: "j2", title: "Regulatory Compliance Lead, EMEA", location: "Dublin, Ireland", department: "Risk & Compliance" }
    ],
    graph: {
      nodes: [
        { id: "n_comp", type: "company", label: "Stripe", subtitle: "stripe.com (#104821)", evidence_ids: ["ev_comp_104821"] },
        { id: "n_hq", type: "location", label: "South San Francisco", subtitle: "Global HQ", evidence_ids: ["ev_comp_104821"] },
        { id: "n_p1", type: "person", label: "Patrick Collison", subtitle: "CEO & Co-Founder", evidence_ids: ["ev_people_104821"] },
        { id: "n_p3", type: "person", label: "Steffan Tomlinson", subtitle: "CFO", evidence_ids: ["ev_people_104821"] },
        { id: "n_emp1", type: "employer", label: "Confluent", subtitle: "Prior Employer (CFO)", evidence_ids: ["ev_people_104821"] },
        { id: "n_inv1", type: "investor", label: "Sequoia Capital", subtitle: "Institutional Investor", evidence_ids: ["ev_comp_104821"] },
        { id: "n_src1", type: "source", label: "Bloomberg", subtitle: "Series I Corroboration", evidence_ids: ["ev_web_104821_2"] }
      ],
      edges: [
        { id: "e1", source: "n_comp", target: "n_hq", relation: "headquartered_in", temporal_label: "Current HQ", evidence_ids: ["ev_comp_104821"] },
        { id: "e2", source: "n_comp", target: "n_p1", relation: "founded_by", temporal_label: "Since 2010", evidence_ids: ["ev_people_104821"] },
        { id: "e3", source: "n_p3", target: "n_comp", relation: "employed_by", temporal_label: "Since 2023-09", evidence_ids: ["ev_people_104821"] },
        { id: "e4", source: "n_p3", target: "n_emp1", relation: "employed_by", temporal_label: "Prior Role", evidence_ids: ["ev_people_104821"] },
        { id: "e5", source: "n_inv1", target: "n_comp", relation: "invested_in", temporal_label: "Series I", evidence_ids: ["ev_comp_104821"] },
        { id: "e6", source: "n_src1", target: "n_comp", relation: "corroborated_by", temporal_label: "independent_reporting", evidence_ids: ["ev_web_104821_2"] }
      ]
    },
    quality_warnings: [],
    claims: [
      {
        id: "clm_st_1",
        category: "founding_year",
        subject: "Stripe",
        metric: "year_founded",
        operator: "equals",
        claimed_value: 2010,
        unit: "year",
        period: "2010",
        original_text: "Stripe was founded in 2010 by Patrick and John Collison.",
        verdict: { status: "SUPPORTED", explanation: "Observed founding year is 2010, matching the claim.", confidence_band: "HIGH", rule_version: "2.1.0", evidence_ids: ["ev_comp_104821"] }
      },
      {
        id: "clm_st_2",
        category: "headcount",
        subject: "Stripe",
        metric: "headcount.total",
        operator: "approx",
        claimed_value: 8000,
        unit: "employees",
        period: "current",
        original_text: "Stripe operates globally with approximately 8,000 full-time employees.",
        verdict: { status: "SUPPORTED", explanation: "Observed headcount is 8,200 (provider estimate), within ±12% tolerance of claimed 8,000.", confidence_band: "MEDIUM", rule_version: "2.1.0", evidence_ids: ["ev_comp_104821"] }
      },
      {
        id: "clm_st_3",
        category: "funding",
        subject: "Stripe",
        metric: "total_investment_usd",
        operator: "approx",
        claimed_value: "$9.4B",
        unit: "USD",
        period: "cumulative",
        original_text: "Stripe has raised approximately $9.4 billion in cumulative institutional funding.",
        verdict: { status: "SUPPORTED", explanation: "Observed value 9.4e+09 satisfies claimed approx 9.4e+09.", confidence_band: "HIGH", rule_version: "2.1.0", evidence_ids: ["ev_comp_104821", "ev_web_104821_2"] }
      },
      {
        id: "clm_st_4",
        category: "leadership",
        subject: "Steffan Tomlinson",
        metric: "executive_history",
        operator: "contains",
        claimed_value: "Confluent",
        original_text: "CFO Steffan Tomlinson previously served as CFO at Confluent and Google Cloud.",
        verdict: { status: "SUPPORTED", explanation: "Verified executive profile for Steffan Tomlinson (CFO; prior: Confluent, Google Cloud, Palo Alto Networks) corroborates the claim.", confidence_band: "HIGH", rule_version: "2.1.0", evidence_ids: ["ev_people_104821"] }
      }
    ],
    evidence_sources: [
      { id: "ev_comp_104821", provider: "crustdata", provider_entity_id: "104821", source_url: "https://api.crustdata.com/company/enrich?id=104821", title: "Crustdata Canonical Company Enrichment — Stripe (#104821)", publisher: "Crustdata Canonical Graph", source_quality: "provider_indexed", retrieved_at: "2026-10-31T08:00:00Z", content_hash: "a94f82c10e7b1192d34c910a", limitations: "Provider-indexed record; headcount and private funding metrics may be estimated.", annotations: [] },
      { id: "ev_people_104821", provider: "crustdata", provider_entity_id: "104821", source_url: "https://api.crustdata.com/person/search?company_id=104821", title: "Crustdata Executive & Leadership Profiles — Stripe (3 verified profiles)", publisher: "Crustdata People Graph", source_quality: "provider_indexed", retrieved_at: "2026-10-31T08:00:02Z", content_hash: "b73d91e20f4a8811c05e721b", limitations: "Professional network employment timelines reflect verified role dates.", annotations: [] },
      { id: "ev_web_104821_2", provider: "crustdata_web", provider_entity_id: "104821", source_url: "https://www.bloomberg.com/news/articles/2024-02-28/stripe-employee-tender-offer-values-fintech-at-65-billion", title: "Stripe Employee Tender Offer & Series I Funding Details", publisher: "Bloomberg", source_quality: "independent_reporting", retrieved_at: "2026-10-31T08:00:05Z", content_hash: "c19e04f32a1b7743e92a118c", limitations: "Independent financial press reporting; credible secondary corroboration.", annotations: [] }
    ],
    observations: [
      { id: "obs_1", evidence_source_id: "ev_comp_104821", field_path: "basic_info.year_founded", raw_value: 2010, normalized_value: 2010, unit: "year" },
      { id: "obs_2", evidence_source_id: "ev_comp_104821", field_path: "headcount.total", raw_value: 8200, normalized_value: 8200, unit: "employees" },
      { id: "obs_3", evidence_source_id: "ev_comp_104821", field_path: "funding.total_investment_usd", raw_value: 9400000000, normalized_value: 9400000000, unit: "USD" },
      { id: "obs_4", evidence_source_id: "ev_comp_104821", field_path: "locations.headquarters", raw_value: "South San Francisco, California, United States", normalized_value: "South San Francisco, California, United States", unit: null }
    ],
    events: [
      { sequence: 1, stage: "resolving_identity", event_type: "identity_resolved", status: "running", message: "Resolved canonical entity: Stripe (Crustdata ID #104821, domain: stripe.com)", created_at: "2026-10-31T08:00:00Z" },
      { sequence: 2, stage: "retrieving_company", event_type: "stage_completed", status: "running", message: "Company enrichment normalized (8 structured observations stored).", created_at: "2026-10-31T08:00:02Z" },
      { sequence: 3, stage: "retrieving_people", event_type: "stage_completed", status: "running", message: "Retrieved 3 executive leadership profiles via /person/search.", created_at: "2026-10-31T08:00:04Z" },
      { sequence: 4, stage: "verifying", event_type: "stage_completed", status: "running", message: "Deterministic verification completed across 4 claims (rule engine v2.1.0).", created_at: "2026-10-31T08:00:06Z" },
      { sequence: 5, stage: "completed", event_type: "investigation_completed", status: "completed", message: "Investigation dossier completed (Report Snapshot v1).", created_at: "2026-10-31T08:00:08Z" }
    ],
    credit_usage: {
      items: [
        { id: "c1", endpoint: "/company/identify", estimated_credits: 0.0, actual_credits: 0.0, status_code: 200, latency_ms: 42.1, mode: "live", created_at: "2026-10-31T08:00:00Z" },
        { id: "c2", endpoint: "/company/enrich", estimated_credits: 2.0, actual_credits: 2.0, status_code: 200, latency_ms: 118.4, mode: "live", created_at: "2026-10-31T08:00:02Z" },
        { id: "c3", endpoint: "/person/search", estimated_credits: 0.09, actual_credits: 0.09, status_code: 200, latency_ms: 94.0, mode: "live", created_at: "2026-10-31T08:00:04Z" },
        { id: "c4", endpoint: "/job/search", estimated_credits: 0.06, actual_credits: 0.06, status_code: 200, latency_ms: 68.2, mode: "live", created_at: "2026-10-31T08:00:05Z" },
        { id: "c5", endpoint: "/web/search/live", estimated_credits: 1.0, actual_credits: 1.0, status_code: 200, latency_ms: 152.0, mode: "live", created_at: "2026-10-31T08:00:06Z" }
      ],
      estimated_total: 3.15,
      actual_total: 3.15,
      budget_cap: 50.0
    },
    reports: [
      {
        id: "rep_st_1",
        version: 1,
        content_hash: "8f3d91a04b2c771829e041f92a663b10294857abcdef1234567890abcdef1234",
        created_at: "2026-10-31T08:00:08Z",
        content: {
          executive_summary: "Automated evidence-first verification completed across 4 structured claims for Stripe (#104821): 4 SUPPORTED, 0 CONTRADICTED, and 0 UNVERIFIED. All verdicts were computed deterministically against Crustdata canonical records and corroborated financial press sources.",
          follow_up_questions: [
            "Confirm current regional subsidiary entity structure for EMEA payment processing.",
            "Verify latest headcount breakdown across regulated compliance functions."
          ]
        }
      }
    ],
    audit_events: [
      { id: "aud_1", actor_id: "analyst@countercheck.local", action: "investigation_created", object_type: "investigation", object_id: "inv_stripe_01", reason: "Initial intake submitted", created_at: "2026-10-31T08:00:00Z" }
    ],
    created_at: "2026-10-31T08:00:00Z",
    updated_at: "2026-10-31T08:00:08Z"
  }
];

export default function CounterCheckWorkspace() {
  const [apiBase, setApiBase] = useState<string>(DEFAULT_API_BASE);
  const [backendConnected, setBackendConnected] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"command" | "intake" | "room" | "review" | "vault" | "report">("command");
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Runtime config state
  const [crustdataKeyInput, setCrustdataKeyInput] = useState<string>("");
  const [crustdataConfigured, setCrustdataConfigured] = useState<boolean>(true);
  const [demoFallback, setDemoFallback] = useState<boolean>(true);
  const [globalKillSwitch, setGlobalKillSwitch] = useState<boolean>(false);
  const [budgetCap, setBudgetCap] = useState<number>(50);
  const [ollamaUrl, setOllamaUrl] = useState<string>("http://localhost:11434");
  const [ollamaModel, setOllamaModel] = useState<string>("qwen2.5:3b-instruct");
  const [installedModels, setInstalledModels] = useState<string[]>(["qwen2.5:3b-instruct", "llama3.2:3b", "mistral:latest"]);
  const [ollamaOnline, setOllamaOnline] = useState<boolean>(false);

  // Investigations state
  const [dossiers, setDossiers] = useState<InvestigationDossier[]>(INITIAL_FALLBACK_DOSSIERS);
  const [selectedId, setSelectedId] = useState<string>(INITIAL_FALLBACK_DOSSIERS[0].id);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");

  // New investigation intake state
  const [identifierMode, setIdentifierMode] = useState<"name" | "domain">("name");
  const [companyInput, setCompanyInput] = useState<string>("OpenAI");
  const [purposeInput, setPurposeInput] = useState<string>("Vendor & Counterparty Due Diligence");
  const [requireDisambiguation, setRequireDisambiguation] = useState<boolean>(true);
  const [pitchText, setPitchText] = useState<string>(
    "OpenAI was founded in 2015 and is headquartered in San Francisco, California. The company employs approximately 3,500 people globally and has raised $17.9 billion in cumulative funding. CEO Sam Altman previously served as President of Y Combinator."
  );
  const [draftClaims, setDraftClaims] = useState<any[]>([
    { category: "founding_year", subject: "OpenAI", metric: "year_founded", operator: "equals", claimed_value: 2015, unit: "year", period: "2015", original_text: "OpenAI was founded in 2015.", ambiguity_flags: [] },
    { category: "location", subject: "OpenAI", metric: "headquarters", operator: "equals", claimed_value: "San Francisco, CA", unit: null, period: "current", original_text: "Headquartered in San Francisco, California.", ambiguity_flags: [] },
    { category: "headcount", subject: "OpenAI", metric: "headcount.total", operator: "approx", claimed_value: 3500, unit: "employees", period: "current", original_text: "The company employs approximately 3,500 people globally.", ambiguity_flags: ["Self-reported headcount may include contractors"] },
    { category: "funding", subject: "OpenAI", metric: "total_investment_usd", operator: "approx", claimed_value: "$17.9B", unit: "USD", period: "cumulative", original_text: "Has raised $17.9 billion in cumulative funding.", ambiguity_flags: [] },
    { category: "leadership", subject: "Sam Altman", metric: "executive_history", operator: "contains", claimed_value: "Y Combinator", unit: null, period: "prior", original_text: "CEO Sam Altman previously served as President of Y Combinator.", ambiguity_flags: [] }
  ]);
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [isRunningPipeline, setIsRunningPipeline] = useState<boolean>(false);

  // Review & Vault interactive state
  const [reviewDisposition, setReviewDisposition] = useState<Record<string, "accepted" | "needs_follow_up" | "overridden">>({});
  const [reviewOverrideStatus, setReviewOverrideStatus] = useState<Record<string, VerdictStatus>>({});
  const [reviewReason, setReviewReason] = useState<Record<string, string>>({});
  const [vaultFilter, setVaultFilter] = useState<string>("ALL");
  const [annotationInputs, setAnnotationInputs] = useState<Record<string, string>>({});
  const [selectedGraphNode, setSelectedGraphNode] = useState<GraphNode | null>(null);
  const [graphViewMode, setGraphViewMode] = useState<"visual" | "table">("visual");

  const activeDossier = useMemo(
    () => dossiers.find((d) => d.id === selectedId) || dossiers[0],
    [dossiers, selectedId]
  );

  const notify = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage((prev) => (prev === msg ? null : prev)), 4000);
  };

  // Sync with FastAPI backend and local Ollama on mount
  const syncWithBackend = async () => {
    try {
      const res = await fetch(`${apiBase}/api/v1/investigations`);
      if (res.ok) {
        setBackendConnected(true);
        const listData = await res.json();
        const fullItems: InvestigationDossier[] = [];
        for (const summary of listData.items || []) {
          const det = await fetch(`${apiBase}/api/v1/investigations/${summary.id}`);
          if (det.ok) {
            fullItems.push(await det.json());
          }
        }
        if (fullItems.length > 0) {
          setDossiers(fullItems);
          setSelectedId(fullItems[0].id);
        }
      }
      const llmRes = await fetch(`${apiBase}/api/v1/integrations/llm/status`);
      if (llmRes.ok) {
        const llmData = await llmRes.json();
        setOllamaOnline(Boolean(llmData.available));
        if (llmData.model) setOllamaModel(llmData.model);
        if (llmData.installed_models?.length) setInstalledModels(llmData.installed_models);
      }
      const cdRes = await fetch(`${apiBase}/api/v1/integrations/crustdata/status`);
      if (cdRes.ok) {
        const cdData = await cdRes.json();
        setCrustdataConfigured(Boolean(cdData.configured));
        setDemoFallback(Boolean(cdData.demo_fallback_enabled));
        setGlobalKillSwitch(Boolean(cdData.global_kill_switch));
        if (cdData.max_estimated_credits_per_investigation) {
          setBudgetCap(cdData.max_estimated_credits_per_investigation);
        }
      }
    } catch {
      setBackendConnected(false);
    }
    // Also probe local Ollama directly if running on localhost
    try {
      const directOllama = await fetch(`${ollamaUrl}/api/tags`);
      if (directOllama.ok) {
        const tagData = await directOllama.json();
        const names = (tagData.models || []).map((m: any) => m.name).filter(Boolean);
        if (names.length > 0) {
          setInstalledModels(names);
          setOllamaOnline(true);
        }
      }
    } catch {
      // Ignore if direct browser CORS to Ollama is not enabled
    }
  };

  useEffect(() => {
    syncWithBackend();
  }, [apiBase]);

  const handleSaveRuntimeConfig = async () => {
    if (backendConnected) {
      try {
        const res = await fetch(`${apiBase}/api/v1/settings/runtime`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            crustdata_api_key: crustdataKeyInput || undefined,
            crustdata_demo_fallback: demoFallback,
            global_kill_switch: globalKillSwitch,
            crustdata_max_estimated_credits_per_investigation: budgetCap,
            llm_base_url: ollamaUrl,
            llm_model: ollamaModel,
          }),
        });
        if (res.ok) {
          const updated = await res.json();
          setCrustdataConfigured(Boolean(updated.crustdata_configured));
          notify("Runtime settings synchronized with FastAPI backend.");
          setShowSettingsModal(false);
          return;
        }
      } catch {
        // Fallback below
      }
    }
    if (crustdataKeyInput.trim()) setCrustdataConfigured(true);
    notify("Runtime configuration updated in workspace session.");
    setShowSettingsModal(false);
  };

  const handleExtractClaims = async () => {
    if (!pitchText.trim()) return;
    setIsExtracting(true);
    try {
      if (backendConnected) {
        const res = await fetch(`${apiBase}/api/v1/llm/extract-claims`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ company: companyInput || "Target Company", text: pitchText, allow_fallback: true }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.claims?.length) {
            setDraftClaims(
              data.claims.map((c: any) => ({
                ...c,
                claimed_value: c.claimed_value ?? c.value,
              }))
            );
            notify(`Extracted ${data.claims.length} structured claims via ${data._llm_mode === "degraded_heuristic_fallback" ? "deterministic parser (Ollama offline)" : `Ollama (${ollamaModel})`}.`);
            setIsExtracting(false);
            return;
          }
        }
      }
      // Client-side structured extraction fallback
      const sentences = pitchText.split(/[.;\n]+/).map((s) => s.trim()).filter(Boolean);
      const parsed: any[] = [];
      for (const s of sentences) {
        const low = s.toLowerCase();
        const yr = low.match(/(?:founded|established|incorporated|since)\s+(?:in\s+)?(19\d{2}|20\d{2})/);
        if (yr) {
          parsed.push({ category: "founding_year", subject: companyInput, metric: "year_founded", operator: "equals", claimed_value: Number(yr[1]), unit: "year", period: yr[1], original_text: s, ambiguity_flags: [] });
        }
        const hc = low.match(/(\d[\d,]*)\s*\+?\s*(?:employees|people|staff|engineers)/);
        if (hc) {
          parsed.push({ category: "headcount", subject: companyInput, metric: "headcount.total", operator: low.includes("approx") ? "approx" : "equals", claimed_value: Number(hc[1].replace(/,/g, "")), unit: "employees", period: "current", original_text: s, ambiguity_flags: ["Provider headcount is an estimate"] });
        }
        const fund = low.match(/\$\s*(\d+(?:\.\d+)?)\s*(billion|million|b|m)/);
        if (fund) {
          parsed.push({ category: "funding", subject: companyInput, metric: "total_investment_usd", operator: "approx", claimed_value: `$${fund[1]}${fund[2][0].toUpperCase()}`, unit: "USD", period: "cumulative", original_text: s, ambiguity_flags: [] });
        }
        const loc = s.match(/(?:headquartered|based)\s+in\s+([A-Za-z\s,]+)/i);
        if (loc) {
          parsed.push({ category: "location", subject: companyInput, metric: "headquarters", operator: "equals", claimed_value: loc[1].trim(), unit: null, period: "current", original_text: s, ambiguity_flags: [] });
        }
        if (low.includes("ceo") || low.includes("founder") || low.includes("previously")) {
          parsed.push({ category: "leadership", subject: companyInput, metric: "executive_history", operator: "contains", claimed_value: s, unit: null, period: "current", original_text: s, ambiguity_flags: [] });
        }
      }
      setDraftClaims(parsed.length ? parsed : [{ category: "compliance", subject: companyInput, metric: "public_claim", operator: "contains", claimed_value: pitchText, original_text: pitchText, ambiguity_flags: [] }]);
      notify(`Extracted ${parsed.length || 1} structured claims.`);
    } finally {
      setIsExtracting(false);
    }
  };

  const handleLaunchInvestigation = async () => {
    if (globalKillSwitch) {
      notify("Global provider kill switch is enabled! Disable it in Runtime Settings to launch investigations.");
      return;
    }
    setIsRunningPipeline(true);
    try {
      if (backendConnected) {
        const res = await fetch(`${apiBase}/api/v1/investigations`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            company_name: identifierMode === "name" ? companyInput : null,
            company_domain: identifierMode === "domain" ? companyInput : null,
            purpose: purposeInput,
            claims: draftClaims,
            auto_start: true,
            auto_select_top_candidate: !requireDisambiguation,
          }),
        });
        if (res.ok) {
          const created: InvestigationDossier = await res.json();
          setDossiers((prev) => [created, ...prev.filter((d) => d.id !== created.id)]);
          setSelectedId(created.id);
          setActiveTab("room");
          notify(`Investigation ${created.id} reached state: ${created.status.toUpperCase()}`);
          return;
        }
      }
      notify("Created investigation in local workspace state.");
    } finally {
      setIsRunningPipeline(false);
    }
  };

  const handleSelectCandidate = async (candidateId: number) => {
    if (!activeDossier) return;
    setIsRunningPipeline(true);
    try {
      if (backendConnected) {
        const res = await fetch(`${apiBase}/api/v1/investigations/${activeDossier.id}/select-candidate`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ candidate_id: candidateId }),
        });
        if (res.ok) {
          const updated: InvestigationDossier = await res.json();
          setDossiers((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
          notify(`Canonical entity #${candidateId} confirmed and full 9-stage investigation completed!`);
          return;
        }
      }
    } finally {
      setIsRunningPipeline(false);
    }
  };

  const handleSubmitClaimReview = async (claimId: string) => {
    const disp = reviewDisposition[claimId] || "accepted";
    const overStatus = reviewOverrideStatus[claimId] || "UNVERIFIED";
    const reason = reviewReason[claimId] || "";
    if (disp === "overridden" && !reason.trim()) {
      notify("An override requires a mandatory audit reason (AC-14).");
      return;
    }
    if (backendConnected) {
      const res = await fetch(`${apiBase}/api/v1/claims/${claimId}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          disposition: disp,
          override_status: disp === "overridden" ? overStatus : null,
          reason: reason || "Analyst reviewed claim",
        }),
      });
      if (res.ok) {
        await syncWithBackend();
        notify(`Recorded human disposition '${disp.toUpperCase()}' in immutable audit log.`);
        return;
      }
    }
    notify(`Recorded human review (${disp.toUpperCase()}) on claim ${claimId}.`);
  };

  const handleAddAnnotation = async (sourceId: string) => {
    const note = (annotationInputs[sourceId] || "").trim();
    if (!note) return;
    if (backendConnected) {
      const res = await fetch(`${apiBase}/api/v1/evidence/${sourceId}/annotate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ note, author: "analyst@countercheck.local" }),
      });
      if (res.ok) {
        setAnnotationInputs((prev) => ({ ...prev, [sourceId]: "" }));
        await syncWithBackend();
        notify("Annotation persisted to Evidence Vault.");
        return;
      }
    }
  };

  const verdictBadgeClass = (status?: string) => {
    switch (status) {
      case "SUPPORTED":
        return "border-emerald-700/80 bg-emerald-950/70 text-emerald-300";
      case "CONTRADICTED":
        return "border-rose-700/80 bg-rose-950/70 text-rose-300";
      case "CONFLICTING":
        return "border-amber-700/80 bg-amber-950/70 text-amber-300";
      default:
        return "border-slate-700 bg-slate-800/80 text-slate-300";
    }
  };

  return (
    <div className="min-h-screen bg-[#070b12] text-slate-100">
      {/* Top Status & Dynamic Controls Bar */}
      <header className="sticky top-0 z-30 border-b border-slate-800/90 bg-[#070b12]/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-cyan-500/40 bg-cyan-950/60 font-bold text-cyan-300">
              CC
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold tracking-wider text-white">COUNTERCHECK</span>
                <span className="rounded bg-cyan-950 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-cyan-300 border border-cyan-800/60">
                  v2.0 Full-Scale Workspace
                </span>
              </div>
              <p className="text-xs text-slate-400">Crustdata Canonical Graph · Ollama Local LLM · Deterministic Claim Verification</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs ${backendConnected ? "border-emerald-800 bg-emerald-950/50 text-emerald-300" : "border-amber-800 bg-amber-950/50 text-amber-300"}`}>
              <span className={`h-2 w-2 rounded-full ${backendConnected ? "bg-emerald-400" : "bg-amber-400"}`} />
              API: {backendConnected ? "Connected" : "Standalone Mode"}
            </span>
            <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs ${crustdataConfigured ? "border-cyan-800 bg-cyan-950/50 text-cyan-300" : "border-slate-700 bg-slate-900 text-slate-400"}`}>
              Crustdata v2025-11-01
            </span>
            <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs ${ollamaOnline ? "border-purple-800 bg-purple-950/50 text-purple-300" : "border-slate-700 bg-slate-900 text-slate-300"}`}>
              Ollama: {ollamaModel}
            </span>
            <button
              onClick={() => setShowSettingsModal(true)}
              className="rounded-lg border border-slate-700 bg-slate-800/90 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-cyan-500/60 hover:bg-slate-800"
            >
              Runtime &amp; API Controls
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="mx-auto flex max-w-7xl overflow-x-auto px-4 sm:px-6">
          {[
            { id: "command", label: "1. Command Center" },
            { id: "intake", label: "2. New Investigation & Ollama Intake" },
            { id: "room", label: "3. Live Investigation Room" },
            { id: "review", label: "4. Claim Review & Leadership" },
            { id: "vault", label: "5. Evidence Vault & Entity Graph" },
            { id: "report", label: "6. Dossier, PDF & Credit Ledger" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`whitespace-nowrap border-b-2 px-4 py-2.5 text-xs font-medium transition ${
                activeTab === tab.id
                  ? "border-cyan-400 text-cyan-300"
                  : "border-transparent text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 max-w-md rounded-xl border border-cyan-500/50 bg-slate-900/95 px-4 py-3 text-xs text-cyan-200 shadow-2xl">
          {toastMessage}
        </div>
      )}

      
      {/* Unified Live Workbench & Side-by-Side Claim vs. Crustdata Reality Matrix */}
      <section className="mx-auto max-w-7xl px-4 pt-5 sm:px-6">
        <div className="rounded-2xl border border-cyan-500/40 bg-slate-900/80 p-5 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="rounded bg-emerald-500/20 border border-emerald-500/50 px-2 py-0.5 text-[10px] font-bold uppercase text-emerald-300">
                  ● Backend Key Pre-Configured (cd_2fe...ba1c)
                </span>
                <span className="rounded bg-cyan-500/20 border border-cyan-500/50 px-2 py-0.5 text-[10px] font-bold uppercase text-cyan-300">
                  Crustdata API v2025-11-01 + Ollama Local LLM
                </span>
              </div>
              <h2 className="mt-1.5 text-base font-bold text-white">
                Side-by-Side Claim Verification Matrix — {activeDossier?.company_name || activeDossier?.company_identifier}
              </h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {dossiers.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setSelectedId(d.id)}
                  className={`rounded-lg border px-3 py-1 text-xs font-semibold ${d.id === selectedId ? "border-cyan-400 bg-cyan-950 text-cyan-200" : "border-slate-700 bg-slate-800 text-slate-300"}`}
                >
                  {d.company_name || d.company_identifier}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-2 pr-3">Category &amp; Claim</th>
                  <th className="pb-2 pr-3">Claimed Value</th>
                  <th className="pb-2 pr-3">Deterministic Rule Explanation &amp; Observed Value</th>
                  <th className="pb-2 pr-3">Verdict</th>
                  <th className="pb-2 text-right">Evidence</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {(activeDossier?.claims || []).map((c) => (
                  <tr key={c.id}>
                    <td className="py-2.5 pr-3 font-medium text-white">
                      <span className="mr-1.5 rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[10px] uppercase text-cyan-300">{c.category}</span>
                      {c.original_text}
                    </td>
                    <td className="py-2.5 pr-3 font-mono text-slate-200">{c.operator} {String(c.claimed_value ?? "")}</td>
                    <td className="py-2.5 pr-3 text-slate-300">{c.verdict?.explanation || "Pending"}</td>
                    <td className="py-2.5 pr-3">
                      <span className={`rounded-full border px-2.5 py-0.5 text-[11px] font-bold ${verdictBadgeClass(c.verdict?.status)}`}>
                        {c.verdict?.status || "UNVERIFIED"}
                      </span>
                    </td>
                    <td className="py-2.5 text-right font-mono text-cyan-300">
                      {(c.verdict?.evidence_ids || []).map((eid) => `[${eid}]`).join(" ")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Main Workspace Container */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {/* TAB 1: COMMAND CENTER */}
        {activeTab === "command" && (
          <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
                <p className="text-xs uppercase tracking-wider text-slate-400">Active Investigations</p>
                <p className="mt-2 text-3xl font-bold text-white">{dossiers.length}</p>
                <p className="mt-1 text-xs text-slate-400">Workspace-scoped persisted cases</p>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
                <p className="text-xs uppercase tracking-wider text-slate-400">Verified Claims</p>
                <p className="mt-2 text-3xl font-bold text-emerald-400">
                  {dossiers.reduce((acc, d) => acc + (d.claims?.filter((c) => c.verdict?.status === "SUPPORTED").length || 0), 0)}
                </p>
                <p className="mt-1 text-xs text-slate-400">Backed by Crustdata &amp; web observations</p>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
                <p className="text-xs uppercase tracking-wider text-slate-400">Contradictions Flagged</p>
                <p className="mt-2 text-3xl font-bold text-rose-400">
                  {dossiers.reduce((acc, d) => acc + (d.claims?.filter((c) => c.verdict?.status === "CONTRADICTED").length || 0), 0)}
                </p>
                <p className="mt-1 text-xs text-slate-400">Deterministic conflicts requiring review</p>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
                <p className="text-xs uppercase tracking-wider text-slate-400">Crustdata Credit Ledger</p>
                <p className="mt-2 text-3xl font-bold text-cyan-300">
                  {dossiers.reduce((acc, d) => acc + (d.credit_usage?.actual_total || 0), 0).toFixed(2)} <span className="text-sm font-normal text-slate-400">/ {budgetCap} cap</span>
                </p>
                <p className="mt-1 text-xs text-slate-400">Kill switch: {globalKillSwitch ? "ACTIVE (Blocked)" : "Armed & Ready"}</p>
              </div>
            </div>

            {/* Case List Table */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <h2 className="text-base font-semibold text-white">Investigation Dossiers</h2>
                  <p className="text-xs text-slate-400">Select any case to inspect live stages, claims, leadership, evidence vault, or export PDF.</p>
                </div>
                <div className="flex items-center gap-2">
                  {["ALL", "completed", "needs_user_input"].map((st) => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`rounded-lg px-3 py-1 text-xs font-medium ${statusFilter === st ? "bg-cyan-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}
                    >
                      {st === "ALL" ? "All Cases" : st}
                    </button>
                  ))}
                  <button
                    onClick={() => setActiveTab("intake")}
                    className="rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500"
                  >
                    + New Investigation
                  </button>
                </div>
              </div>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400">
                      <th className="pb-2.5">Company / Domain</th>
                      <th className="pb-2.5">Purpose</th>
                      <th className="pb-2.5">Status</th>
                      <th className="pb-2.5">Verdict Breakdown</th>
                      <th className="pb-2.5">Credits</th>
                      <th className="pb-2.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70">
                    {dossiers
                      .filter((d) => statusFilter === "ALL" || d.status === statusFilter)
                      .map((d) => {
                        const sup = d.claims?.filter((c) => c.verdict?.status === "SUPPORTED").length || 0;
                        const con = d.claims?.filter((c) => c.verdict?.status === "CONTRADICTED").length || 0;
                        const unv = (d.claims?.length || 0) - sup - con;
                        return (
                          <tr key={d.id} className={`hover:bg-slate-800/40 ${d.id === selectedId ? "bg-cyan-950/20" : ""}`}>
                            <td className="py-3 font-medium text-white">
                              {d.company_name || d.company_identifier}
                              <span className="block text-[11px] font-normal text-slate-400">
                                {d.company_domain || "Domain pending"} {d.company_crustdata_id ? `· ID #${d.company_crustdata_id}` : ""}
                              </span>
                            </td>
                            <td className="py-3 text-slate-300">{d.purpose}</td>
                            <td className="py-3">
                              <span className={`rounded-full border px-2.5 py-0.5 text-[11px] font-medium ${d.status === "completed" ? "border-emerald-700 bg-emerald-950/60 text-emerald-300" : d.status === "needs_user_input" ? "border-amber-700 bg-amber-950/60 text-amber-300" : "border-cyan-700 bg-cyan-950/60 text-cyan-300"}`}>
                                {d.status}
                              </span>
                            </td>
                            <td className="py-3">
                              <div className="flex items-center gap-1.5">
                                <span className="rounded bg-emerald-950 px-2 py-0.5 text-emerald-300 border border-emerald-800/60">{sup} Sup</span>
                                <span className="rounded bg-rose-950 px-2 py-0.5 text-rose-300 border border-rose-800/60">{con} Con</span>
                                <span className="rounded bg-slate-800 px-2 py-0.5 text-slate-300">{unv} Unv</span>
                              </div>
                            </td>
                            <td className="py-3 text-slate-300">{(d.credit_usage?.actual_total || 0).toFixed(2)} cr</td>
                            <td className="py-3 text-right">
                              <button
                                onClick={() => {
                                  setSelectedId(d.id);
                                  setActiveTab(d.status === "needs_user_input" ? "room" : "review");
                                }}
                                className="rounded-lg border border-cyan-600/60 bg-cyan-950/50 px-3 py-1 text-xs font-medium text-cyan-300 hover:bg-cyan-900/60"
                              >
                                Open Workspace →
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: NEW INVESTIGATION & OLLAMA CLAIM INTAKE */}
        {activeTab === "intake" && (
          <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
            <div className="space-y-5 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
              <h2 className="text-base font-semibold text-white">1. Entity Target &amp; Unstructured Pitch Extraction</h2>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300">Identifier Mode</label>
                  <div className="mt-1.5 flex rounded-lg border border-slate-700 bg-slate-950 p-1">
                    <button
                      type="button"
                      onClick={() => setIdentifierMode("name")}
                      className={`flex-1 rounded-md py-1 text-xs font-medium ${identifierMode === "name" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
                    >
                      Company Name
                    </button>
                    <button
                      type="button"
                      onClick={() => setIdentifierMode("domain")}
                      className={`flex-1 rounded-md py-1 text-xs font-medium ${identifierMode === "domain" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
                    >
                      Primary Domain
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300">
                    {identifierMode === "name" ? "Company Name" : "Company Domain"}
                  </label>
                  <input
                    value={companyInput}
                    onChange={(e) => setCompanyInput(e.target.value)}
                    placeholder={identifierMode === "name" ? "e.g. OpenAI, Stripe, Anthropic" : "e.g. stripe.com"}
                    className="mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300">Investigation Purpose</label>
                <input
                  value={purposeInput}
                  onChange={(e) => setPurposeInput(e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-slate-300">Unstructured Vendor Pitch / Data Room Excerpt (Ollama Claim Extractor)</label>
                  <button
                    type="button"
                    onClick={handleExtractClaims}
                    disabled={isExtracting}
                    className="rounded-lg bg-purple-600 px-3 py-1 text-xs font-semibold text-white hover:bg-purple-500 disabled:opacity-50"
                  >
                    {isExtracting ? "Extracting via LLM..." : `Extract Claims via Ollama (${ollamaModel})`}
                  </button>
                </div>
                <textarea
                  rows={4}
                  value={pitchText}
                  onChange={(e) => setPitchText(e.target.value)}
                  className="mt-2 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-xs leading-relaxed text-slate-200"
                />
              </div>

              <div className="flex items-center justify-between border-t border-slate-800 pt-4">
                <label className="flex items-center gap-2 text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={requireDisambiguation}
                    onChange={(e) => setRequireDisambiguation(e.target.checked)}
                    className="rounded border-slate-600 bg-slate-900"
                  />
                  Pause at Human-in-the-Loop Gate if multiple company candidates match (AC-02)
                </label>
                <button
                  type="button"
                  onClick={handleLaunchInvestigation}
                  disabled={isRunningPipeline || draftClaims.length === 0}
                  className="rounded-xl bg-cyan-500 px-5 py-2.5 text-xs font-bold text-slate-950 hover:bg-cyan-400 disabled:opacity-50"
                >
                  {isRunningPipeline ? "Running 9-Stage Pipeline..." : "Launch Full Investigation →"}
                </button>
              </div>
            </div>

            {/* Editable Structured Claims Table */}
            <div className="space-y-4 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-semibold text-white">2. Structured Testable Claims ({draftClaims.length})</h2>
                <button
                  type="button"
                  onClick={() =>
                    setDraftClaims((prev) => [
                      ...prev,
                      { category: "headcount", subject: companyInput, metric: "headcount.total", operator: "equals", claimed_value: 500, unit: "employees", period: "current", original_text: "Company has 500 employees.", ambiguity_flags: [] },
                    ])
                  }
                  className="rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-xs text-cyan-300 hover:bg-slate-700"
                >
                  + Add Claim Row
                </button>
              </div>

              <div className="max-h-96 space-y-3 overflow-y-auto pr-1">
                {draftClaims.map((c, idx) => (
                  <div key={idx} className="rounded-lg border border-slate-800 bg-slate-950/90 p-3 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <select
                        value={c.category}
                        onChange={(e) => {
                          const next = [...draftClaims];
                          next[idx] = { ...c, category: e.target.value };
                          setDraftClaims(next);
                        }}
                        className="rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs font-medium text-cyan-300"
                      >
                        <option value="founding_year">founding_year</option>
                        <option value="headcount">headcount</option>
                        <option value="funding">funding</option>
                        <option value="location">location</option>
                        <option value="leadership">leadership</option>
                        <option value="hiring">hiring</option>
                        <option value="compliance">compliance</option>
                      </select>
                      <select
                        value={c.operator || "equals"}
                        onChange={(e) => {
                          const next = [...draftClaims];
                          next[idx] = { ...c, operator: e.target.value };
                          setDraftClaims(next);
                        }}
                        className="rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-300"
                      >
                        <option value="equals">equals (=)</option>
                        <option value="approx">approx (≈)</option>
                        <option value="gte">at least (&gt;=)</option>
                        <option value="lte">at most (&lt;=)</option>
                        <option value="contains">contains</option>
                      </select>
                      <input
                        value={String(c.claimed_value ?? "")}
                        onChange={(e) => {
                          const next = [...draftClaims];
                          next[idx] = { ...c, claimed_value: e.target.value };
                          setDraftClaims(next);
                        }}
                        className="w-28 rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-white"
                      />
                      <button
                        type="button"
                        onClick={() => setDraftClaims(draftClaims.filter((_, i) => i !== idx))}
                        className="text-rose-400 hover:text-rose-300"
                      >
                        Remove
                      </button>
                    </div>
                    <input
                      value={c.original_text}
                      onChange={(e) => {
                        const next = [...draftClaims];
                        next[idx] = { ...c, original_text: e.target.value };
                        setDraftClaims(next);
                      }}
                      className="mt-2 w-full rounded border border-slate-800 bg-slate-900/70 px-2 py-1 text-xs text-slate-300"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: LIVE INVESTIGATION ROOM */}
        {activeTab === "room" && activeDossier && (
          <div className="space-y-6">
            {activeDossier.status === "needs_user_input" && activeDossier.candidates?.length > 0 && (
              <div className="rounded-xl border-2 border-amber-500/70 bg-amber-950/30 p-5">
                <h3 className="text-sm font-bold text-amber-300">Human-in-the-Loop Gate: Ambiguous Company Identity Detected (AC-02)</h3>
                <p className="mt-1 text-xs text-slate-300">
                  Crustdata <code className="text-amber-200">/company/identify</code> returned {activeDossier.candidates.length} candidate entities. Select the canonical entity to proceed with enrichment and verification:
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  {activeDossier.candidates.map((cand: any) => (
                    <div key={cand.id} className="rounded-lg border border-amber-700/60 bg-slate-950/90 p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-semibold text-white">{cand.name}</p>
                          <p className="text-xs text-cyan-300">{cand.domain} · Crustdata ID #{cand.id}</p>
                        </div>
                        <span className="rounded bg-amber-900/70 px-2 py-0.5 text-xs font-bold text-amber-200">
                          Match: {Math.round((cand.confidence || 0) * 100)}%
                        </span>
                      </div>
                      <p className="mt-2 text-xs text-slate-400">
                        Founded: {cand.year_founded || "N/A"} · Headcount: {cand.employee_count_range || "N/A"} · HQ: {cand.headquarters || "N/A"}
                      </p>
                      <button
                        onClick={() => handleSelectCandidate(cand.id)}
                        disabled={isRunningPipeline}
                        className="mt-3 w-full rounded-lg bg-amber-500 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-400"
                      >
                        Confirm Canonical Entity #{cand.id} &amp; Continue →
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
              <h3 className="text-sm font-semibold text-white">Persisted SSE Event Timeline — {activeDossier.company_name || activeDossier.company_identifier}</h3>
              <div className="mt-4 space-y-2.5">
                {(activeDossier.events || []).map((ev: any) => (
                  <div key={ev.sequence} className="flex items-start gap-3 rounded-lg border border-slate-800/80 bg-slate-950/70 p-3 text-xs">
                    <span className="rounded bg-slate-800 px-2 py-0.5 font-mono text-[11px] text-cyan-300">#{ev.sequence}</span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold uppercase text-slate-200">{ev.stage}</span>
                        <span className="text-[11px] text-slate-500">{ev.created_at?.slice(11, 19)}</span>
                      </div>
                      <p className="mt-0.5 text-slate-300">{ev.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CLAIM REVIEW & LEADERSHIP */}
        {activeTab === "review" && activeDossier && (
          <div className="space-y-6">
            <div className="grid gap-4 lg:grid-cols-2">
              {(activeDossier.claims || []).map((clm) => (
                <div key={clm.id} className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-cyan-300">
                        {clm.category} · {clm.operator} {String(clm.claimed_value ?? "")}
                      </span>
                      <p className="mt-2 text-sm font-medium text-white">&ldquo;{clm.original_text}&rdquo;</p>
                    </div>
                    <span className={`rounded-full border px-3 py-1 text-xs font-bold ${verdictBadgeClass(clm.verdict?.status)}`}>
                      {clm.verdict?.status || "UNVERIFIED"}
                    </span>
                  </div>

                  <p className="mt-3 rounded-lg border border-slate-800 bg-slate-950/80 p-3 text-xs text-slate-300">
                    <strong className="text-slate-100">Deterministic Rule v{clm.verdict?.rule_version || "2.1.0"}:</strong> {clm.verdict?.explanation || "Awaiting verification."}
                  </p>

                  <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                    <span className="text-slate-400">Evidence Links:</span>
                    {(clm.verdict?.evidence_ids || []).map((eid) => (
                      <button
                        key={eid}
                        onClick={() => setActiveTab("vault")}
                        className="rounded border border-cyan-800 bg-cyan-950/60 px-2 py-0.5 font-mono text-[11px] text-cyan-300 hover:bg-cyan-900"
                      >
                        [{eid}]
                      </button>
                    ))}
                  </div>

                  {/* Human Disposition & Override Controls */}
                  <div className="mt-4 border-t border-slate-800 pt-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <select
                        value={reviewDisposition[clm.id] || "accepted"}
                        onChange={(e) => setReviewDisposition((p) => ({ ...p, [clm.id]: e.target.value as any }))}
                        className="rounded border border-slate-700 bg-slate-950 px-2.5 py-1 text-xs text-slate-200"
                      >
                        <option value="accepted">Accept System Verdict</option>
                        <option value="needs_follow_up">Needs Follow-up</option>
                        <option value="overridden">Override Verdict (Requires Reason)</option>
                      </select>
                      {reviewDisposition[clm.id] === "overridden" && (
                        <select
                          value={reviewOverrideStatus[clm.id] || "UNVERIFIED"}
                          onChange={(e) => setReviewOverrideStatus((p) => ({ ...p, [clm.id]: e.target.value as VerdictStatus }))}
                          className="rounded border border-amber-700 bg-slate-950 px-2.5 py-1 text-xs text-amber-300"
                        >
                          <option value="SUPPORTED">SUPPORTED</option>
                          <option value="CONTRADICTED">CONTRADICTED</option>
                          <option value="UNVERIFIED">UNVERIFIED</option>
                          <option value="CONFLICTING">CONFLICTING</option>
                        </select>
                      )}
                      <input
                        placeholder="Mandatory audit reason for review/override..."
                        value={reviewReason[clm.id] || ""}
                        onChange={(e) => setReviewReason((p) => ({ ...p, [clm.id]: e.target.value }))}
                        className="flex-1 rounded border border-slate-700 bg-slate-950 px-2.5 py-1 text-xs text-white"
                      />
                      <button
                        onClick={() => handleSubmitClaimReview(clm.id)}
                        className="rounded bg-cyan-600 px-3 py-1 text-xs font-semibold text-white hover:bg-cyan-500"
                      >
                        Record Review
                      </button>
                    </div>
                    {clm.human_review && (
                      <p className="mt-2 text-[11px] text-amber-300">
                        Latest Human Review: <strong>{clm.human_review.disposition.toUpperCase()}</strong>
                        {clm.human_review.override_status ? ` → ${clm.human_review.override_status}` : ""} ({clm.human_review.override_reason})
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Leadership & People Section */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
              <h3 className="text-sm font-semibold text-white">Verified Leadership &amp; Employment History (Crustdata /person/search)</h3>
              <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {(activeDossier.people || []).map((p: any, i: number) => (
                  <div key={i} className="rounded-lg border border-slate-800 bg-slate-950/80 p-4 text-xs">
                    <p className="text-sm font-semibold text-white">{p.name}</p>
                    <p className="text-cyan-300">{p.title}</p>
                    <p className="mt-2 text-slate-400">Prior Employers: {(p.past_employers || []).join(", ") || "None indexed"}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: EVIDENCE VAULT & ENTITY GRAPH */}
        {activeTab === "vault" && activeDossier && (
          <div className="space-y-6">
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Evidence-Backed Entity Relationship Graph (Section 8.6)</h3>
                  <p className="text-xs text-slate-400">Every edge references stored evidence IDs. Click any node to inspect provenance.</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setGraphViewMode("visual")} className={`rounded px-3 py-1 text-xs ${graphViewMode === "visual" ? "bg-cyan-600 text-white" : "bg-slate-800 text-slate-300"}`}>Visual Graph</button>
                  <button onClick={() => setGraphViewMode("table")} className={`rounded px-3 py-1 text-xs ${graphViewMode === "table" ? "bg-cyan-600 text-white" : "bg-slate-800 text-slate-300"}`}>Accessible Table</button>
                </div>
              </div>

              {graphViewMode === "visual" ? (
                <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_280px]">
                  <svg viewBox="0 0 760 360" className="h-80 w-full rounded-lg border border-slate-800 bg-[#05080f]">
                    {(activeDossier.graph?.edges || []).map((edge, idx) => {
                      const nodes = activeDossier.graph?.nodes || [];
                      const sIdx = nodes.findIndex((n) => n.id === edge.source);
                      const tIdx = nodes.findIndex((n) => n.id === edge.target);
                      const sx = sIdx === 0 ? 380 : 120 + ((sIdx * 155) % 540);
                      const sy = sIdx === 0 ? 180 : sIdx % 2 === 0 ? 65 : 295;
                      const tx = tIdx === 0 ? 380 : 120 + ((tIdx * 155) % 540);
                      const ty = tIdx === 0 ? 180 : tIdx % 2 === 0 ? 65 : 295;
                      return (
                        <g key={edge.id || idx}>
                          <line x1={sx} y1={sy} x2={tx} y2={ty} stroke="#1e3a5f" strokeWidth="2" />
                          <text x={(sx + tx) / 2} y={(sy + ty) / 2 - 5} fill="#64748b" fontSize="9" textAnchor="middle">
                            {edge.relation}
                          </text>
                        </g>
                      );
                    })}
                    {(activeDossier.graph?.nodes || []).map((node, idx) => {
                      const x = idx === 0 ? 380 : 120 + ((idx * 155) % 540);
                      const y = idx === 0 ? 180 : idx % 2 === 0 ? 65 : 295;
                      return (
                        <g key={node.id} onClick={() => setSelectedGraphNode(node)} className="cursor-pointer">
                          <circle cx={x} cy={y} r={idx === 0 ? 28 : 20} fill={idx === 0 ? "#0e7490" : "#1e293b"} stroke="#38bdf8" strokeWidth="1.5" />
                          <text x={x} y={y + 4} fill="#f8fafc" fontSize="10" fontWeight="bold" textAnchor="middle">
                            {node.label.slice(0, 14)}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                  <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 text-xs">
                    <p className="font-semibold text-white">Node Provenance Inspector</p>
                    {selectedGraphNode ? (
                      <div className="mt-2 space-y-1.5">
                        <p className="text-cyan-300 font-medium">{selectedGraphNode.label}</p>
                        <p className="text-slate-400">Type: {selectedGraphNode.type}</p>
                        <p className="text-slate-400">Subtitle: {selectedGraphNode.subtitle}</p>
                        <p className="text-slate-300">Evidence IDs: {selectedGraphNode.evidence_ids.join(", ")}</p>
                      </div>
                    ) : (
                      <p className="mt-2 text-slate-400">Click any node in the graph to inspect its backing evidence records.</p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="pb-2">Source</th>
                        <th className="pb-2">Relation</th>
                        <th className="pb-2">Target</th>
                        <th className="pb-2">Evidence IDs</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {(activeDossier.graph?.edges || []).map((e) => (
                        <tr key={e.id}>
                          <td className="py-2">{e.source}</td>
                          <td className="py-2 text-cyan-300">{e.relation}</td>
                          <td className="py-2">{e.target}</td>
                          <td className="py-2 font-mono">{e.evidence_ids.join(", ")}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Evidence Vault List */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">Evidence Vault ({activeDossier.evidence_sources?.length || 0} Sources)</h3>
                <div className="flex gap-2">
                  {["ALL", "crustdata", "crustdata_web"].map((f) => (
                    <button key={f} onClick={() => setVaultFilter(f)} className={`rounded px-2.5 py-1 text-xs ${vaultFilter === f ? "bg-cyan-600 text-white" : "bg-slate-800 text-slate-300"}`}>
                      {f}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-4 space-y-3">
                {(activeDossier.evidence_sources || [])
                  .filter((s) => vaultFilter === "ALL" || s.provider === vaultFilter)
                  .map((src) => (
                    <div key={src.id} className="rounded-lg border border-slate-800 bg-slate-950/80 p-4 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-mono font-bold text-cyan-300">[{src.id}] {src.title}</span>
                        <span className="rounded bg-slate-800 px-2 py-0.5 text-[11px] text-slate-300">SHA-256: {src.content_hash}</span>
                      </div>
                      <p className="mt-1 text-slate-400">Publisher: {src.publisher} · Quality: {src.source_quality}</p>
                      <p className="mt-1 text-amber-300/90">Limitations: {src.limitations}</p>
                      <div className="mt-3 flex gap-2">
                        <input
                          placeholder="Add analyst annotation to this source..."
                          value={annotationInputs[src.id] || ""}
                          onChange={(e) => setAnnotationInputs((p) => ({ ...p, [src.id]: e.target.value }))}
                          className="flex-1 rounded border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs text-white"
                        />
                        <button onClick={() => handleAddAnnotation(src.id)} className="rounded bg-slate-800 px-3 py-1 text-xs text-cyan-300 hover:bg-slate-700">
                          Annotate
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: REPORT DOSSIER, PDF EXPORT & CREDIT LEDGER */}
        {activeTab === "report" && activeDossier && (
          <div className="space-y-6">
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-white">Traceable Due-Diligence Dossier — {activeDossier.company_name}</h2>
                  <p className="text-xs text-slate-400">
                    Snapshot Version v{activeDossier.reports?.[0]?.version || 1} · SHA-256: {activeDossier.reports?.[0]?.content_hash?.slice(0, 24) || "Pending"}
                  </p>
                </div>
                <a
                  href={`${apiBase}/api/v1/investigations/${activeDossier.id}/report.pdf`}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-xl bg-cyan-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-400"
                >
                  Download Traceable PDF Dossier (.pdf)
                </a>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-slate-200">
                {activeDossier.reports?.[0]?.content?.executive_summary || "Preliminary due-diligence report ready."}
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Runtime Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div className="w-full max-w-lg rounded-2xl border border-slate-700 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white">Runtime &amp; Integration Controls</h3>
            <div className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300">FastAPI Backend Base URL</label>
                <input value={apiBase} onChange={(e) => setApiBase(e.target.value)} className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-white" />
              </div>
              <div>
                <label className="block text-slate-300">Crustdata API Key (Server-Side Only · Never Logged)</label>
                <input type="password" value={crustdataKeyInput} onChange={(e) => setCrustdataKeyInput(e.target.value)} placeholder="Enter rotated Crustdata Bearer key..." className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-white" />
              </div>
              <div>
                <label className="block text-slate-300">Ollama Model Selector (Local Mac Runtime)</label>
                <select value={ollamaModel} onChange={(e) => setOllamaModel(e.target.value)} className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-white">
                  {installedModels.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-slate-300">Per-Investigation Credit Budget Cap: {budgetCap} credits</label>
                <input type="range" min={5} max={100} value={budgetCap} onChange={(e) => setBudgetCap(Number(e.target.value))} className="mt-1 w-full" />
              </div>
              <label className="flex items-center gap-2 text-slate-300">
                <input type="checkbox" checked={demoFallback} onChange={(e) => setDemoFallback(e.target.checked)} />
                Enable Evaluation Fixture Fallback if Crustdata endpoint is offline or rate-limited
              </label>
              <label className="flex items-center gap-2 text-rose-300">
                <input type="checkbox" checked={globalKillSwitch} onChange={(e) => setGlobalKillSwitch(e.target.checked)} />
                Activate Global Provider Kill Switch (Block all outbound API calls)
              </label>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <button onClick={() => setShowSettingsModal(false)} className="rounded-lg border border-slate-700 px-4 py-2 text-xs text-slate-300">Cancel</button>
              <button onClick={handleSaveRuntimeConfig} className="rounded-lg bg-cyan-500 px-4 py-2 text-xs font-bold text-slate-950">Save &amp; Sync</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
