import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "CounterCheck", description: "Evidence-first business due diligence" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
