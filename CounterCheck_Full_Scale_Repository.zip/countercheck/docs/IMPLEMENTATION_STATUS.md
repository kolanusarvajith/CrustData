# Implementation status — 2026-10-31

This is a live engineering checkpoint, not a declaration that the whole product is complete.

## Crustdata account validation

- API version: `2025-11-01`.
- Remaining balance after a real company-enrichment validation call: `15,220.27` credits.
- Enabled: company identify/enrich/search, person search/enrich, job search, indexed social search, web search live and web enrich live.
- Disabled: live company/person search, batch endpoints, professional-network live social endpoints.
- `identify_company(names=["OpenAI"])` returned multiple company candidates, demonstrating need for candidate selection.
- Enrichment by selected canonical ID succeeded; broad field response was too large for the tool display cap. Production code must prefer narrow `fields` selection.

## Files implemented

- Monorepo layout and README/security setup.
- Docker Compose: PostgreSQL 16, Redis 7 and MinIO with persistent volumes and health checks.
- FastAPI app, typed settings, CORS config and log redaction filter.
- Async Crustdata client: company identify/enrich, people search/enrich, job search, web search and web page fetch.
- Ollama structured-output adapter, model manifest, prompt schemas, model pull script and required-model health route.
- Initial SQLAlchemy schema: investigations, claims, evidence sources, observations, verdicts and persisted events.
- Initial repository for investigations/evidence, development DB initialization and Alembic environment.
- API routes for health, integration status, LLM extraction, company identify/enrich, investigations, evidence/observations, persisted events and SSE event streaming.
- Investigation company resolve/enrich workflow that pauses when identity candidates are ambiguous.
- Deterministic numeric, founding-year, headcount and location verifier primitives.
- Evidence reference validation for model-written report narrative.
- SSRF URL validation primitive.
- Initial frontend dashboard shell.
- Tests for verifier behavior, company claim rules, Crustdata connector contracts and URL safety.

## Remaining work

- Generate and test the initial Alembic migration against a running PostgreSQL service.
- Implement durable Redis-backed background execution, resume/checkpoint logic, cancellation and safe idempotency.
- Complete end-to-end claim planning, data normalization, evidence persistence from Crustdata/web responses and automatic verdict generation.
- Implement robust currency, ranges, date and funding-specific comparisons; current verifier rules are primitives only.
- Complete actual authenticated users/workspaces/role authorization and audit logs (currently the API is not safe for public exposure).
- Implement graph endpoints, claim review endpoints, report snapshot/PDF export, full credit ledger and limits.
- Complete the full Next.js analyst UI and wire it to the APIs, including SSE, evidence vault and Phase 2 modules.
- Implement web page safe fetch policy end to end, source quality classification and citation completeness tests.
- Run tests after dependencies are installed; perform Docker clean-start and real API integration tests with the rotated account key.
- Pull and benchmark the chosen Ollama model on the target Mac; exact model/version is a proposed starting point, not yet benchmarked.
- Add production deployment manifests, TLS, secrets manager, backups, monitoring and model service authentication.

## Security

The prior Crustdata key was exposed in chat; rotate it. No credential is present in source code. Put the replacement in `apps/api/.env`, which is ignored by Git. The scaffold currently lacks production authentication and must not be deployed publicly yet.
