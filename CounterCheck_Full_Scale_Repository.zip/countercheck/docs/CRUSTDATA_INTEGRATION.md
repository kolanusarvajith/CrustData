# Crustdata integration notes

Account validation date: 2026-10-31. API version: `2025-11-01`.

## Confirmed access

Enabled in the connected account: `/company/identify`, `/company/enrich`, `/company/search`, `/person/search`, `/person/enrich`, `/job/search`, `/social_post/search`, `/web/search/live`, `/web/enrich/live`. Not enabled: `/person/professional_network/search/live`, `/company/professional_network/search/live`, batch endpoints and professional-network live social endpoints.

## Verified request patterns

- Company identify: POST `/company/identify`, exactly one identifier array (`names` or `domains`). Free. Name can return many candidates; inspect `company_data.basic_info.primary_domain` and user confirmation.
- Company enrich: POST `/company/enrich`, `crustdata_company_ids: [id]`, explicitly request `fields`, e.g. `basic_info`, `headcount`, `funding`, `locations`, `hiring`, `news`.
- People search: POST `/person/search`, filter `experience.employment_details.current.company_id` with `=` and Crustdata company ID. The response returns people profiles; search filters accept this ID alias.
- Person enrich: POST `/person/enrich`, use `professional_network_profile_urls`; request `experience` when employment history is required.
- Job search: POST `/job/search`, company filter via `company.basic_info.company_id`.
- Web search: POST `/web/search/live` with `query` and optional sources.
- Page fetch: POST `/web/enrich/live` with `urls`, up to 10.

## Observed account base pricing

- Identify: free.
- Company enrich: 2 credits base; technographics and social posts cost extra.
- Company search: 0.03 per company; various premium groups cost extra.
- Person search: 0.03 per profile; experience/education/skills and other field groups cost extra.
- Person enrich: 1 per profile; contact/developer/social/research fields add cost.
- Job search: 0.03 per job.
- Web search: 1 per started block of 10 returned results; empty results are free.
- Web page fetch: 1 per page returned.

These are a snapshot, not immutable configuration. Runtime must use configurable limits and administrators should refresh pricing/access before production.

## Test record

- `identify_company(names=["OpenAI"])` returned multiple candidates; expected behavior is candidate selection, not silent first-hit acceptance.
- Enriched company ID `631466` with selected field groups successfully; one company enrich used 2 credits. Large output exceeded the connector display cap; avoid unnecessarily broad field selections.
