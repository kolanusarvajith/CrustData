# Known limitations at this checkpoint

1. Authentication and workspace authorization are not implemented. Do not expose this API publicly.
2. Initial schema has Alembic environment, but no generated initial migration verified against PostgreSQL yet.
3. The Redis queue and worker are a simple starting point; they still need durable job state, retries, dead-letter handling, cancellation, checkpointing and idempotency.
4. Identity → company enrich is implemented. Person discovery/enrichment and web research connectors exist at client layer but are not yet orchestrated and normalized into the investigation.
5. Company facts currently normalize selected fields. Claim-to-observation matching is basic; the category-specific verifier catalogue needs stronger semantics and test coverage before relying on verdicts.
6. SSE stream is a persisted-event polling loop. Sequence replay exists, but terminal-state handling and worker state transitions require additional tests.
7. Evidence API persists source metadata and observations, but raw object storage writes and secure raw provider response archival are not yet wired.
8. Report snapshot and PDF rendering are initial. There is no full LLM narrative generation flow, evidence appendix, signed export, or PDF regression tests yet.
9. Next.js is a functional landing dashboard shell, not yet the complete analyst workspace and does not yet call the investigation APIs.
10. No clean Docker boot, live provider request from the generated application, model pull, Ollama inference, or production deployment has been executed here. The actual Crustdata account was validated separately through the connected integration.
11. Exact local model tag is a starting candidate in the manifest; validate availability, license, JSON reliability, latency and peak RAM on the user's Mac.
12. Use the rotated Crustdata key only. The previously exposed key must be revoked.
