# CounterCheck v2.0 — Autonomous Business Due Diligence & Claim Verification Platform

CounterCheck is an evidence-first business due-diligence and claim-verification workspace built for **ContextCon IIT Bombay (Crustdata Track)**.

## Full-Scale Capabilities Implemented

1. **9-Stage Autonomous Investigation State Machine (`apps/api/app/services/investigation_workflow.py`)**:
   - `draft` -> `queued` -> `resolving_identity` -> `awaiting_identity_confirmation` (Human-in-the-Loop Gate when multiple candidates match) -> `planning` -> `retrieving_company` -> `retrieving_people` -> `researching_web` -> `normalizing` -> `verifying` -> `quality_check` -> `drafting_report` -> `completed`.
2. **Crustdata Canonical Graph Connector (`apps/api/app/integrations/crustdata/client.py`)**:
   - Full support for `x-api-version: 2025-11-01` across `/company/identify`, `/company/enrich`, `/person/search`, `/person/enrich`, `/job/search`, `/web/search/live`, and `/web/enrich/live`.
   - Includes rate-limit backoff, SSRF URL validation, per-investigation credit ledger, budget caps, global kill switch, and offline evaluation fixture fallback.
3. **Local Ollama LLM Gateway (`apps/api/app/integrations/llm/provider.py`)**:
   - Auto-detects locally installed Ollama models (`http://localhost:11434/api/tags`), executes structured JSON claim extraction and bounded report synthesis, strips any unsupported citations (`validate_evidence_references`), and provides an explicit deterministic fallback when Ollama is offline.
4. **Deterministic Claim Verification Engine (`apps/api/app/verification/`)**:
   - Rule v2.1.0 verifiers for `founding_year`, `headcount`, `funding`, `location`, `leadership`, `hiring`, and `public_claim` with currency/unit/range/location normalization.
   - Enforces the core trust boundary: missing evidence always resolves to `UNVERIFIED`, never false `CONTRADICTED`.
5. **Interactive Analyst Web Workspace (`apps/web/app/page.tsx` & standalone `countercheck_workspace.html`)**:
   - Dynamic Runtime & API Configurator (set Crustdata API key, switch Ollama models, adjust credit caps, toggle kill switch).
   - Command Center, Ollama Pitch Claim Extractor, Candidate Disambiguation Gate, Live SSE Event Timeline, Claim Review & Audited Human Override Console, Evidence Vault with SHA-256 hashes & annotations, Interactive Entity Relationship Graph, and Traceable PDF Dossier export.
6. **Multi-Modal Agent Interfaces**:
   - **REST + SSE API**: `uvicorn app.main:app --reload --port 8000`
   - **MCP Server**: `python3 -m app.mcp_server`
   - **CLI Tool**: `python3 -m app.cli --company "Stripe" --claim "Founded in 2010" --pdf-out stripe_dossier.pdf`

## Quick Start (Zero-Docker Local Mode or Docker Compose)

### Option A: Instant Local Run (SQLite + Local Ollama + Next.js)
```bash
# 1. Start the FastAPI backend (auto-initializes SQLite DB and seeds 3 evaluation dossiers)
cd apps/api
cp .env.example .env
# Edit apps/api/.env to paste your CRUSTDATA_API_KEY (or enter it live in the Web UI Runtime Controls!)
pip install -e '.[dev]'
uvicorn app.main:app --reload --port 8000

# 2. In a second terminal, start the Next.js web workspace
cd apps/web
npm install
npm run dev
```

### Option B: Run All Unit & E2E Acceptance Tests (AC-01 through AC-14)
```bash
PYTHONPATH=apps/api python3 -m unittest discover -s tests -p "test_*.py" -v
```
