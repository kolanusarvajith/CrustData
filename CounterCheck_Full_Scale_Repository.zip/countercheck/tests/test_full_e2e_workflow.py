from __future__ import annotations
import asyncio
import tempfile
import unittest
from pathlib import Path

from app.core.logging import redact_secrets
from app.core.store import CounterCheckStore
from app.integrations.crustdata.client import CrustdataClient
from app.integrations.llm.provider import OllamaProvider
from app.integrations.web.safety import UnsafeURL, classify_source_quality, validate_public_http_url
from app.mcp_server import handle_mcp_request
from app.services.claim_extraction import extract_claims
from app.services.investigation_workflow import run_full_investigation_pipeline
from app.services.llm_report import validate_evidence_references
from app.services.pdf_report import render_report_pdf
from app.verification.company_rules import (
    compare_funding_claim,
    compare_headcount_claim,
    compare_leadership_claim,
    compare_location_claim,
    compare_year_claim,
)
from app.verification.rules import VerdictStatus, parse_numeric_value, verify_numeric_claim


class CounterCheckAcceptanceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp_db = tempfile.NamedTemporaryFile(dir="/tmp", suffix=".db", delete=False)
        self.tmp_db.close()
        self.store = CounterCheckStore(db_path=self.tmp_db.name)

    def tearDown(self) -> None:
        Path(self.tmp_db.name).unlink(missing_ok=True)

    def test_ac01_and_ac02_ambiguous_company_requires_selection(self) -> None:
        # OpenAI has 2 candidates in evaluation fixtures -> must pause at needs_user_input when auto_select=False
        inv = self.store.create_investigation(
            company_name="OpenAI",
            company_domain=None,
            purpose="Test Disambiguation Gate",
            claims=[
                {"category": "founding_year", "subject": "OpenAI", "metric": "year_founded", "claimed_value": 2015, "original_text": "OpenAI was founded in 2015."},
                {"category": "headcount", "subject": "OpenAI", "metric": "headcount.total", "claimed_value": 3500, "original_text": "OpenAI has 3,500 employees."},
                {"category": "location", "subject": "OpenAI", "metric": "headquarters", "claimed_value": "San Francisco", "original_text": "Headquartered in San Francisco."},
            ],
        )
        res = asyncio.run(
            run_full_investigation_pipeline(
                inv["id"],
                auto_select_top_candidate=False,
                allow_fallback=True,
                target_store=self.store,
            )
        )
        self.assertEqual(res["status"], "needs_user_input")
        self.assertGreaterEqual(len(res["candidates"]), 2)

        # Now select canonical candidate 631466 and verify full pipeline completion
        completed = asyncio.run(
            run_full_investigation_pipeline(
                inv["id"],
                selected_candidate_id=631466,
                auto_select_top_candidate=True,
                allow_fallback=True,
                target_store=self.store,
            )
        )
        self.assertEqual(completed["status"], "completed")
        self.assertEqual(completed["company_crustdata_id"], 631466)
        self.assertEqual(len(completed["claims"]), 3)
        for clm in completed["claims"]:
            self.assertEqual(clm["verdict"]["status"], "SUPPORTED")
            self.assertTrue(len(clm["verdict"]["evidence_ids"]) >= 1)

    def test_ac03_secret_redaction(self) -> None:
        raw = "Authorization: Bearer sk_live_secret_998877 and crustdata_api_key=cd_secret_12345"
        redacted = redact_secrets(raw)
        self.assertNotIn("sk_live_secret_998877", redacted)
        self.assertNotIn("cd_secret_12345", redacted)
        self.assertIn("[REDACTED]", redacted)

    def test_ac05_and_ac06_deterministic_verifiers_and_unverified_rule(self) -> None:
        # Missing evidence must NEVER produce CONTRADICTED
        self.assertEqual(compare_year_claim(2020, None, None).status, VerdictStatus.UNVERIFIED)
        self.assertEqual(compare_headcount_claim(500, None, None).status, VerdictStatus.UNVERIFIED)
        self.assertEqual(compare_location_claim("Austin, TX", None, None).status, VerdictStatus.UNVERIFIED)
        self.assertEqual(verify_numeric_claim(100.0, []).status, VerdictStatus.UNVERIFIED)

        # Single funding round vs cumulative total must be UNVERIFIED, not false contradiction
        res_round = compare_funding_claim(
            "$50M Series A",
            250000000.0,
            ["ev_1"],
            claim_metric="Series A round",
            observed_last_round_type=None,
            observed_last_round_usd=None,
        )
        self.assertEqual(res_round.status, VerdictStatus.UNVERIFIED)

        # Leadership verification
        people = [{"name": "Patrick Collison", "title": "CEO & Co-Founder", "past_employers": ["Auctomatic"], "evidence_id": "ev_p1"}]
        self.assertEqual(
            compare_leadership_claim("CEO Patrick Collison previously at Auctomatic", "Patrick Collison", "Auctomatic", people).status,
            VerdictStatus.SUPPORTED,
        )
        self.assertEqual(
            compare_leadership_claim("CEO Patrick Collison previously at Goldman Sachs", "Patrick Collison", "Goldman Sachs", people).status,
            VerdictStatus.CONTRADICTED,
        )

    def test_ac07_and_ac08_llm_evidence_boundary_and_extraction(self) -> None:
        llm = OllamaProvider(base_url="http://127.0.0.1:59999")  # Offline port to test deterministic fallback
        extracted = asyncio.run(
            extract_claims(
                llm,
                "Stripe",
                "Stripe was founded in 2010, is headquartered in South San Francisco, and employs over 8,000 staff with $9.4 billion in funding.",
                allow_heuristic_fallback=True,
            )
        )
        self.assertGreaterEqual(len(extracted["claims"]), 3)
        # Validate that hallucinated evidence IDs are stripped
        draft = {
            "executive_summary": "Summary",
            "key_findings": [
                {"text": "Valid finding", "evidence_ids": ["ev_valid"]},
                {"text": "Hallucinated finding", "evidence_ids": ["ev_fake_999"]},
            ],
            "follow_up_questions": ["Check cap table"],
        }
        cleaned = validate_evidence_references(draft, {"ev_valid"})
        self.assertEqual(len(cleaned["key_findings"]), 1)
        self.assertEqual(cleaned["key_findings"][0]["evidence_ids"], ["ev_valid"])

    def test_ac09_and_ac14_graph_pdf_and_human_override_audit(self) -> None:
        inv = self.store.create_investigation(
            company_name="Meridian Quantum Logistics Ltd.",
            company_domain="meridian-q-logistics.io",
            purpose="Supplier Fraud & Shell Check",
            claims=[
                {"category": "founding_year", "subject": "Meridian", "metric": "year_founded", "claimed_value": 2016, "original_text": "Founded in 2016."},
                {"category": "headcount", "subject": "Meridian", "metric": "headcount.total", "claimed_value": 450, "original_text": "Has 450 employees."},
            ],
        )
        completed = asyncio.run(
            run_full_investigation_pipeline(
                inv["id"],
                auto_select_top_candidate=True,
                allow_fallback=True,
                target_store=self.store,
            )
        )
        self.assertEqual(completed["status"], "completed")
        self.assertGreaterEqual(len(completed["graph"]["nodes"]), 3)
        self.assertGreaterEqual(len(completed["graph"]["edges"]), 2)
        for edge in completed["graph"]["edges"]:
            self.assertTrue(len(edge["evidence_ids"]) >= 1)

        # Human override preserves system verdict and records audit event
        claim_id = completed["claims"][0]["id"]
        self.assertEqual(completed["claims"][0]["verdict"]["status"], "CONTRADICTED")
        rev = self.store.record_human_review(
            claim_id=claim_id,
            disposition="overridden",
            override_status="UNVERIFIED",
            reason="Vendor supplied supplemental parent holding incorporation certificate pending legal verification.",
        )
        self.assertTrue(rev["system_verdict_unchanged"])
        refreshed = self.store.get_claim(claim_id)
        self.assertEqual(refreshed["verdict"]["status"], "CONTRADICTED")
        self.assertEqual(refreshed["human_review"]["override_status"], "UNVERIFIED")
        audits = self.store.list_audit_events(inv["id"])
        self.assertTrue(any(a["action"] == "claim_reviewed" for a in audits))

        # PDF export produces valid PDF bytes
        pdf_bytes = render_report_pdf(completed["reports"][0]["content"])
        self.assertTrue(pdf_bytes.startswith(b"%PDF"))
        self.assertGreater(len(pdf_bytes), 1200)

    def test_mcp_server_protocol(self) -> None:
        init_resp = asyncio.run(handle_mcp_request({"jsonrpc": "2.0", "id": 1, "method": "initialize"}))
        self.assertEqual(init_resp["result"]["serverInfo"]["name"], "countercheck-mcp")
        tools_resp = asyncio.run(handle_mcp_request({"jsonrpc": "2.0", "id": 2, "method": "tools/list"}))
        self.assertEqual(len(tools_resp["result"]["tools"]), 3)


if __name__ == "__main__":
    unittest.main()
