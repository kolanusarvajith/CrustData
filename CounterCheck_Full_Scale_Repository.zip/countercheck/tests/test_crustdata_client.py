import asyncio
import unittest
from app.integrations.crustdata.client import CrustdataClient


async def test_identify_requires_exactly_one_identifier():
    async with CrustdataClient(api_key="test-key") as client:
        try:
            await client.identify_company(name="A", domain="a.com")
            raise AssertionError("Expected ValueError")
        except ValueError:
            pass


async def test_missing_credentials_fails_clearly():
    async with CrustdataClient(api_key="", allow_fallback=False) as client:
        try:
            await client.identify_company(name="Acme")
            raise AssertionError("Expected CrustdataError")
        except Exception as exc:
            assert "CRUSTDATA_API_KEY is not configured" in str(exc)


class TestCrustdataClient(unittest.TestCase):
    def test_identify_validation(self):
        asyncio.run(test_identify_requires_exactly_one_identifier())

    def test_missing_key_error(self):
        asyncio.run(test_missing_credentials_fails_clearly())
