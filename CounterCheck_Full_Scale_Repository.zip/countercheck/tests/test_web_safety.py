import unittest
from app.integrations.web.safety import UnsafeURL, validate_public_http_url


def test_rejects_localhost():
    try:
        validate_public_http_url("http://localhost:8000/admin")
        raise AssertionError("Expected UnsafeURL")
    except UnsafeURL:
        pass


def test_rejects_private_ip():
    try:
        validate_public_http_url("http://127.0.0.1/private")
        raise AssertionError("Expected UnsafeURL")
    except UnsafeURL:
        pass


class TestWebSafety(unittest.TestCase):
    def test_localhost(self):
        test_rejects_localhost()

    def test_private_ip(self):
        test_rejects_private_ip()
