from app.verification.rules import VerdictStatus, verify_numeric_claim


def test_missing_observation_is_unverified():
    result = verify_numeric_claim(100, [])
    assert result.status == VerdictStatus.UNVERIFIED


def test_matching_value_is_supported():
    result = verify_numeric_claim(100, [{"value": 100, "evidence_id": "e1"}])
    assert result.status == VerdictStatus.SUPPORTED
    assert result.evidence_ids == ("e1",)


def test_conflicting_observations_do_not_force_verdict():
    result = verify_numeric_claim(100, [
        {"value": 100, "evidence_id": "e1"},
        {"value": 140, "evidence_id": "e2"},
    ])
    assert result.status == VerdictStatus.CONFLICTING


import unittest
class TestVerificationUnit(unittest.TestCase):
    def test_all(self):
        test_missing_observation_is_unverified()
        test_matching_value_is_supported()
        test_conflicting_observations_do_not_force_verdict()
