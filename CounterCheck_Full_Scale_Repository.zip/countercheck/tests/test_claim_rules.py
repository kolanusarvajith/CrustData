from app.verification.company_rules import compare_year_claim, compare_headcount_claim
from app.verification.rules import VerdictStatus


def test_year_missing_is_unverified():
    assert compare_year_claim(2020, None, None).status == VerdictStatus.UNVERIFIED


def test_year_match_supported():
    assert compare_year_claim(2020, 2020, "source-1").status == VerdictStatus.SUPPORTED


def test_estimated_headcount_difference_is_not_silently_exact():
    result = compare_headcount_claim(100, 120, "source-2")
    assert result.status == VerdictStatus.CONTRADICTED
    assert "estimate" in result.explanation


import unittest
class TestClaimRulesUnit(unittest.TestCase):
    def test_all(self):
        test_year_missing_is_unverified()
        test_year_match_supported()
        test_estimated_headcount_difference_is_not_silently_exact()
