# Database migrations

Alembic migration configuration and version scripts will be committed here. The initial ORM schema lives in `apps/api/app/models/investigation.py`. Until the first versioned migration is generated, initialize only in local development with `Base.metadata.create_all`; do not use that shortcut in production. Migration wiring is part of the next hardening checkpoint.
