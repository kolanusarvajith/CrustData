"""Initial CounterCheck schema migration (Section 9)."""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial_countercheck"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "investigations",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("company_identifier", sa.String(length=256), nullable=False),
        sa.Column("company_name", sa.String(length=256), nullable=True),
        sa.Column("company_domain", sa.String(length=253), nullable=True),
        sa.Column("company_crustdata_id", sa.Integer(), nullable=True),
        sa.Column("purpose", sa.String(length=500), nullable=False),
        sa.Column("status", sa.String(length=40), nullable=False, server_default="draft"),
        sa.Column("input_snapshot", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_investigations_status", "investigations", ["status"])
    op.create_index("ix_investigations_created_at", "investigations", ["created_at"])

    op.create_table(
        "claims",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("investigation_id", sa.String(length=36), sa.ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("category", sa.String(length=80), nullable=False),
        sa.Column("subject", sa.String(length=256), nullable=False),
        sa.Column("metric", sa.String(length=128), nullable=False),
        sa.Column("operator", sa.String(length=32), nullable=False),
        sa.Column("claimed_value", sa.JSON(), nullable=True),
        sa.Column("unit", sa.String(length=64), nullable=True),
        sa.Column("period", sa.String(length=128), nullable=True),
        sa.Column("original_text", sa.Text(), nullable=False),
        sa.Column("parse_version", sa.String(length=32), nullable=False, server_default="v2.1"),
    )
    op.create_index("ix_claims_investigation_id", "claims", ["investigation_id"])

    op.create_table(
        "evidence_sources",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("investigation_id", sa.String(length=36), sa.ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("provider", sa.String(length=40), nullable=False),
        sa.Column("provider_entity_id", sa.String(length=128), nullable=True),
        sa.Column("source_url", sa.Text(), nullable=True),
        sa.Column("source_title", sa.Text(), nullable=True),
        sa.Column("publisher", sa.String(length=256), nullable=True),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("retrieved_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("content_hash", sa.String(length=64), nullable=True),
        sa.Column("raw_object_ref", sa.Text(), nullable=True),
        sa.Column("limitations", sa.Text(), nullable=True),
    )

    op.create_table(
        "observations",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("investigation_id", sa.String(length=36), sa.ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("evidence_source_id", sa.String(length=36), sa.ForeignKey("evidence_sources.id", ondelete="CASCADE"), nullable=False),
        sa.Column("entity_provider_id", sa.String(length=128), nullable=True),
        sa.Column("field_path", sa.String(length=512), nullable=False),
        sa.Column("raw_value", sa.JSON(), nullable=True),
        sa.Column("normalized_value", sa.JSON(), nullable=True),
        sa.Column("unit", sa.String(length=64), nullable=True),
        sa.Column("observed_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "verdicts",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("claim_id", sa.String(length=36), sa.ForeignKey("claims.id", ondelete="CASCADE"), unique=True, nullable=False),
        sa.Column("status", sa.String(length=24), nullable=False),
        sa.Column("explanation", sa.Text(), nullable=False),
        sa.Column("confidence_band", sa.String(length=24), nullable=True),
        sa.Column("rule_version", sa.String(length=32), nullable=False),
        sa.Column("evidence_ids", sa.JSON(), nullable=False),
    )

    op.create_table(
        "human_reviews",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("claim_id", sa.String(length=36), sa.ForeignKey("claims.id", ondelete="CASCADE"), nullable=False),
        sa.Column("reviewer_id", sa.String(length=128), nullable=True),
        sa.Column("disposition", sa.String(length=32), nullable=False),
        sa.Column("override_status", sa.String(length=24), nullable=True),
        sa.Column("override_reason", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "investigation_events",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("investigation_id", sa.String(length=36), sa.ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sequence", sa.Integer(), nullable=False),
        sa.Column("stage", sa.String(length=64), nullable=False),
        sa.Column("event_type", sa.String(length=64), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("safe_message", sa.Text(), nullable=False),
        sa.Column("details", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("investigation_id", "sequence", name="uq_investigation_event_sequence"),
    )


def downgrade() -> None:
    op.drop_table("investigation_events")
    op.drop_table("human_reviews")
    op.drop_table("verdicts")
    op.drop_table("observations")
    op.drop_table("evidence_sources")
    op.drop_table("claims")
    op.drop_table("investigations")
